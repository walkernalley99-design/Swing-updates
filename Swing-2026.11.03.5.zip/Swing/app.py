"""
Swing - automated futures trading for Topstep.

Double-click "Start Swing" (Windows) or "Start Swing.command" (Mac).
It opens a dashboard in your browser where you can:
  - start / stop the bot, or flatten everything
  - see each account's balance, today's P&L, open positions and limits
  - run the backtest and see which strategies passed
  - see your P&L calendar
  - change settings (API key, accounts, risk, practice mode)
Optional: control it from your phone on the same Wi-Fi (Settings > Phone access).
"""
import json, os, re, socket, subprocess, sys, threading, time, webbrowser, secrets
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from http.cookies import SimpleCookie

APP_DIR = os.path.dirname(os.path.abspath(__file__))
PORT = 8765
SETTINGS = os.path.join(APP_DIR, "settings.json")
PRESETS = {  # Topstep account sizes: start balance, max loss limit, profit target, max micros
    "50K": (50_000, 2_000, 3_000, 50), "100K": (100_000, 3_000, 6_000, 100), "150K": (150_000, 4_500, 9_000, 150)}

API = "https://api.topstepx.com/api"
procs = {"bot": None, "backtest": None}
NEWS = {"events": [], "ok": True, "headlines": []}

def news_loop():
    """Keeps the calendar and headlines fresh for the dashboard, even when the bot is off."""
    os.chdir(APP_DIR)
    import news as N
    while True:
        try:
            cfg = N.settings(load_settings().get("news"))
            NEWS["events"], NEWS["ok"] = N.calendar()
            NEWS["headlines"] = N.headlines(cfg["keywords"])
        except Exception:
            pass
        time.sleep(120)
lock = threading.Lock()


def path(name):
    return os.path.join(APP_DIR, name)

def read_json(name, default=None):
    try:
        with open(path(name)) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default

_TAIL = {}

def tail(name, lines=150):
    """Last lines of a log. Cached until the file changes (the app asks for these every few seconds)."""
    try:
        st = os.stat(path(name))
    except OSError:
        return []
    key = (name, lines)
    hit = _TAIL.get(key)
    if hit and hit[0] == (st.st_mtime_ns, st.st_size):
        return list(hit[1])
    try:
        with open(path(name), errors="replace") as f:
            if st.st_size > 2_000_000:          # big log: only read the end
                f.seek(st.st_size - 2_000_000)
                f.readline()
            out = f.readlines()[-lines:]
    except FileNotFoundError:
        return []
    _TAIL[key] = ((st.st_mtime_ns, st.st_size), out)
    return list(out)

def load_settings():
    s = None
    for _ in range(5):                       # never treat a busy/unreadable file as "no settings"
        s = read_json("settings.json", None)
        if s is not None or not os.path.exists(SETTINGS):
            break
        time.sleep(0.05)
    if s is None and os.path.exists(SETTINGS) and os.path.getsize(SETTINGS) > 0:
        raise RuntimeError("settings.json can't be read")
    s = s or {}
    s["api_key"] = reveal_secret(s.get("api_key", ""))
    s.setdefault("username", "")
    s.setdefault("api_key", "")
    s.setdefault("mode", "paper" if not s.get("api_key") else ("practice" if s.get("dry_run", True) else "live"))
    s.setdefault("venue", "paper" if s["mode"] == "paper" else "topstep")
    s.setdefault("real_orders", s["mode"] == "live")
    s.setdefault("topstep_accounts", [])
    s["mode"] = "paper" if s["venue"] == "paper" else ("live" if s["real_orders"] else "practice")
    s["dry_run"] = s["mode"] == "practice"
    s.setdefault("accounts", [{"match": "", "type": "combine", "size": "50K", "risk": "auto"}])
    s.setdefault("remote_access", False)
    s.setdefault("news", {})
    s.setdefault("rules", {"giveback": True, "loss_streak_all": False})
    s.setdefault("payouts", [])
    s.setdefault("funded_cost", 200)
    s.setdefault("risk_override", None)          # None = Swing picks from the backtest; a number = $ per trade
    s.setdefault("auto_update", True)            # install new versions by itself (Settings can turn it off)
    s.setdefault("cloud_url", "")                # set: this computer opens the cloud Swing instead of its own
    s.setdefault("monthly_goal", 10000)          # the scale plan aims for this much a month after fees
    s.setdefault("min_pass", 75)                 # Combine sizes must pass at least this % of the time in testing
    s.setdefault("auto_reopt", True)             # re-run the backtest every weekend (and after a setup is benched)
    import notify as NT
    s["notify"] = NT.settings(s.get("notify"))
    s.setdefault("pin", "")                      # old passcode (before accounts); only used to claim the account
    s.setdefault("owner", None)                  # {"name", "salt", "hash"}: the Swing account
    s.setdefault("sessions", {})                 # sign-in token -> expiry (unix time)
    s.setdefault("setup_done", bool(s.get("owner")) or os.path.exists(path("best_config.json")))
    s.setdefault("token", secrets.token_hex(16))
    return s

SETTINGS_LOCK = threading.RLock()

# ---------------- keeping your Topstep API key safe on disk ----------------
# Windows: encrypted with your Windows login (DPAPI), so the file is useless if copied to another PC.
# Linux servers: the settings file is readable only by Swing's own user.
def _dpapi(data, protect):
    import ctypes
    from ctypes import wintypes as w
    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", w.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    buf = ctypes.create_string_buffer(data, len(data))
    blob_in = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    blob_out = BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
    if not fn(ctypes.byref(blob_in), None, None, None, None, 0x1, ctypes.byref(blob_out)):   # 0x1 = no UI
        raise OSError("DPAPI failed")
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)

def protect_secret(v):
    if not v or os.name != "nt":
        return v
    try:
        import base64
        enc = "dpapi:" + base64.b64encode(_dpapi(v.encode(), True)).decode()
        return enc if reveal_secret(enc) == v else v          # only keep it encrypted if it reads back right
    except Exception:
        return v

def reveal_secret(v):
    if not isinstance(v, str) or not v.startswith("dpapi:"):
        return v or ""
    try:
        import base64
        return _dpapi(base64.b64decode(v[6:]), False).decode()
    except Exception:
        return ""

def save_settings(s):
    if "venue" in s:
        s["mode"] = "paper" if s["venue"] == "paper" else ("live" if s.get("real_orders") else "practice")
        s["dry_run"] = s["mode"] == "practice"
    tmp = SETTINGS + ".tmp"
    out = dict(s)
    out["api_key"] = protect_secret(s.get("api_key", ""))
    with SETTINGS_LOCK:                   # write whole, then swap: readers never see a half-written file
        with open(tmp, "w") as f:
            json.dump(out, f, indent=2)
        if os.name != "nt":
            os.chmod(tmp, 0o600)          # only Swing's own user can read it
        os.replace(tmp, SETTINGS)

def guess_type(name):
    n = name.upper()
    if "PRAC" in n:
        return "practice"
    if any(k in n for k in ("XFA", "EXPRESS", "EFA", "FUNDED")):
        return "express"
    return "combine"

def guess_size(name, balance):
    n = name.upper()
    for k in ("150K", "100K", "50K"):
        if k in n:
            return k
    b = balance or 50_000
    return "50K" if b < 75_000 else "100K" if b < 125_000 else "150K"

def topstep_login(username, api_key):
    import requests
    try:
        r = requests.post(f"{API}/Auth/loginKey", json={"userName": username, "apiKey": api_key}, timeout=15).json()
    except Exception:
        return None, "Couldn't reach TopstepX. Check your internet connection."
    if not r.get("success"):
        return None, "TopstepX didn't accept that username and API key. Check both and try again."
    sess = requests.Session()
    sess.headers["Authorization"] = f"Bearer {r['token']}"
    return sess, None

def fetch_topstep_accounts(s):
    """Log in and merge the live account list with the saved choices (on/off, type, size, risk)."""
    sess, err = topstep_login(s["username"], s["api_key"])
    if err:
        return err
    try:
        accts = sess.post(f"{API}/Account/search", json={"onlyActiveAccounts": True}, timeout=15).json().get("accounts", [])
    except Exception:
        return "Connected, but couldn't load your accounts. Try Refresh in a minute."
    old = {a["id"]: a for a in s.get("topstep_accounts", [])}
    merged = []
    for x in accts:
        prev = old.get(x["id"], {})
        merged.append({"id": x["id"], "name": x["name"], "balance": x.get("balance"), "can_trade": bool(x.get("canTrade")),
                       "enabled": prev.get("enabled", False), "type": prev.get("type") or guess_type(x["name"]),
                       "size": prev.get("size") or guess_size(x["name"], x.get("balance")), "risk": prev.get("risk", "auto")})
    s["topstep_accounts"] = merged
    s["connected"] = True
    save_settings(s)
    return None

def bot_accounts(s):
    """Convert the app's simple account rows into the bot's ACCOUNTS format."""
    out = []
    for a in s["accounts"]:
        start, mll, target, micros = PRESETS.get(a.get("size", "50K"), PRESETS["50K"])
        combine = a.get("type") == "combine"
        out.append({"match": a.get("match", ""), "type": a.get("type", "combine"), "start_balance": start,
                    "mll": mll, "profit_target": target if combine else 0,
                    "consistency": 0.5 if combine else 0, "max_micros": micros, "risk": a.get("risk", "auto")})
    return out

def running(name):
    p = procs[name]
    return p is not None and p.poll() is None

def child_env(s):
    env = dict(os.environ)
    env["PX_USERNAME"], env["PX_API_KEY"] = s["username"], s["api_key"]
    return env

def start_bot():
    with lock:
        if running("bot"):
            return "The bot is already running."
        s = load_settings()
        if s.get("cloud_url"):
            return "This computer shows your cloud Swing, which does the trading. Nothing runs here."
        if s["mode"] != "paper":
            if not s["username"] or not s["api_key"]:
                return "Connect your Topstep account in Settings, or switch to Paper."
            if not any(a.get("enabled") for a in s["topstep_accounts"]):
                return "Turn on at least one Topstep account in Settings."
        if s["mode"] == "live" and not read_json("best_config.json"):
            return "Run the backtest first. Live trading needs its results."
        try:
            os.remove(path("STOP"))
        except FileNotFoundError:
            pass
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        procs["bot"] = subprocess.Popen([sys.executable, path("topstep_bot.py")], cwd=APP_DIR, env=child_env(s),
                                        stdout=subprocess.DEVNULL, stderr=open(path("bot_errors.log"), "a"),
                                        creationflags=flags)
        if not s.get("autostart"):
            s["autostart"] = True
            save_settings(s)
        return None

def stop_bot(flatten=False, remember=True):
    with lock:
        if remember:
            s = load_settings()
            if s.get("autostart"):
                s["autostart"] = False
                save_settings(s)
        if not running("bot"):
            return "The bot isn't running."
        if flatten:
            open(path("STOP"), "w").close()        # bot closes every position, then exits
            try:
                procs["bot"].wait(timeout=60)
            except subprocess.TimeoutExpired:
                procs["bot"].terminate()
        else:
            procs["bot"].terminate()                # open trades keep their stop + target at Topstep
        return None

def start_backtest():
    with lock:
        if running("backtest"):
            return "A backtest is already running."
        s = load_settings()
        has_csv = any(os.path.exists(path(f"data/{m}.csv")) or os.path.exists(path(f"data/{m}_api.csv"))
                      for m in ("MNQ", "MES", "MGC"))
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        procs["backtest"] = subprocess.Popen([sys.executable, "-u", path("backtest.py")], cwd=APP_DIR,
                                             env=child_env(s), stdout=open(path("backtest_output.log"), "w"),
                                             stderr=subprocess.STDOUT, creationflags=flags)
        return None

# ---------------- Swing account (username + password) ----------------
SESSION_DAYS = 90
_FAILS = {}            # ip -> [count, first failure time]

def hash_pw(pw, salt):
    import hashlib
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200_000).hex()

def make_owner(name, pw):
    salt = secrets.token_hex(16)
    return {"name": name.strip(), "salt": salt, "hash": hash_pw(pw, salt)}

def check_pw(owner, name, pw):
    return bool(owner) and name.strip().lower() == owner["name"].lower() and \
        secrets.compare_digest(hash_pw(pw, owner["salt"]), owner["hash"])

def new_session(s):
    tok = secrets.token_urlsafe(32)
    now = time.time()
    s["sessions"] = {k: v for k, v in s.get("sessions", {}).items() if v > now}
    s["sessions"][tok] = now + SESSION_DAYS * 86400
    save_settings(s)
    return f"sw={tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_DAYS * 86400}"

def account_problem(name, pw):
    if not re.fullmatch(r"[A-Za-z0-9_.@-]{3,40}", (name or "").strip()):
        return "Pick a username of 3+ letters or numbers (no spaces)."
    if len(pw or "") < 8:
        return "Use a password of at least 8 characters."
    return None

def listening_remote(s):
    return bool(s["remote_access"] and (s.get("owner") or s.get("pin")))

def lan_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sk:
            sk.connect(("8.8.8.8", 80))
            return sk.getsockname()[0]
    except OSError:
        return "127.0.0.1"

def news_cfg(s):
    import news as N
    return N.settings(s.get("news"))

ACTIVITY = re.compile(r"ENTERED|STOPPED|first target|EOD|reversal|DRY RUN|Kill switch|FLATTENED|exit time|NEWS|VOLATILITY|no stop")

_ACT = {"key": None, "lines": []}

def activity():
    try:
        st = os.stat(path("bot.log"))
        key = (st.st_mtime_ns, st.st_size)
    except OSError:
        return []
    if key != _ACT["key"]:
        _ACT.update(key=key, lines=[l for l in tail("bot.log", 4000) if ACTIVITY.search(l)][-150:])
    return list(_ACT["lines"])

def state():
    s = load_settings()
    status = read_json("status.json", {}) or {}
    fresh = bool(status) and time.time() - status.get("ts", 0) < 120
    report = "".join(tail("backtest_report.txt", 400))
    return {
        "bot": {"running": running("bot"), "dry_run": s["mode"] == "practice", "mode": s["mode"]},
        "paper": read_json("paper_state.json"),
        "backtest": {"running": running("backtest"), "output": tail("backtest_output.log", 60), "report": report},
        "status": status if fresh else {},
        "config": read_json("best_config.json"),
        "history": read_json("bot_state.json", {}) or {},
        "log": tail("bot.log", 200),
        "activity": activity(),
        "briefs": (read_json("briefs.json", []) or [])[-10:],
        "news": {"events": NEWS["events"], "ok": NEWS["ok"], "headlines": NEWS["headlines"],
                 "cfg": news_cfg(s)},
        "errors": tail("bot_errors.log", 20) if not running("bot") else [],
        "settings": {"username": s["username"], "has_key": bool(s["api_key"]), "dry_run": s["dry_run"], "mode": s["mode"],
                     "accounts": s["accounts"], "remote_access": s["remote_access"], "account": (s.get("owner") or {}).get("name"),
                     "setup_done": s.get("setup_done"), "host": s.get("host", "pc"), "cloud_url": s.get("cloud_url"),
                     "auto_update": s.get("auto_update", True), "version": local_version(),
                     "update": dict(UPDATE, feed=bool(feed_url(s))),
                     "venue": s["venue"], "real_orders": s["real_orders"], "connected": bool(s.get("connected")),
                     "topstep_accounts": s["topstep_accounts"], "rules": s["rules"], "notify": s["notify"],
                     "payouts": s["payouts"], "funded_cost": s["funded_cost"], "risk_override": s["risk_override"],
                     "min_pass": s["min_pass"], "monthly_goal": s["monthly_goal"], "auto_reopt": s["auto_reopt"], "last_reopt": s.get("last_reopt"),
                     "phone_url": f"http://{lan_ip()}:{PORT}",
                     "anywhere_url": (tailscale_https() or f"http://{tailscale_ip()}:{PORT}") if s["remote_access"] and tailscale_ip() else None},
        "ui_version": ui_version(),
    }


PROGRAM = ("version.json", "app.py", "topstep_bot.py", "strategies.py", "backtest.py", "news.py", "notify.py", "paper.py",
           "dashboard.html", "icon.png", "icon.ico", "README.txt", "install_cloud.sh", "install_pi.sh",
           "Swing.vbs", "Start Swing.bat", "Add Desktop Icon.bat")

UPDATABLE = re.compile(r"^(?:[\w .-]+/)?([A-Za-z_]+\.py|dashboard\.html|version\.json|install_\w+\.sh|README\.txt|"
                       r"icon\.(?:png|ico)|Start Swing\.(?:bat|command)|Add Desktop Icon\.bat|Swing\.vbs)$")

def install_zip(data):
    """Install Swing's program files from a Swing.zip. Settings, keys, history and results are never touched.
    The running app notices the new files and restarts itself on them."""
    import io, zipfile
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        return "That isn't a Swing.zip file.", 0
    files = {}
    for info in z.infolist():
        m = UPDATABLE.match(info.filename)
        if m and not info.is_dir() and ".." not in info.filename:
            files[m.group(1)] = z.read(info)
    if "app.py" not in files or "topstep_bot.py" not in files:
        return "That zip doesn't look like Swing (no app.py / topstep_bot.py).", 0
    for name, blob in files.items():          # write each file whole, then swap it in
        tmp = path(name + ".new")
        with open(tmp, "wb") as f:
            f.write(blob)
        os.replace(tmp, path(name))
    print(f"Update installed: {len(files)} files. Restarting with the new version.")
    return None, len(files)

# ---------------- automatic updates ----------------
# Swing checks a small "latest.json" file online every few hours:
#   {"version": "2026.11.03.2", "zip": "https://.../Swing.zip", "sha256": "...", "notes": "What's new"}
# When there's a newer version it downloads Swing.zip, checks it isn't damaged (sha256), and installs it
# while no trade is open. Turn it off in Settings.
UPDATE_FEED = "https://raw.githubusercontent.com/walkernalley99-design/swing-updates/main/latest.json"
UPDATE = {"checked": None, "latest": None, "notes": None, "error": None, "pending": False}

def local_version():
    v = read_json("version.json", {}) or {}
    return v.get("version", "0")

def _vkey(v):
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-]", str(v)))

def feed_url(s):
    u = (s.get("update_feed") or UPDATE_FEED or "").strip()
    return "" if "OWNER/REPO" in u else u

def trades_open():
    st = read_json("status.json", {}) or {}
    return any(a.get("positions") for a in st.get("accounts", []))

def check_update(install=True):
    """Look for a newer Swing; install it when it's safe. Returns a short message."""
    import hashlib
    import requests as rq
    s = load_settings()
    url = feed_url(s)
    if not url:
        UPDATE["error"] = "Automatic updates aren't set up for this copy yet."
        return UPDATE["error"]
    try:
        info = rq.get(url, timeout=15, headers={"Cache-Control": "no-cache"}).json()
    except Exception as e:
        UPDATE["error"] = f"Couldn't check for updates ({type(e).__name__})."
        return UPDATE["error"]
    UPDATE.update(checked=time.strftime("%b %d %I:%M %p"), latest=info.get("version"), notes=info.get("notes"), error=None)
    if _vkey(info.get("version", "0")) <= _vkey(local_version()):
        UPDATE["pending"] = False
        return "Swing is up to date."
    if not install:
        UPDATE["pending"] = True
        return f"Version {info.get('version')} is available."
    if trades_open():
        UPDATE["pending"] = True
        return "An update is ready. It installs once no trade is open."
    try:
        blob = rq.get(info["zip"], timeout=60).content
    except Exception as e:
        UPDATE["error"] = f"Couldn't download the update ({type(e).__name__})."
        return UPDATE["error"]
    if info.get("sha256") and hashlib.sha256(blob).hexdigest() != info["sha256"].lower():
        UPDATE["error"] = "The update download was damaged. Swing will try again later."
        return UPDATE["error"]
    err, _ = install_zip(blob)
    if err:
        UPDATE["error"] = err
        return err
    UPDATE["pending"] = False
    return f"Updated to {info.get('version')}. Restarting…"

def _auto_update():
    time.sleep(90)                              # let Swing settle after starting
    while True:
        try:
            if load_settings().get("auto_update", True) and not running("backtest"):
                check_update(install=True)
        except Exception as e:
            UPDATE["error"] = f"Update check failed ({type(e).__name__})."
        time.sleep(30 * 60 if UPDATE.get("pending") else 3 * 3600)

def support_zip():
    """Logs and results for getting help. Never includes your API key, password or sign-ins."""
    import io, zipfile
    s = load_settings()
    safe = {k: v for k, v in s.items() if k not in ("api_key", "owner", "sessions", "pin", "token", "notify")}
    safe["username"] = "(set)" if s.get("username") else ""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("settings (no secrets).json", json.dumps(safe, indent=2))
        z.writestr("about.txt", f"Swing {local_version()} on {sys.platform}, Python {sys.version.split()[0]}\n")
        for f in ("bot.log", "bot_errors.log", "app_output.log", "backtest_output.log", "backtest_report.txt",
                  "status.json", "best_config.json", "version.json"):
            if os.path.exists(path(f)):
                z.writestr(f, "".join(tail(f, 3000)) if f.endswith(".log") else open(path(f), errors="replace").read())
    return buf.getvalue()

def trades_csv():
    """Every finished trade Swing has recorded, for your records or taxes."""
    import csv, io
    hist = read_json("bot_state.json", {}) or {}
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["date", "account", "market", "side", "contracts", "setup", "session", "entry time", "exit time",
                "entry", "exit", "stop", "net P&L ($)", "result"])
    rows = []
    for acct in hist.values():
        if not isinstance(acct, dict):
            continue
        for day, d in (acct.get("days") or {}).items():
            for t in d.get("trips") or []:
                rows.append([day, t.get("account", acct.get("name", "")), t.get("market"), t.get("side"), t.get("size"),
                             t.get("strategy"), t.get("session"), t.get("time"), t.get("exit_time"), t.get("entry"),
                             t.get("exit"), t.get("stop"), t.get("net"), t.get("outcome")])
    for r in sorted(rows, key=lambda r: str(r[7])):
        w.writerow(r)
    return out.getvalue().encode("utf-8-sig")

def package_zip():
    """Swing's program files (never settings, keys or history) as Swing.zip."""
    import io, zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in PROGRAM:
            if os.path.exists(path(f)):
                z.write(path(f), "Swing/" + f)
    return buf.getvalue()

def page():
    """Read fresh from disk, so an updated dashboard shows up on the computer and phone without a restart."""
    try:
        with open(path("dashboard.html"), encoding="utf-8") as f:
            return f.read()
    except OSError:
        return "missing dashboard.html"

def ui_version():
    try:
        return int(os.path.getmtime(path("dashboard.html")))
    except OSError:
        return 0

_TS = {"ip": None, "at": 0}

_TSH = {"url": None, "at": 0}

def tailscale_https():
    """A secure https:// address for this Swing on your Tailscale network, when Tailscale HTTPS is serving it."""
    if time.time() - _TSH["at"] < 300:
        return _TSH["url"]
    url = None
    for exe in ("tailscale", r"C:\Program Files\Tailscale\tailscale.exe"):
        try:
            kw = dict(capture_output=True, text=True, timeout=5,
                      creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            serve = subprocess.run([exe, "serve", "status", "--json"], **kw).stdout
            if str(PORT) not in serve:
                break
            name = json.loads(subprocess.run([exe, "status", "--json"], **kw).stdout)["Self"]["DNSName"].rstrip(".")
            url = f"https://{name}"
            break
        except (OSError, subprocess.SubprocessError, ValueError, KeyError):
            continue
    _TSH.update(url=url, at=time.time())
    return url

def tailscale_ip():
    """This computer's private Tailscale address (reachable from your phone anywhere), if Tailscale is installed."""
    if time.time() - _TS["at"] < 60:
        return _TS["ip"]
    ip = None
    for exe in ("tailscale", r"C:\Program Files\Tailscale\tailscale.exe"):
        try:
            out = subprocess.run([exe, "ip", "-4"], capture_output=True, text=True, timeout=4,
                                 creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0).stdout.split()
            if out and out[0].startswith("100."):
                ip = out[0]
                break
        except (OSError, subprocess.SubprocessError):
            continue
    _TS.update(ip=ip, at=time.time())
    return ip

class Server(ThreadingHTTPServer):
    """Only one Swing may listen on the port. (Windows otherwise lets a second copy share it,
    and the two copies would answer at random and both trade.)"""
    allow_reuse_address = os.name != "nt"

    def server_bind(self):
        if os.name == "nt":
            self.socket.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", -5), 1)
        super().server_bind()

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def local(self):
        """A request from this same computer (also when it uses the computer's own network address)."""
        return self.client_address[0] in ("127.0.0.1", "::1", lan_ip())

    def admin(self):
        """Keys, access and updates: whoever is signed in to the Swing account."""
        return self.authed()

    def authed(self):
        """Signed in to the Swing account."""
        s = load_settings()
        if not s.get("owner"):
            return False                     # first, create the account (sign-in page)
        c = SimpleCookie(self.headers.get("Cookie", ""))
        tok = c["sw"].value if "sw" in c else None
        return bool(tok) and s.get("sessions", {}).get(tok, 0) > time.time()

    def login_state(self):
        s = load_settings()
        return {"login": True, "setup": not s.get("owner"), "need_pin": not s.get("owner") and not self.local()
                and bool(s.get("pin")), "blocked": not s.get("owner") and not self.local() and not s.get("pin")}

    def account_api(self, b):
        """Sign in, create the account, sign out, change password."""
        s = load_settings()
        ip = self.client_address[0]
        if self.path == "/api/login":
            f = _FAILS.get(ip)
            if f and f[0] >= 8 and time.time() - f[1] < 600:
                return self.send(429, json.dumps({"error": "Too many tries. Wait 10 minutes."}))
            if check_pw(s.get("owner"), b.get("name", ""), b.get("password", "")):
                _FAILS.pop(ip, None)
                return self.send(200, "{}", extra={"Set-Cookie": new_session(s)})
            time.sleep(1)
            f = _FAILS.setdefault(ip, [0, time.time()])
            f[0] += 1
            return self.send(403, json.dumps({"error": "Wrong username or password."}))
        if self.path == "/api/account/create":
            if s.get("owner"):
                return self.send(400, json.dumps({"error": "This Swing already has an account. Sign in instead."}))
            if not self.local() and not (s.get("pin") and b.get("pin") == s["pin"]):
                return self.send(403, json.dumps({"error": "Enter the passcode you picked when you installed Swing."
                                                  if s.get("pin") else "Create the account on the computer Swing runs on."}))
            err = account_problem(b.get("name"), b.get("password"))
            if err:
                return self.send(400, json.dumps({"error": err}))
            if not b.get("accept_terms"):
                return self.send(400, json.dumps({"error": "Read and accept the terms to use Swing."}))
            s["owner"] = make_owner(b["name"], b["password"])
            s["terms_accepted"] = time.strftime("%Y-%m-%d %H:%M")
            s["pin"] = ""
            return self.send(200, "{}", extra={"Set-Cookie": new_session(s)})
        if self.path == "/api/logout":
            c = SimpleCookie(self.headers.get("Cookie", ""))
            if "sw" in c:
                s.get("sessions", {}).pop(c["sw"].value, None)
                save_settings(s)
            return self.send(200, "{}", extra={"Set-Cookie": "sw=; Path=/; Max-Age=0"})
        if self.path == "/api/account/password":
            if not self.authed():
                return self.send(401, json.dumps(self.login_state()))
            if not check_pw(s.get("owner"), s["owner"]["name"], b.get("old", "")):
                return self.send(403, json.dumps({"error": "Your current password isn't right."}))
            err = account_problem(s["owner"]["name"], b.get("new"))
            if err:
                return self.send(400, json.dumps({"error": err}))
            s["owner"] = make_owner(s["owner"]["name"], b["new"])
            s["sessions"] = {}                     # sign out everywhere else
            return self.send(200, "{}", extra={"Set-Cookie": new_session(s)})

    def send(self, code, body, ctype="application/json", extra=None):
        data = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            return {}

    def update_upload(self):
        """Install a new version from Swing.zip (from Claude), e.g. from your phone when Swing runs on a server.
        Only Swing's own program files are replaced. Your settings, keys, history and results are never touched."""
        if not self.admin():
            return self.send(403, json.dumps({"error": "Updating needs the computer, or phone access on a server install."}))
        n = int(self.headers.get("Content-Length") or 0)
        if not 0 < n <= 20 * 1024 * 1024:
            return self.send(400, json.dumps({"error": "That file is empty or too big for a Swing update."}))
        err, count = install_zip(self.rfile.read(n))
        if err:
            return self.send(400, json.dumps({"error": err}))
        return self.send(200, json.dumps({"updated": count}))

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            cu = load_settings().get("cloud_url")
            if cu and self.local():            # this computer shows your cloud Swing: one Swing everywhere
                return self.send(302, "", "text/plain", extra={"Location": cu})
            return self.send(200, page(), "text/html; charset=utf-8")
        if self.path == "/?local=1" or self.path == "/local":
            return self.send(200, page(), "text/html; charset=utf-8")
        if self.path == "/Swing.zip" and self.authed():   # this Swing's program, to put on a cloud server
            return self.send(200, package_zip(), "application/zip",
                             extra={"Content-Disposition": 'attachment; filename="Swing.zip"'})
        if self.path == "/icon.png" and os.path.exists(path("icon.png")):
            return self.send(200, open(path("icon.png"), "rb").read(), "image/png")
        if self.path == "/manifest.webmanifest":
            return self.send(200, json.dumps({"name": "Swing", "short_name": "Swing", "start_url": "/", "display": "standalone",
                                              "background_color": "#F4F6FA", "theme_color": "#FFFFFF",
                                              "icons": [{"src": "/icon.png", "sizes": "512x512", "type": "image/png"}]}),
                             "application/manifest+json")
        if self.path == "/api/support.zip" and self.authed():
            return self.send(200, support_zip(), "application/zip",
                             extra={"Content-Disposition": 'attachment; filename="swing-support.zip"'})
        if self.path == "/api/trades.csv" and self.authed():
            return self.send(200, trades_csv(), "text/csv; charset=utf-8",
                             extra={"Content-Disposition": 'attachment; filename="swing-trades.csv"'})
        if self.path == "/api/state":
            if not self.authed():
                return self.send(401, json.dumps(self.login_state()))
            return self.send(200, json.dumps(state()))
        self.send(404, "{}")

    def do_POST(self):
        if self.path == "/api/update":
            return self.update_upload()
        b = self.body()
        if self.path in ("/api/login", "/api/account/create", "/api/logout", "/api/account/password"):
            return self.account_api(b)
        if not self.authed():
            return self.send(401, json.dumps(self.login_state()))
        err = None
        if self.path == "/api/bot/start":
            err = start_bot()
        elif self.path == "/api/bot/stop":
            err = stop_bot(False)
        elif self.path == "/api/bot/flatten":
            err = stop_bot(True)
        elif self.path == "/api/backtest/start":
            err = start_backtest()
        elif self.path == "/api/settings":
            b.pop("pin", None)
            s = load_settings()
            TRADING = ("venue", "real_orders", "topstep_accounts", "risk_override", "rules", "news", "accounts", "min_pass")
            before = json.dumps({k: s.get(k) for k in TRADING}, sort_keys=True)
            for k in ("username", "accounts", "remote_access", "news", "venue", "real_orders", "rules", "notify", "funded_cost", "risk_override", "min_pass", "auto_reopt", "monthly_goal", "setup_done", "auto_update"):
                if k in b:
                    s[k] = b[k]
            if "topstep_accounts" in b:             # only the choices; names/balances come from Topstep
                choice = {x["id"]: x for x in b["topstep_accounts"]}
                for acc in s["topstep_accounts"]:
                    c = choice.get(acc["id"], {})
                    for k in ("enabled", "type", "size", "risk"):
                        if k in c:
                            acc[k] = c[k]
            if sum(1 for x in s["topstep_accounts"] if x.get("enabled") and x.get("type") == "express") > 5:
                return self.send(400, json.dumps({"error": "Topstep allows at most 5 Express Funded accounts at once."}))
            s["mode"] = "paper" if s["venue"] == "paper" else ("live" if s["real_orders"] else "practice")
            ro = s.get("risk_override")
            if ro not in (None, ""):
                try:
                    ro = round(float(str(ro).replace("$", "").replace(",", "")))
                except ValueError:
                    return self.send(400, json.dumps({"error": "Enter risk per trade as a dollar amount, like 100."}))
                if not 10 <= ro <= 1000:
                    return self.send(400, json.dumps({"error": "Risk per trade has to be between $10 and $1,000."}))
                s["risk_override"] = ro
            else:
                s["risk_override"] = None
            try:
                s["min_pass"] = round(float(s.get("min_pass") or 75))
            except (TypeError, ValueError):
                return self.send(400, json.dumps({"error": "Enter the pass rate as a number, like 75."}))
            if not 50 <= s["min_pass"] <= 99:
                return self.send(400, json.dumps({"error": "Keep the pass rate floor between 50% and 99%."}))
            s["auto_reopt"] = bool(s.get("auto_reopt"))
            try:
                s["monthly_goal"] = round(float(str(s.get("monthly_goal") or 10000).replace("$", "").replace(",", "")))
            except ValueError:
                return self.send(400, json.dumps({"error": "Enter the monthly goal in dollars, like 10000."}))
            if not 500 <= s["monthly_goal"] <= 200000:
                return self.send(400, json.dumps({"error": "Keep the monthly goal between $500 and $200,000."}))
            if b.get("api_key"):
                s["api_key"] = b["api_key"]
            s["dry_run"] = s["mode"] == "practice"
            if s["remote_access"] and not s.get("owner"):
                return self.send(400, json.dumps({"error": "Create your Swing account first (username and password)."}))
            bind_before = load_settings()
            save_settings(s)
            if listening_remote(bind_before) != listening_remote(s):
                request_restart("phone access changed")       # listen on the network (or stop) right away
            changed = json.dumps({k: s.get(k) for k in TRADING}, sort_keys=True) != before
            if running("bot") and changed:          # apply trading changes right away
                stop_bot(False, remember=False)
                time.sleep(1)
                e2 = start_bot()
                err = "Saved and restarted the bot." if not e2 else f"Saved, but the bot couldn't restart: {e2}"
        elif self.path == "/api/topstep/connect":
            if not self.admin():
                return self.send(403, json.dumps({"error": "Connect your Topstep account from the computer."}))
            s = load_settings()
            s["username"] = (b.get("username") or s["username"]).strip()
            if b.get("api_key"):
                s["api_key"] = b["api_key"].strip()
            err = fetch_topstep_accounts(s)
            if not err:
                s = load_settings()
                s["venue"] = "topstep"
                s["mode"] = "live" if s["real_orders"] else "practice"
                save_settings(s)
        elif self.path == "/api/topstep/refresh":
            err = fetch_topstep_accounts(load_settings())
        elif self.path == "/api/topstep/disconnect":
            if running("bot"):
                err = "Stop the bot before disconnecting."
            else:
                s = load_settings()
                s.update({"api_key": "", "connected": False, "topstep_accounts": [], "venue": "paper",
                          "real_orders": False, "mode": "paper"})
                save_settings(s)
        elif self.path == "/api/payouts":
            s = load_settings()
            if b.get("remove") is not None:
                s["payouts"] = [p for i, p in enumerate(s["payouts"]) if i != int(b["remove"])]
            else:
                try:
                    amt = round(float(str(b.get("amount", "")).replace("$", "").replace(",", "")), 2)
                except ValueError:
                    return self.send(400, json.dumps({"error": "Enter the payout amount in dollars."}))
                if amt <= 0:
                    return self.send(400, json.dumps({"error": "Enter the payout amount in dollars."}))
                s["payouts"].append({"date": time.strftime("%Y-%m-%d"), "amount": amt})
            save_settings(s)
        elif self.path == "/api/update/check":
            msg = check_update(install=True)
            return self.send(200, json.dumps({"message": msg}))
        elif self.path == "/api/cloud/use":
            s = load_settings()
            u = (b.get("url") or "").strip().rstrip("/")
            if u:
                if not re.fullmatch(r"https?://[\w.\-]+(:\d+)?", u):
                    return self.send(400, json.dumps({"error": "Enter the address like http://100.72.165.2:8765"}))
                try:
                    import requests as rq
                    ok = rq.get(u + "/manifest.webmanifest", timeout=6).status_code == 200
                except Exception:
                    ok = False
                if not ok:
                    return self.send(400, json.dumps({"error": "Can't reach your cloud Swing at that address. Is Tailscale on and signed in on this computer?"}))
                if running("bot"):
                    stop_bot(False)                 # only the cloud trades
            s = load_settings()
            s["cloud_url"] = u + "/" if u else ""
            if u:
                s["autostart"] = False
            save_settings(s)
        elif self.path == "/api/notify/test":
            import notify as NT
            cfg = dict(load_settings()["notify"], enabled=True)
            if not NT.send(cfg, "Swing is connected", "Notifications are working. You'll get trade alerts and briefs here."):
                err = "Couldn't send. Check this computer's internet connection."
        elif self.path == "/api/paper/reset":
            if running("bot"):
                err = "Stop the bot before resetting the paper account."
            else:
                for f in ("paper_state.json", "bot_state.json"):
                    try:
                        os.remove(path(f))
                    except FileNotFoundError:
                        pass
        elif self.path == "/api/quit":
            self.send(200, "{}")
            if running("bot"):
                procs["bot"].terminate()
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        else:
            return self.send(404, "{}")
        ok = not err or err.startswith("Saved and")
        self.send(200 if ok else 400, json.dumps({"error": err} if err else {}))


def open_window(url):
    """Open Swing in its own app window (no tabs, no address bar, its own taskbar icon).
    Uses Microsoft Edge's app mode, which every Windows 10/11 PC has. Falls back to the browser."""
    if os.name == "nt":
        roots = [os.environ.get(k) for k in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")]
        for r in filter(None, roots):
            edge = os.path.join(r, "Microsoft", "Edge", "Application", "msedge.exe")
            if os.path.exists(edge):
                try:
                    subprocess.Popen([edge, f"--app={url}", "--window-size=1200,860",
                                      f"--user-data-dir={path('.window')}",   # its own profile: a separate app
                                      "--no-first-run", "--no-default-browser-check"],
                                     creationflags=subprocess.CREATE_NO_WINDOW)
                    return
                except OSError:
                    break
    elif sys.platform == "darwin":
        chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if os.path.exists(chrome):
            try:
                subprocess.Popen([chrome, f"--app={url}", f"--user-data-dir={path('.window')}"])
                return
            except OSError:
                pass
    webbrowser.open(url)

RESTART = {"why": None, "server": None}
RESTART_CODE = 3        # "Start Swing.bat" and the Pi service start Swing again when it exits with this

def request_restart(why):
    """Restart the app (the bot keeps its stops and targets at Topstep and resumes on its own)."""
    if RESTART["why"] or not RESTART["server"]:
        return
    RESTART["why"] = why
    threading.Timer(1.5, RESTART["server"].shutdown).start()

CODE_APP = ("app.py", "news.py", "notify.py", "paper.py")
CODE_BOT = ("topstep_bot.py", "strategies.py", "news.py", "notify.py", "paper.py")

def _code_watch():
    """When Claude updates Swing's files, use the new version right away: the bot restarts with new bot code,
    the app restarts itself with new app code. Waits while a backtest runs."""
    def stamp(files):
        return tuple(os.path.getmtime(path(f)) if os.path.exists(path(f)) else 0 for f in files)
    app0, bot0 = stamp(CODE_APP), stamp(CODE_BOT)
    while True:
        time.sleep(10)
        if running("backtest"):
            continue
        a, bt = stamp(CODE_APP), stamp(CODE_BOT)
        if a != app0:
            time.sleep(5)                       # let all the files finish copying
            print("Swing was updated: restarting with the new version.")
            request_restart("update")
            return
        if bt != bot0:
            time.sleep(5)
            bot0 = stamp(CODE_BOT)
            if running("bot"):
                stop_bot(False, remember=False)
                time.sleep(1)
                err = start_bot()
                print("Bot updated: restarted with the new version." if not err else f"Bot update: couldn't restart ({err})")

def fix_shortcuts():
    """Windows: make the Swing icons open Swing as its own app (not the old console/browser launcher)."""
    if os.name != "nt":
        return
    exe = os.environ.get("SWING_EXE")          # started from Swing.exe: the icons open Swing.exe
    if exe:
        target, args = exe, ""
    elif os.path.exists(path("Swing.vbs")):
        target, args = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "System32", "wscript.exe"), f'"{path("Swing.vbs")}"'
    else:
        return
    ps = ("$w=New-Object -ComObject WScript.Shell; "
          "foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){"
          "$p=$d+'\\Swing.lnk'; if(Test-Path $p){ if($w.CreateShortcut($p).TargetPath -match 'msedge'){ continue } }; "
          f"$s=$w.CreateShortcut($p); $s.TargetPath='{target}'; "
          f"$s.Arguments='{args}'; $s.WorkingDirectory='{APP_DIR}'; "
          f"$s.IconLocation='{path('icon.ico')}'; $s.Description='Swing'; $s.Save() }}")
    try:
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps], timeout=20,
                       capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
    except (OSError, subprocess.SubprocessError):
        pass

def main():
    threading.Thread(target=fix_shortcuts, daemon=True).start()
    s = load_settings()
    save_settings(s)
    host = "0.0.0.0" if listening_remote(s) else "127.0.0.1"
    url = f"http://127.0.0.1:{PORT}"
    server = None
    for attempt in range(40 if os.environ.get("SWING_RESTARTED") else 1):   # after an update the port can take a moment
        try:
            server = Server((host, PORT), Handler)
            break
        except OSError:
            time.sleep(3)
    if server is None:
        open_window(url)                # already running: just show it
        return
    threading.Thread(target=news_loop, daemon=True).start()
    def _watchdog():
        """If the bot should be running but stopped (internet drop, crash), bring it back, backing off up to 10 min."""
        wait = 60
        while True:
            time.sleep(wait)
            if load_settings().get("autostart") and not running("bot") and not running("backtest"):
                err = start_bot()
                print("Watchdog restarted the bot." if not err else f"Watchdog couldn't restart the bot: {err}")
                wait = min(wait * 2, 600)
            else:
                wait = 60
    threading.Thread(target=_watchdog, daemon=True).start()
    def _after_backtest():
        """When a backtest finishes while the bot runs, restart the bot so it trades the new results."""
        seen = None
        while True:
            time.sleep(5)
            p = procs["backtest"]
            if p is None or p is seen or p.poll() is None:
                continue
            seen = p
            if p.returncode == 0 and running("bot"):
                stop_bot(False, remember=False)
                time.sleep(1)
                err = start_bot()
                print("Backtest finished: restarted the bot with the new results." if not err
                      else f"Backtest finished, but the bot couldn't restart: {err}")
    threading.Thread(target=_after_backtest, daemon=True).start()
    def _reoptimize():
        """Keep the setups fresh without you doing anything: re-run the backtest every weekend, and on a weekday
        evening (market closed, 4-5:30 PM ET) when a setup got benched for losing live. The bot then restarts
        with the new picks, so benched setups get replaced by whatever tests best now."""
        from zoneinfo import ZoneInfo
        from datetime import datetime
        et = ZoneInfo("America/New_York")
        while True:
            time.sleep(300)
            try:
                s = load_settings()
                if not s.get("auto_reopt") or running("backtest"):
                    continue
                cfg = read_json("best_config.json", {}) or {}
                age = time.time() - (cfg.get("generated_ts") or os.path.getmtime(path("best_config.json"))
                                     if os.path.exists(path("best_config.json")) else 0)
                now = datetime.now(et)
                weekend = now.weekday() == 5 or (now.weekday() == 6 and now.hour < 16)
                evening = now.weekday() < 5 and (16, 0) <= (now.hour, now.minute) < (17, 30)
                benched = (read_json("status.json", {}) or {}).get("benched") or {}
                why = None
                if weekend and age > 5 * 86400:
                    why = "weekly refresh"
                elif evening and benched and age > 2 * 86400:
                    why = f"{len(benched)} setup(s) benched for losing live"
                if why:
                    err = start_backtest()
                    s["last_reopt"] = f"{now:%b %d %I:%M %p} ET ({why})"
                    save_settings(s)
                    print(f"Auto re-optimize: {why}" + (f" ({err})" if err else ""))
            except Exception as e:
                print(f"Auto re-optimize skipped: {e}")
    threading.Thread(target=_reoptimize, daemon=True).start()
    def _open():
        try:
            open_window(url)
        except Exception:
            pass
    if not s.get("allow_remote_admin") and not os.environ.get("SWING_RESTARTED"):   # no new tab after an update
        threading.Timer(0.8, _open).start()
    if s.get("autostart"):                       # it was running before a restart or power cut: resume
        def _resume():
            err = start_bot()
            print("Resumed the bot." if not err else f"Couldn't resume the bot: {err}")
        threading.Timer(5, _resume).start()
    print(f"Swing is open at {url}  (close this window or use Quit in the app to exit)")
    RESTART["server"] = server
    threading.Thread(target=_code_watch, daemon=True).start()
    threading.Thread(target=_auto_update, daemon=True).start()
    try:
        server.serve_forever()
    finally:
        if running("bot"):
            procs["bot"].terminate()
        server.server_close()
    if RESTART["why"]:
        sys.exit(RESTART_CODE)


if __name__ == "__main__":
    main()
