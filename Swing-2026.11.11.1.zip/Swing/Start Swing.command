#!/bin/bash
cd "$(dirname "$0")"
python3 -m pip install --quiet --disable-pip-version-check requests tzdata 2>/dev/null || python3 -m pip install --quiet --user requests tzdata
python3 app.py
