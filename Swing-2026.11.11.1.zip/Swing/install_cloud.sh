#!/bin/bash
# Swing: one-time setup on a cloud server (Ubuntu/Debian, e.g. Google Cloud's free e2-micro).
# Upload Swing.zip to the server, then run:   unzip -o Swing.zip && bash Swing/install_cloud.sh
#
# Note: Topstep's terms say trading must come from your own device and prohibit VPS/remote servers.
# Running Swing here means accepting that Topstep may close the accounts it trades.
set -e
cd "$(dirname "$0")"
DIR="$(pwd)"

echo "Installing what Swing needs (2-3 minutes)..."
sudo apt-get update -qq
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3 python3-requests tzdata unzip curl >/dev/null

# Small free servers have 1 GB of memory: add 2 GB of swap so the backtest can't run out
if [ "$(free -m | awk '/Mem:/{print $2}')" -lt 2000 ] && ! swapon --show | grep -q swapfile; then
  sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile >/dev/null && sudo swapon /swapfile
  grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
fi

# Your Swing account: you'll sign in with this on your phone and computer.
SW_USER="${SWING_USER:-}"
while ! [[ "$SW_USER" =~ ^[A-Za-z0-9_.@-]{3,40}$ ]]; do
  read -rp "Pick a Swing username (3+ letters or numbers, no spaces): " SW_USER
done
SW_PASS="${SWING_PASS:-}"
while [ "${#SW_PASS}" -lt 8 ]; do
  read -rsp "Pick a Swing password (8+ characters): " SW_PASS; echo
  read -rsp "Type it again: " P2; echo
  [ "$SW_PASS" == "$P2" ] || { echo "They didn't match. Try again."; SW_PASS=""; }
done
SW_USER="$SW_USER" SW_PASS="$SW_PASS" python3 - << 'PY'
import json, os, sys
sys.path.insert(0, ".")
from app import make_owner
s = json.load(open("settings.json")) if os.path.exists("settings.json") else {}
s.update({"remote_access": True, "allow_remote_admin": True, "host": "cloud", "pin": "",
          "owner": make_owner(os.environ["SW_USER"], os.environ["SW_PASS"])})
json.dump(s, open("settings.json", "w"), indent=2)
PY
unset SW_PASS P2

# Private link between the server and your phone. Swing's port stays closed to the internet.
if ! command -v tailscale >/dev/null 2>&1; then
  curl -fsSL https://tailscale.com/install.sh | sh
fi
echo ""
echo "Open the link below and sign in with the SAME account you use in the Tailscale app on your iPhone:"
sudo tailscale up --hostname=swing-cloud
TSIP=$(tailscale ip -4 | head -1)
# Secure https:// address (lets the phone app use everything, like notifications). Needs HTTPS turned on
# for your Tailscale network; if it isn't, Swing still works at the http:// address.
HTTPS_URL=""
if timeout 40 sudo tailscale serve --bg 8765 >/dev/null 2>&1; then
  HTTPS_URL=$(tailscale status --json | python3 -c "import json,sys;print('https://'+json.load(sys.stdin)['Self']['DNSName'].rstrip('.'))" 2>/dev/null)
fi

RUNAS="$(id -un)"
sudo tee /etc/systemd/system/swing.service >/dev/null << UNIT
[Unit]
Description=Swing trading app
After=network-online.target tailscaled.service
Wants=network-online.target

[Service]
User=$RUNAS
WorkingDirectory=$DIR
ExecStart=/usr/bin/python3 $DIR/app.py
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable swing >/dev/null 2>&1
sudo systemctl restart swing
sleep 3

echo ""
if systemctl is-active --quiet swing; then
  echo "Done. Swing runs 24/7 on this server and restarts by itself after reboots and updates."
else
  echo "Swing didn't start. Run:  sudo journalctl -u swing -n 50   and send the output to Claude."
fi
echo ""
if [ -n "$HTTPS_URL" ]; then
  echo "On your iPhone (Tailscale app on):  $HTTPS_URL"
else
  echo "On your iPhone (Tailscale app on):  http://$TSIP:8765"
  echo "(For a secure https address: turn on HTTPS at login.tailscale.com/admin/dns, then run: sudo tailscale serve --bg 8765)"
fi
echo "Sign in with the username and password you just picked."
echo "In Safari tap Share, then Add to Home Screen."
echo "Then in Swing: Settings -> connect Topstep, and on the Edge tab press Run backtest."
echo "Quit Swing on your PC so only one copy trades."
