"""
Free news for the bot.

1. Economic calendar (Forex Factory's free weekly feed): every US CPI, jobs report,
   Fed decision, etc., with exact times. The bot pauses new trades around them and
   can close open trades just before the big ones.
2. Headlines (free RSS from CNBC, MarketWatch and the Federal Reserve) with keyword
   alerts like "Powell" or "tariff". Shown in the app; can optionally pause trading.
3. Volatility shock check: if a 5-minute candle is 3x bigger than normal, something
   happened (tweet, headline, surprise). Pause that market for 30 minutes.
"""
import json, os, re, time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from zoneinfo import ZoneInfo
import requests

ET_TZ = ZoneInfo("America/New_York")
CAL_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
FEEDS = [("CNBC", "https://www.cnbc.com/id/100003114/device/rss/rss.html"),
         ("MarketWatch", "https://feeds.content.dowjones.io/public/rss/mw_topstories"),
         ("Federal Reserve", "https://www.federalreserve.gov/feeds/press_all.xml")]
DEFAULT_KEYWORDS = ["Fed", "Powell", "FOMC", "rate cut", "rate hike", "CPI", "inflation", "jobs report", "payrolls",
                    "tariff", "recession", "shutdown", "war", "sanctions", "Trump", "default"]
DEFAULTS = {"pause": True, "flatten_before": True, "medium": False, "shock": True, "headline_pause": False,
            "keywords": DEFAULT_KEYWORDS}
FALLBACK_TIMES = [(8, 30), (10, 0), (14, 0)]     # used only if the calendar can't be downloaded
SHOCK_MULT, SHOCK_BARS = 3.0, 6                  # candle > 3x normal range -> pause 6 bars (30 min)
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Swing/1.0"}
CACHE = "news_cache.json"


def settings(raw=None):
    s = dict(DEFAULTS)
    s.update({k: v for k, v in (raw or {}).items() if k in DEFAULTS})
    if isinstance(s["keywords"], str):
        s["keywords"] = [k.strip() for k in s["keywords"].split(",") if k.strip()]
    return s

def _load():
    try:
        with open(CACHE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def _save(d):
    try:
        with open(CACHE + ".tmp", "w") as f:
            json.dump(d, f)
        os.replace(CACHE + ".tmp", CACHE)
    except OSError:
        pass


# ---------------- economic calendar ----------------
def calendar():
    """US Medium/High impact events this week. Returns (events, ok). Refreshes every 6 hours."""
    d = _load()
    c = d.get("calendar")
    if c and time.time() - c["ts"] < 6 * 3600:
        return c["events"], c["ok"]
    try:
        r = requests.get(CAL_URL, headers=UA, timeout=15)
        r.raise_for_status()
        events = []
        for e in r.json():
            if e.get("country") != "USD" or e.get("impact") not in ("High", "Medium"):
                continue
            t = datetime.fromisoformat(e["date"]).astimezone(ET_TZ)
            if t.hour == 0 and t.minute == 0:            # "all day" / tentative items
                continue
            events.append({"title": e.get("title", ""), "time": t.isoformat(), "impact": e["impact"],
                           "forecast": e.get("forecast", ""), "previous": e.get("previous", "")})
        events.sort(key=lambda e: e["time"])
        d["calendar"] = {"ts": time.time(), "events": events, "ok": True}
    except Exception:
        old = c["events"] if c else []
        d["calendar"] = {"ts": time.time() - 5.5 * 3600, "events": old, "ok": bool(old)}   # retry in 30 min
    _save(d)
    return d["calendar"]["events"], d["calendar"]["ok"]

def is_major(e):
    t = e["title"].lower()
    return any(k in t for k in ("fomc", "federal funds", "fed chair", "powell", "press conference", "non-farm"))

def window(e):
    """Minutes before / after an event when no new trades open."""
    if is_major(e):
        return 30, 60
    return (10, 15) if e["impact"] == "High" else (5, 10)

def news_pause(now, events, cfg, ok):
    """(reason, until) if new trades should wait because of scheduled news, else (None, None)."""
    if not cfg["pause"]:
        return None, None
    if not ok:                                   # calendar unavailable: fall back to fixed times
        for h, m in FALLBACK_TIMES:
            t = now.replace(hour=h, minute=m, second=0, microsecond=0)
            if t - timedelta(minutes=5) <= now <= t + timedelta(minutes=5):
                return "possible news release (calendar unavailable)", t + timedelta(minutes=5)
        return None, None
    for e in events:
        if e["impact"] != "High" and not cfg["medium"]:
            continue
        t = datetime.fromisoformat(e["time"])
        b, a = window(e)
        if t - timedelta(minutes=b) <= now <= t + timedelta(minutes=a):
            return e["title"], t + timedelta(minutes=a)
    return None, None

def oil_pause(now, events, cfg):
    """Weekly crude inventory report (Wednesdays 10:30 ET) moves oil hard: pause MCL around it."""
    if not cfg["pause"]:
        return None
    for e in events:
        if "crude" in e["title"].lower():
            t = datetime.fromisoformat(e["time"])
            if t - timedelta(minutes=10) <= now <= t + timedelta(minutes=15):
                return e["title"]
    return None

def flatten_due(now, events, cfg, minutes=2):
    """The High-impact event starting within `minutes`, if open trades should be closed first."""
    if not cfg["flatten_before"]:
        return None
    for e in events:
        if e["impact"] == "High":
            t = datetime.fromisoformat(e["time"])
            if t - timedelta(minutes=minutes) <= now < t:
                return e
    return None

def upcoming(now, events, cfg, n=8):
    out = []
    for e in events:
        t = datetime.fromisoformat(e["time"])
        if t >= now - timedelta(minutes=60) and (e["impact"] == "High" or cfg["medium"]):
            out.append(dict(e, major=is_major(e)))
    return out[:n]


# ---------------- headlines ----------------
def _match(title, keywords):
    hits = [k for k in keywords if re.search(r"\b" + re.escape(k) + r"(s|es)?\b", title, re.I)]
    return hits

def headlines(keywords=None, n=30):
    """Latest headlines from free RSS feeds, refreshed every 5 minutes, with keyword hits."""
    keywords = keywords or DEFAULT_KEYWORDS
    d = _load()
    h = d.get("headlines")
    if not (h and time.time() - h["ts"] < 300):
        items = []
        for source, url in FEEDS:
            try:
                r = requests.get(url, headers=UA, timeout=10)
                r.raise_for_status()
                root = ET.fromstring(r.content)
                for it in root.iter("item"):
                    title = (it.findtext("title") or "").strip()
                    if not title:
                        continue
                    try:
                        pub = parsedate_to_datetime(it.findtext("pubDate") or "").astimezone(timezone.utc).isoformat()
                    except (TypeError, ValueError):
                        pub = datetime.now(timezone.utc).isoformat()
                    items.append({"source": source, "title": title, "link": (it.findtext("link") or "").strip(),
                                  "time": pub})
            except Exception:
                continue
        items.sort(key=lambda x: x["time"], reverse=True)
        h = {"ts": time.time(), "items": items[:80] or (h["items"] if h else [])}
        d["headlines"] = h
        _save(d)
    return [dict(i, hits=_match(i["title"], keywords)) for i in h["items"][:n]]

def headline_alert(items, minutes=10):
    """A keyword headline published in the last `minutes`, if any."""
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=minutes)
    for i in items:
        if i["hits"] and datetime.fromisoformat(i["time"]) >= cutoff:
            return i
    return None


# ---------------- volatility shock ----------------
def shock(bars, atr_values, mult=SHOCK_MULT):
    """True if the latest completed candle's range is `mult` times the normal (ATR) range."""
    if len(bars) < 20 or not atr_values or atr_values[-2] <= 0:
        return False
    b = bars[-1]
    return (b["h"] - b["l"]) > mult * atr_values[-2]
