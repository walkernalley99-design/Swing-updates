' Swing: opens like a normal app. No black window; Swing shows up in its own window.
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
dir = fs.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
url = "http://127.0.0.1:8765/"

' Already running in the background? Then just show its window.
running = False
On Error Resume Next
Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
http.setTimeouts 1500, 1500, 1500, 1500
http.Open "GET", url & "manifest.webmanifest", False
http.Send
If Err.Number = 0 Then If http.Status = 200 Then running = True
Err.Clear
On Error GoTo 0

If running Then
  On Error Resume Next
  sh.Run "msedge.exe --app=" & url & " --window-size=1200,860 --no-first-run --no-default-browser-check --user-data-dir=""" & dir & "\.window""", 1, False
  If Err.Number <> 0 Then sh.Run url, 1, False
  On Error GoTo 0
Else
  sh.Run "cmd /c """ & dir & "\Start Swing.bat"" hidden", 0, False
End If
