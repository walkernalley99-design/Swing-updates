"""
Phone notifications for Swing through ntfy (free, no account): install the ntfy app
on your phone, subscribe to your Swing topic, and you get trade alerts, a morning
brief, an evening recap and a weekly report, even away from home.
The topic name is a long random string so nobody else can guess it.
"""
import json, os, secrets, time
import requests

BRIEFS = "briefs.json"
DEFAULTS = {"enabled": False, "topic": "", "trades": True, "briefs": True, "weekly": True}


def settings(raw=None):
    s = dict(DEFAULTS)
    s.update({k: v for k, v in (raw or {}).items() if k in DEFAULTS})
    if not s["topic"]:
        s["topic"] = "swing-" + secrets.token_hex(8)
    return s

def send(cfg, title, body, tags="chart_with_upwards_trend", priority=3):
    """Push to the phone. Never raises: a failed notification must not stop trading."""
    if not cfg.get("enabled") or not cfg.get("topic"):
        return False
    try:
        requests.post(f"https://ntfy.sh/{cfg['topic']}", data=body.encode("utf-8"), timeout=8,
                      headers={"Title": title.encode("ascii", "ignore").decode() or "Swing",
                               "Tags": tags, "Priority": str(priority)})
        return True
    except Exception:
        return False

def save_brief(kind, title, body):
    """Keep the last 30 briefs so the app can show them too."""
    try:
        with open(BRIEFS) as f:
            items = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        items = []
    items.append({"ts": time.time(), "kind": kind, "title": title, "body": body})
    try:
        with open(BRIEFS + ".tmp", "w") as f:
            json.dump(items[-30:], f)
        os.replace(BRIEFS + ".tmp", BRIEFS)
    except OSError:
        pass
