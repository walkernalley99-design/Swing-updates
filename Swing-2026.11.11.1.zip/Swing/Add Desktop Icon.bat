@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))){ $s=$w.CreateShortcut($d+'\Swing.lnk'); $s.TargetPath=$env:WINDIR+'\System32\wscript.exe'; $s.Arguments='"%~dp0Swing.vbs"'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0icon.ico'; $s.Description='Swing'; $s.Save() }"
echo.
echo Done. Swing is on your desktop and in the Start menu.
echo Double-click it and Swing opens in its own window, like any app.
echo Tip: right-click Swing in the Start menu and choose "Pin to taskbar".
pause
