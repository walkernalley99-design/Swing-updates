SWING - QUICK START

1. Install Python 3.10 or newer from python.org
   (Windows: tick "Add Python to PATH" during install)
2. Unzip this folder somewhere you'll keep it (like Documents).
3. Windows: double-click "Start Swing.bat"
   Mac: right-click "Start Swing.command" > Open
   Tip: right-click it > Send to > Desktop for a shortcut
4. The app opens in your browser.

NO TOPSTEP ACCOUNT? Use Paper mode (the default):
   - Strategies > Run backtest (uses 60 days of free data)
   - Today > Start paper trading
   It trades real NQ, ES and gold prices (about 10 min delayed) on a
   virtual $50,000 Combine with Topstep's rules. Nothing real is traded.

WITH TOPSTEP (one or many accounts):
   - Settings > Trade on > Topstep
   - Enter your TopstepX username and API key, tap Connect
     (API key: ProjectX dashboard > Subscriptions > API Access, then TopstepX > Settings > API)
   - Your accounts appear automatically. Switch on the ones to trade.
   - Leave "Place real orders" off for the first week (watch only), then turn it on.
   - Re-run the backtest: a Topstep login gives a full year of data

Keep the computer on and awake while the bot runs.
To quit: Settings > Quit app.

ON YOUR PHONE: Settings > Phone access > on, set a passcode, restart Swing,
then open the address it shows on your phone and Add to Home Screen.

NOTIFICATIONS (trade alerts + daily briefs, even away from home):
   Install the free "ntfy" app, subscribe to the topic shown in
   Settings > Phone notifications, turn it on and tap Send test.

RASPBERRY PI (runs 24/7 so your computer can be off):
   See the guide in the chat. Short version: copy Swing.zip to the Pi, then run
   python3 -m zipfile -e Swing.zip . && bash Swing/install_pi.sh
   Swing then starts by itself whenever the Pi has power, restarts if it crashes,
   and resumes trading after a power cut.

RUN SWING ON A CLOUD SERVER (PC can be off)
Topstep's terms prohibit VPS/remote servers; running Swing in the cloud risks the accounts it trades.
1. Make a free Google Cloud e2-micro VM (Ubuntu 24.04, region us-central1).
2. Click SSH, then Upload file -> Swing.zip.
3. Run:  unzip -o Swing.zip && bash Swing/install_cloud.sh
4. On your iPhone: Tailscale app on, open the address it prints, Add to Home Screen.
5. Quit Swing on your PC so only one copy trades.
Updates: Settings -> Update Swing -> pick the new Swing.zip.
