#!/bin/bash
# Swing: one-time setup on a Raspberry Pi (or any always-on Linux box).
# Run once:  bash Swing/install_pi.sh
set -e
cd "$(dirname "$0")"
DIR="$(pwd)"

echo "Installing what Swing needs (takes a minute)..."
sudo apt-get update -qq
sudo apt-get install -y -qq python3 python3-requests tzdata >/dev/null

while true; do
  read -rp "Pick a passcode for opening Swing on your phone (at least 4 digits): " PIN
  [[ "$PIN" =~ ^[0-9]{4,}$ ]] && break
  echo "Use at least 4 digits, numbers only."
done

python3 - "$PIN" << 'PY'
import json, os, sys
s = json.load(open("settings.json")) if os.path.exists("settings.json") else {}
s.update({"remote_access": True, "pin": sys.argv[1], "allow_remote_admin": True})
json.dump(s, open("settings.json", "w"), indent=2)
PY

sudo tee /etc/systemd/system/swing.service >/dev/null << UNIT
[Unit]
Description=Swing trading app
After=network-online.target
Wants=network-online.target

[Service]
User=$USER
WorkingDirectory=$DIR
ExecStart=/usr/bin/python3 $DIR/app.py
Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable swing >/dev/null 2>&1
sudo systemctl restart swing

# Open Swing on your phone from anywhere (not just home Wi-Fi), privately, with Tailscale (free).
# Only your phone talks to the Pi through it. Trades still go out over your normal home internet.
if ! command -v tailscale >/dev/null 2>&1; then
  read -rp "Set up phone access from anywhere with Tailscale (free)? [Y/n] " T
  if [[ ! "$T" =~ ^[Nn] ]]; then
    curl -fsSL https://tailscale.com/install.sh | sh
  fi
fi
if command -v tailscale >/dev/null 2>&1; then
  echo "Sign in to Tailscale with the link below (use the same account as the Tailscale app on your iPhone):"
  sudo tailscale up || true
fi
TSIP=$(tailscale ip -4 2>/dev/null | head -1)

IP=$(hostname -I | awk '{print $1}')
echo ""
echo "Done. Swing is running and starts by itself whenever the Pi has power."
echo "Open it on your phone or computer (same Wi-Fi):"
echo "   http://$IP:8765"
echo "   or http://$(hostname).local:8765"
if [ -n "$TSIP" ]; then
  echo "From anywhere (Tailscale on in your iPhone):"
  echo "   http://$TSIP:8765"
fi
echo "In Safari tap Share, then Add to Home Screen. You can unplug the keyboard and screen now."
echo "Turn your PC's Swing off (Quit app) so only the Pi trades."
