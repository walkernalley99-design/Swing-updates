@echo off
title Swing
cd /d "%~dp0"
set "PY="
python --version >nul 2>nul && set "PY=python"
if not defined PY py --version >nul 2>nul && set "PY=py"
if not defined PY (
  echo Python was not found. Install it from python.org and tick "Add Python to PATH".
  if /i "%~1"=="hidden" (
    msg * "Swing: Python was not found. Install it from python.org and tick Add Python to PATH."
    exit /b
  )
  pause
  exit /b
)
echo Starting Swing...
%PY% -m pip install --quiet --disable-pip-version-check requests tzdata
if errorlevel 1 %PY% -m pip install --quiet --disable-pip-version-check --user requests tzdata
:run
if /i "%~1"=="hidden" (
  %PY% app.py > app_output.log 2>&1
) else (
  %PY% app.py
)
if "%errorlevel%"=="3" (
  echo Swing was updated. Starting the new version...
  set "SWING_RESTARTED=1"
  timeout /t 2 /nobreak >nul
  goto run
)
if errorlevel 1 (
  if /i "%~1"=="hidden" (
    start "" notepad "%~dp0app_output.log"
    exit /b
  )
  echo.
  echo Swing stopped with an error. Take a screenshot of this window and send it to Claude.
  pause
)
