"""
Backtester + optimizer for topstep_bot.py

What it does:
  1. Loads 5-min history for MNQ, MES, MGC (TopstepX API, or CSVs you put in data/)
  2. Tests every strategy + setting combo with slippage and fees included
  3. Walk-forward: picks settings on the first 70% of the data, then checks them on
     the last 30% they never saw. Strategies that only worked on old data get rejected.
     (This is what catches "too perfect" backtests like the ones in those screenshots.)
  4. Monte Carlo: simulates thousands of Topstep 50K Combines to find the per-trade
     risk with the HIGHEST PASS RATE
  5. Writes best_config.json (the bot reads it) and backtest_report.txt

Usage:
  python backtest.py            # uses cached data if present
  python backtest.py --refresh  # re-download from the API

Your own data: put data/MNQ.csv (etc.) with columns time,open,high,low,close
(time = ISO timestamp or unix seconds, 5-minute bars; a volume column is optional
but helps the Silver Bullet volume filter). It's used instead of the API.
"""
import os, sys, csv, json, time, random, itertools, statistics
from datetime import datetime, timedelta, timezone, date
import requests
from strategies import parse_bars, trade_day, exit_time, STRATEGIES, PAIRS, KILLZONES, MACROS
from news import SHOCK_MULT, SHOCK_BARS

API = "https://api.topstepx.com/api"
MARKETS = ["MNQ", "MES", "MGC", "MCL", "MYM", "M2K", "SIL", "M6E", "M6B", "MHG"]
SPECS = {"MNQ": {"tick": 0.25, "pv": 2.0}, "MES": {"tick": 0.25, "pv": 5.0}, "MGC": {"tick": 0.1, "pv": 10.0},
         "MCL": {"tick": 0.01, "pv": 100.0},
         # more Topstep-permitted micros. Each must pass the same checks; most will be switched off.
         "MYM": {"tick": 1.0, "pv": 0.5}, "M2K": {"tick": 0.1, "pv": 5.0}, "SIL": {"tick": 0.005, "pv": 1000.0},
         "M6E": {"tick": 0.0001, "pv": 12500.0}, "M6B": {"tick": 0.0001, "pv": 6250.0},
         "MHG": {"tick": 0.0005, "pv": 2500.0}}
MONTHS_OF_HISTORY = 12
SLIP_TICKS = 1            # slippage on market entries and stop exits
FEE_RT = 1.50             # $ per contract round trip; check your Topstep fee schedule
MAX_CONTRACTS = 5         # must match MAX_CONTRACTS_PER_TRADE in the bot
BASE_RISK = 100           # $ risk per trade used while choosing strategies
RISK_LEVELS = [50, 75, 100, 125, 150, 175, 200]                      # Combines
EXPRESS_RISK_LEVELS = [50, 75, 100, 125, 150, 175, 200, 250, 300, 400]  # funded accounts
MIN_PASS = 75.0            # Combine sizes must pass at least this often (Settings can change it)
MAX_FUNDED_BREACH = 10.0   # % chance of losing a funded account in 3 months that Swing will accept
IN_SAMPLE = 0.70
COMBINE = {"target": 3000, "mll": 2000, "consistency": 0.50, "max_days": 90, "runs": 5000}
DATA_DIR = "data"
SHORT_DATA = set()   # markets tested on only ~60 days of free data

RTH = [[9, 45], [15, 30]]
OVERNIGHT = {"asia_trend", "eu_pullback", "eu_grail"}
# "partial": True = take half at 1R, move stop to break-even, let the runner go (from your notes)
GRIDS = {
    # --- built from your Notion notes ---
    "silver_bullet": {"windows": [KILLZONES, MACROS], "lookback": [24, 48], "sweep_bars": [6],
                      "stop_buf": [0.1], "rr": [2.0], "htf_ema": [0, 240], "vol_mult": [0, 1.3],
                      "partial": [False, True]},
    "vwap_trama":    {"trama_len": [50, 99], "window": [RTH], "rsi_mode": ["none", "extreme"],
                      "stop_atr": [1.5], "rr": [1.5, 2.5], "htf_ema": [0, 240], "partial": [False, True]},
    "smt":           {"lookback": [24, 48], "confirm_bars": [6], "windows": [KILLZONES, MACROS],
                      "stop_buf": [0.1], "rr": [2.0, 3.0], "partial": [False, True]},
    # --- models from your Notion screenshots (Blake's rules: no EQH/EQL against, TP 1:1 + runner) ---
    "venom":     {"lookback": [24, 48], "windows": [KILLZONES, MACROS], "max_below": [6], "stop_buf": [0.1],
                  "target": ["rr", "liq"], "rr": [2.0], "no_eq": [True], "partial": [True]},
    "hourly_sb": {"sessions": [[[2, 0], [9, 0], [13, 0]], [[9, 0]]], "stop_buf": [0.1], "target": ["rr", "liq"],
                  "rr": [2.0, 2.5], "no_eq": [False, True], "partial": [True]},
    "pdi":       {"lookback": [24, 48], "max_manip": [12], "max_dist": [0.5, 1.0], "windows": [KILLZONES, MACROS],
                  "stop_buf": [0.1], "rr": [2.0], "no_eq": [True], "partial": [True]},
    "shulk":     {"lookback": [24, 48], "sweep_bars": [12], "ob_bars": [6], "windows": [KILLZONES, MACROS],
                  "stop_buf": [0.0], "rr": [2.0, 2.5], "no_eq": [True], "partial": [True]},
    # --- general strategies ---
    "trend":    {"fast": [9, 13], "slow": [21, 34], "stop_atr": [1.5, 2.0], "rr": [1.5, 2.0], "window": [RTH]},
    "pullback": {"trend": [100, 200], "rsi_lo": [5, 10], "stop_atr": [1.0, 1.5], "rr": [1.0, 1.5], "window": [RTH]},
    # range_min 60 = initial balance (first hour). nr7 = Toby Crabel's narrow-range filter.
    "orb":      {"range_start": [[9, 30]], "range_min": [15, 30, 60], "entry_end": [[11, 30]],
                 "stop_frac": [0.5, 1.0], "rr": [1.0, 1.5, 2.0], "nr7": [False, True]},
    # --- mean reversion: snap back after a 2+ standard deviation stretch (window 60 = 20 x 15-min) ---
    "snapback":   {"window": [60, 36], "z": [2.0, 2.5], "min_rr": [1.0], "window_time": [RTH], "htf_ema": [0, 240]},
    # --- public research and classic books ---
    "imom":     {"sig_time": [[14, 55], [15, 15]], "min_atr": [0, 1.0], "stop_atr": [1.5, 2.5], "rr": [3.0]},
    "volbrk":   {"k": [0.3, 0.5], "stop_atr": [1.0, 1.5], "rr": [1.5, 2.5], "window": [[[9, 35], [14, 0]]]},
    "vwapband": {"z": [2.0, 2.5], "min_rr": [1.0], "window": [RTH], "htf_ema": [0, 240]},
    "onsweep":  {"max_back": [6, 12], "target": ["mid", "rr"], "rr": [2.0], "stop_buf": [0.1],
                 "window": [[[9, 30], [11, 30]]]},
    "squeeze":  {"min_sq": [6, 12], "stop_atr": [1.5, 2.0], "rr": [1.5, 2.5], "window": [RTH]},
    # --- other well-known rule-based traders ---
    "holy_grail": {"adx_min": [25, 30], "window": [RTH], "rr": [1.5, 2.0], "partial": [False, True]},
    "gap_fill":   {"min_gap": [0.1], "max_gap": [0.4, 0.7], "min_rr": [1.0], "exit": [[11, 30]]},
    "pdhl":       {"windows": [KILLZONES, MACROS, [[[9, 30], [15, 30]]]], "target": ["mid", "rr"], "rr": [2.0],
                   "partial": [True]},
    # Overnight models. The first batch (Asia/London breakouts, sweeps, fades, Europe drift) lost live and was
    # retired. These replacements passed walk-forward on real Aug-Oct 2026 data (gold Asia trend: profitable
    # every month and with 2 ticks worse fills). They must clear a stricter bar below, then trade on paper
    # in the live bot until they prove themselves.
    "asia_trend":  {"fast": [9, 13], "slow": [21, 34], "stop_atr": [1.5, 2.0], "rr": [1.5, 2.0],
                    "window": [[[19, 0], [1, 0]]], "exit": [[2, 30]]},
    "eu_pullback": {"trend": [100, 200], "rsi_lo": [5, 10], "stop_atr": [1.0, 1.5], "rr": [1.0, 1.5],
                    "window": [[[3, 0], [8, 30]]], "exit": [[9, 25]]},
    "eu_grail":    {"adx_min": [25, 30], "window": [[[3, 0], [8, 30]]], "rr": [1.5, 2.0], "partial": [False, True],
                    "exit": [[9, 25]]},
}

MONTH_CODE = "FGHJKMNQUVXZ"
CYCLE = {"MNQ": "HMUZ", "MES": "HMUZ", "MGC": "GJMQVZ", "MCL": "FGHJKMNQUVXZ", "MYM": "HMUZ", "M2K": "HMUZ",
         "SIL": "HKNUZ", "M6E": "HMUZ", "M6B": "HMUZ", "MHG": "HKNUZ"}


# ---------------- data ----------------
class PX:
    def __init__(self):
        user, key = os.environ.get("PX_USERNAME"), os.environ.get("PX_API_KEY")
        if not user or not key:
            raise SystemExit("Set PX_USERNAME and PX_API_KEY, or put CSV files in data/")
        self.s = requests.Session()
        r = self.s.post(f"{API}/Auth/loginKey", json={"userName": user, "apiKey": key}, timeout=15).json()
        if not r.get("success"):
            raise SystemExit(f"Login failed: {r}")
        self.s.headers["Authorization"] = f"Bearer {r['token']}"

    def post(self, path, body):
        r = self.s.post(f"{API}/{path}", json=body, timeout=30)
        r.raise_for_status()
        d = r.json()
        if d.get("success") is False:
            raise RuntimeError(f"{path}: {d}")
        return d

def roll_date(sym, code):
    m, y = MONTH_CODE.index(code[0]) + 1, 2000 + int(code[1:])
    if sym == "MCL":                       # crude expires around the 20th of the month before
        m -= 1
        if m == 0:
            m, y = 12, y - 1
        return date(y, m, 12)
    if sym in ("MGC", "SIL", "MHG"):       # metals roll late in the month before
        m -= 1
        if m == 0:
            m, y = 12, y - 1
        return date(y, m, 25)
    return date(y, m, 8)                   # index futures roll ~a week before expiry

def contract_codes(sym, current, months):
    m, y = MONTH_CODE.index(current[0]) + 1, 2000 + int(current[1:])
    codes = []
    for k in range(months + 4):
        mm, yy = m - k, y
        while mm <= 0:
            mm, yy = mm + 12, yy - 1
        if MONTH_CODE[mm - 1] in CYCLE[sym]:
            codes.append(f"{MONTH_CODE[mm - 1]}{yy % 100:02d}")
    return list(reversed(codes))

def fetch_api(px, sym):
    cs = [c for c in px.post("Contract/search", {"searchText": sym, "live": False}).get("contracts", [])
          if f".{sym}." in c["id"]]
    cur = next((c for c in cs if c.get("activeContract")), cs[0] if cs else None)
    if not cur:
        raise RuntimeError(f"No contract found for {sym}")
    prefix, code = cur["id"].rsplit(".", 1)
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=30 * MONTHS_OF_HISTORY)
    out, prev_roll = [], None
    for cd in contract_codes(sym, code, MONTHS_OF_HISTORY):
        roll = date.max if cd == code else roll_date(sym, cd)
        if roll != date.max and roll < start.date():
            prev_roll = roll
            continue
        c_start = max(start, datetime.combine(prev_roll, datetime.min.time(), timezone.utc) - timedelta(days=3)) \
            if prev_roll else start
        c_end = end if roll == date.max else min(end, datetime.combine(roll, datetime.min.time(), timezone.utc) + timedelta(days=1))
        raw, t0 = [], c_start
        while t0 < c_end:
            t1 = min(t0 + timedelta(days=20), c_end)
            try:
                d = px.post("History/retrieveBars", {
                    "contractId": f"{prefix}.{cd}", "live": False, "startTime": t0.isoformat(),
                    "endTime": t1.isoformat(), "unit": 2, "unitNumber": 5, "limit": 20000,
                    "includePartialBar": False})
                raw += d.get("bars", [])
            except Exception as e:
                print(f"  {sym} {cd}: no data ({e})")
                break
            t0 = t1
            time.sleep(0.3)
        keep = [b for b in parse_bars(raw)
                if (prev_roll is None or trade_day(b["dt"]) >= prev_roll) and trade_day(b["dt"]) < roll]
        print(f"  {sym} {cd}: {len(keep)} bars")
        out += keep
        if roll != date.max:
            prev_roll = roll
    seen, bars = set(), []
    for b in sorted(out, key=lambda b: b["dt"]):
        if b["dt"] not in seen:
            seen.add(b["dt"])
            bars.append(b)
    return bars

def load_csv(path):
    rows = []
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            r = {k.strip().lower(): v for k, v in r.items() if k}
            rows.append({"t": r.get("time") or r.get("t") or r.get("datetime"),
                         "o": r.get("open", r.get("o")), "h": r.get("high", r.get("h")),
                         "l": r.get("low", r.get("l")), "c": r.get("close", r.get("c")),
                         "v": r.get("volume", r.get("v")) or 0})
    return parse_bars(rows)

def save_cache(path, bars):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["time", "open", "high", "low", "close", "volume"])
        for b in bars:
            w.writerow([b["dt"].isoformat(), b["o"], b["h"], b["l"], b["c"], b["v"]])

def get_data(sym, refresh, px_holder):
    user_csv, cache = os.path.join(DATA_DIR, f"{sym}.csv"), os.path.join(DATA_DIR, f"{sym}_api.csv")
    if os.path.exists(user_csv):
        print(f"{sym}: using {user_csv}")
        return load_csv(user_csv)
    ycache = os.path.join(DATA_DIR, f"{sym}_yahoo.csv")
    if os.path.exists(ycache) and not os.environ.get("PX_API_KEY"):
        # The free feed only gives the last 60 days, so Swing keeps everything it has ever downloaded
        # and adds the new days each run. The history (and how much the tests can be trusted) grows over time.
        old = load_csv(ycache)
        fresh = time.time() - os.path.getmtime(ycache) < 20 * 3600
        if not fresh or refresh:
            try:
                from paper import yahoo_bars, FEED
                import requests as rq
                sess = rq.Session()
                sess.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                new = parse_bars(yahoo_bars(sess, FEED[sym][0], rng="60d"))
                merged = {b["dt"].timestamp(): b for b in old}
                merged.update({b["dt"].timestamp(): b for b in new})
                old = [merged[k] for k in sorted(merged)]
                save_cache(ycache, old)
                print(f"{sym}: added the latest free data, {len({b['dt'].date() for b in old})} days saved so far")
            except Exception as e:
                print(f"{sym}: couldn't download new data ({e}), using what's saved")
        else:
            print(f"{sym}: using saved free data from today")
        if len({b["dt"].date() for b in old}) < 100:
            SHORT_DATA.add(sym)
        return old
    if os.path.exists(cache) and not refresh and time.time() - os.path.getmtime(cache) < 20 * 3600:
        print(f"{sym}: using Topstep history saved today")
        return load_csv(cache)
    if not (os.environ.get("PX_USERNAME") and os.environ.get("PX_API_KEY")):
        from paper import yahoo_bars, FEED
        import requests as rq
        sess = rq.Session()
        sess.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        print(f"{sym}: no Topstep login, downloading 60 days of free data from Yahoo Finance...")
        bars = parse_bars(yahoo_bars(sess, FEED[sym][0], rng="60d"))
        save_cache(os.path.join(DATA_DIR, f"{sym}_yahoo.csv"), bars)
        SHORT_DATA.add(sym)
        return bars
    if px_holder[0] is None:
        px_holder[0] = PX()
    print(f"{sym}: downloading history from Topstep...")
    try:
        bars = fetch_api(px_holder[0], sym)
    except Exception as e:
        if os.path.exists(cache):
            print(f"{sym}: couldn't download ({e}), using what's saved")
            return load_csv(cache)
        raise
    if os.path.exists(cache):                     # keep older days too: the history only grows
        merged = {b["dt"].timestamp(): b for b in load_csv(cache)}
        merged.update({b["dt"].timestamp(): b for b in bars})
        bars = [merged[k] for k in sorted(merged)]
    save_cache(cache, bars)
    return bars


# ---------------- simulation ----------------
def shock_flags(bars):
    """Bars inside a volatility-shock pause (same rule as the live bot, from news.py)."""
    from strategies import atr as _atr
    a = _atr(bars)
    hot, until = [False] * len(bars), -1
    for k in range(20, len(bars)):
        if (bars[k]["h"] - bars[k]["l"]) > SHOCK_MULT * a[k - 1]:
            until = k + SHOCK_BARS
        hot[k] = k <= until
    return hot

def simulate(bars, name, p, spec, risk, pair=None, shock=False, lunch=False, streak=False):
    """One strategy. shock = volatility-shock pause, lunch = no entries 11:30-1:30 ET,
    streak = done for the day after 2 losses in a row."""
    return simulate_legs(bars, [(name, p, {"shock": shock, "lunch": lunch, "streak": streak})], spec, risk, pair)

_PREP = {}

def simulate_legs(bars, legs, spec, risk, pair=None):
    """Several strategies on one market, exactly like the live bot: one position at a time,
    the first strategy (in priority order) that signals takes the trade."""
    from strategies import in_window as _iw
    ready = []
    hot = shock_flags(bars) if any(o.get("shock") for _, _, o in legs) else None
    for name, p, o in legs:
        prep, sig = STRATEGIES[name]
        key = (id(bars), id(pair), name, json.dumps(p, sort_keys=True))
        if key not in _PREP:
            if len(_PREP) > 400:
                _PREP.clear()
            _PREP[key] = prep(bars, p, pair)
        ready.append((sig, _PREP[key], p, o))
    losses_in_row, stopped_day = {}, set()
    tick, pv = spec["tick"], spec["pv"]
    slip = SLIP_TICKS * tick
    trades, pos, pend = [], None, None

    def close(px_out):
        L = pos["L"]
        move = (px_out - pos["entry"]) if L else (pos["entry"] - px_out)
        pnl = pos["realized"] + move * pv * pos["size"] - FEE_RT * pos["full"]
        day = trade_day(pos["dt"])
        trades.append({"day": day, "pnl": pnl, "leg": pos["leg"], "cost1": 2 * tick * pv * pos["full"]})
        losses_in_row[day] = losses_in_row.get(day, 0) + 1 if pnl < 0 else 0
        if losses_in_row[day] >= 2:
            stopped_day.add(day)

    for j, b in enumerate(bars):
        if pend:
            side, sp, tp, size, k = pend
            pend = None
            p = ready[k][2]
            L = side == "long"
            entry = b["o"] + (slip if L else -slip)
            half = size // 2 if p.get("partial") and size >= 2 else 0
            pos = {"L": L, "entry": entry, "size": size, "full": size, "half": half, "realized": 0.0, "leg": k,
                   "dt": b["dt"], "exit_dt": exit_time(b["dt"], p),
                   "stop": entry - sp if L else entry + sp, "tgt": entry + tp if L else entry - tp,
                   "t1": (entry + sp if L else entry - sp) if half else None}
        if pos:
            L = pos["L"]
            if b["dt"] >= pos["exit_dt"]:
                close(b["o"] - slip if L else b["o"] + slip)
                pos = None
            elif (b["l"] <= pos["stop"]) if L else (b["h"] >= pos["stop"]):       # stop first = conservative
                close((min(b["o"], pos["stop"]) - slip) if L else (max(b["o"], pos["stop"]) + slip))
                pos = None
            else:
                if pos["t1"] is not None and ((b["h"] >= pos["t1"]) if L else (b["l"] <= pos["t1"])):
                    move = (pos["t1"] - pos["entry"]) if L else (pos["entry"] - pos["t1"])
                    pos["realized"] += move * pv * pos["half"]
                    pos["size"] -= pos["half"]
                    pos["stop"], pos["t1"] = pos["entry"], None                    # runner is now risk free
                if (b["h"] >= pos["tgt"]) if L else (b["l"] <= pos["tgt"]):
                    close(pos["tgt"])
                    pos = None
            if pos:
                continue
        if pend is not None or j >= len(bars) - 1:
            continue
        day = trade_day(b["dt"])
        for k, (sig, x, p, o) in enumerate(ready):
            if (o.get("shock") and hot[j]) or (o.get("lunch") and _iw(b["dt"], [11, 30], [13, 30])) \
                    or (o.get("streak") and day in stopped_day):
                continue
            s_ = sig(bars, j, p, x)
            if s_:
                side, sp, tp = s_
                sp = max(sp, 4 * tick)
                tp = max(tp, 4 * tick)
                size = min(max(MAX_CONTRACTS, int(MAX_CONTRACTS * risk / BASE_RISK)), int(risk // (sp * pv)))
                if size >= 1:
                    pend = (side, sp, tp, size, k)
                    break
    return trades

def metrics(trades):
    if not trades:
        return None
    pnl = [t["pnl"] for t in trades]
    gw = sum(v for v in pnl if v > 0)
    gl = -sum(v for v in pnl if v <= 0)
    eq = peak = dd = 0
    for v in pnl:
        eq += v
        peak = max(peak, eq)
        dd = max(dd, peak - eq)
    return {"n": len(pnl), "win": 100 * sum(v > 0 for v in pnl) / len(pnl),
            "pf": gw / gl if gl else 99.0, "total": sum(pnl), "dd": dd, "worst": min(pnl)}

def score(m):
    return m["total"] / (m["dd"] + BASE_RISK)

BLOCK = 5   # days drawn together, so real losing streaks stay intact

def day_path(daily):
    """Chronological list of (day P&L, worst intraday dip) from {day: {"pnl", "low"}}."""
    return [(daily[k]["pnl"], daily[k]["low"]) for k in sorted(daily)]

def draws(path):
    """Endless stream of days, drawn in 5-day blocks from the real sequence (block bootstrap)."""
    n = len(path)
    while True:
        s = random.randrange(n)
        for k in range(min(BLOCK, n)):
            yield path[(s + k) % n]

def combine_mc(daily):
    path = day_path(daily)
    if not path:
        return 0, 0, None
    C = COMBINE
    passed = failed = 0
    days_to = []
    for _ in range(C["runs"]):
        bal = peak = best = 0
        g = draws(path)
        for d in range(1, C["max_days"] + 1):
            v, low = next(g)
            floor = min(peak - C["mll"], 0)
            if bal + low <= floor:                # breached during the day
                failed += 1
                break
            bal += v
            best = max(best, v)
            if bal <= floor:
                failed += 1
                break
            peak = max(peak, bal)
            if bal >= C["target"] and best <= C["consistency"] * bal:
                passed += 1
                days_to.append(d)
                break
    n = C["runs"]
    return 100 * passed / n, 100 * failed / n, (statistics.median(days_to) if days_to else None)


EXPRESS = {"days": 60, "split": 0.9, "replace_cost": 200, "cushion_mult": 1.25}
YOUR_RISK = None   # your own risk per trade from the app's Settings (None = let Swing choose)
try:   # what losing a funded account really costs you (new Combine + activation), and your risk setting
    with open("settings.json") as _f:
        _st = json.load(_f)
    EXPRESS["replace_cost"] = float(_st.get("funded_cost", 200))
    if _st.get("min_pass") is not None:
        MIN_PASS = float(_st["min_pass"])
    if _st.get("risk_override"):
        YOUR_RISK = int(round(float(_st["risk_override"])))
except (FileNotFoundError, ValueError, TypeError, json.JSONDecodeError):
    pass

def express_mc(daily, runs=5000):
    """A funded (Express) account over ~3 months. Swing trades half size until the account
    is 25% further from the max loss limit than at the start (cushion mode).
    Returns (expected $ you keep, breach %). A breach costs a replacement Combine."""
    path = day_path(daily)
    if not path:
        return 0.0, 0.0
    E, mll = EXPRESS, COMBINE["mll"]
    total, breaches = 0.0, 0
    for _ in range(runs):
        bal = peak = 0.0
        breached = False
        g = draws(path)
        for _d in range(E["days"]):
            floor = min(peak - mll, 0)
            v, low = next(g)
            if bal - floor < E["cushion_mult"] * mll:
                v, low = v * 0.5, low * 0.5
            if bal + low <= floor or bal + v <= floor:     # breached during or at the end of the day
                breached = True
                break
            bal += v
            peak = max(peak, bal)
        if breached:
            breaches += 1
            total -= E["replace_cost"]
        else:
            total += max(bal, 0) * E["split"]
    return total / runs, 100 * breaches / runs


# ---------------- scale plan: several accounts, real Topstep costs and payout rules ----------------
# Topstep (checked Oct 2026): Combine $49/$149 a month (50K/150K), $149 activation per funded account,
# max 5 Express Funded accounts. Funded accounts start at $0 with a trailing max loss that locks at $0;
# a payout needs 5 winning days of $150+, pays up to 50% of the balance (max $2,000 on 50K, $5,000 on 150K),
# you keep 90%, and after a payout the max loss locks at $0 for good.
SIZES = {
    "50K":  {"mll": 2000, "target": 3000, "fee": 49,  "cap": 2000, "scale": 1.0},
    "150K": {"mll": 4500, "target": 9000, "fee": 149, "cap": 5000, "scale": 2.25},
}
PLAN = {"slots": 5, "activation": 149, "win_day": 150, "min_payout": 125, "split": 0.9,
        "months": 6, "month_days": 21, "runs": 1500, "goal": 10000}
try:
    with open("settings.json") as _f:
        _g = json.load(_f).get("monthly_goal")
    if _g:
        PLAN["goal"] = float(_g)
except (FileNotFoundError, ValueError, TypeError, json.JSONDecodeError):
    pass

def size_combine_mc(path, sz, runs=2000):
    """Combine pass rate for an account size (risk scaled to the size's max loss)."""
    k, S = sz["scale"], sz
    passed = failed = 0
    for _ in range(runs):
        bal = peak = best = 0.0
        g = draws(path)
        for _d in range(COMBINE["max_days"]):
            v, low = next(g)
            v, low = v * k, low * k
            floor = min(peak - S["mll"], 0)
            if bal + low <= floor or bal + v <= floor:
                failed += 1
                break
            bal += v
            best = max(best, v)
            peak = max(peak, bal)
            if bal >= S["target"] and best <= COMBINE["consistency"] * bal:
                passed += 1
                break
    return 100 * passed / runs, 100 * failed / runs

def fleet_mc(keys, dc, dx, sz, runs=None):
    """Run the whole business for 6 months: keep buying Combines until 5 funded accounts are running,
    trade them all on the same days (they win and lose together), take payouts by Topstep's rules,
    pay every fee. Returns month-by-month net cash for each run."""
    P, S, k = PLAN, sz, sz["scale"]
    runs = runs or P["runs"]
    z = {"pnl": 0.0, "low": 0.0}
    path = [(dc.get(d, z)["pnl"] * k, dc.get(d, z)["low"] * k, dx.get(d, z)["pnl"] * k, dx.get(d, z)["low"] * k) for d in keys]
    n, M = len(path), P["month_days"]
    results = []
    for _ in range(runs):
        months = [0.0] * P["months"]
        combines = []          # [balance, peak, best day, days since billed]
        funded = []            # [balance, peak, paid out?, winning days]
        lost = passed = 0
        s, i = random.randrange(n), 0
        for day in range(P["months"] * M):
            m = day // M
            while len(combines) + len(funded) < P["slots"]:
                combines.append([0.0, 0.0, 0.0, 0])
                months[m] -= S["fee"]
            if i >= BLOCK:
                s, i = random.randrange(n), 0
            cv, cl, xv, xl = path[(s + i) % n]
            i += 1
            keep = []
            for c in combines:
                c[3] += 1
                if c[3] >= M:                                  # monthly subscription renews
                    c[3] = 0
                    months[m] -= S["fee"]
                floor = min(c[1] - S["mll"], 0)
                if c[0] + cl <= floor or c[0] + cv <= floor:   # failed: start a fresh Combine tomorrow
                    continue
                c[0] += cv
                c[2] = max(c[2], cv)
                c[1] = max(c[1], c[0])
                if c[0] >= S["target"] and c[2] <= COMBINE["consistency"] * c[0]:
                    passed += 1
                    months[m] -= P["activation"]
                    funded.append([0.0, 0.0, False, 0])
                    continue
                keep.append(c)
            combines = keep
            keep = []
            for f in funded:
                floor = 0.0 if f[2] else min(f[1] - S["mll"], 0)
                half = f[0] - floor < 1.25 * S["mll"]          # cushion mode, same as the live bot
                v, low = (xv * 0.5, xl * 0.5) if half else (xv, xl)
                if f[0] + low <= floor or f[0] + v <= floor:
                    lost += 1
                    continue
                f[0] += v
                f[1] = max(f[1], f[0])
                if v >= P["win_day"]:
                    f[3] += 1
                if f[3] >= 5 and f[0] > 0:
                    pay = min(0.5 * f[0], S["cap"])
                    if pay >= P["min_payout"]:
                        months[m] += pay * P["split"]
                        f[0] -= pay
                        f[2], f[3] = True, 0
                keep.append(f)
            funded = keep
        results.append(months)
    return results

STRESS = 0.5   # stress test: live trading keeps only half of the tested edge

def stressed(daily):
    """Same days, but every trading day gives back half of the average day's profit."""
    traded = [v for v in daily.values() if v["pnl"] != 0]
    h = STRESS * max(0.0, sum(v["pnl"] for v in traded) / len(traded)) if traded else 0.0
    return {d: ({"pnl": v["pnl"] - h, "low": v["low"] - h} if v["pnl"] != 0 else v) for d, v in daily.items()}

def plan_summary(res):
    goal = PLAN["goal"]
    steady = [sum(r[3:]) / len(r[3:]) for r in res]                 # months 4-6, once accounts are running
    total = [sum(r) for r in res]
    by_month = [statistics.median(r[i] for r in res) for i in range(PLAN["months"])]
    return {"p_goal": round(100 * sum(x >= goal for x in steady) / len(res), 1),
            "median_month": round(statistics.median(steady)),
            "low_month": round(sorted(steady)[len(steady) // 10]),        # 1 in 10 runs did worse than this
            "p_loss_6mo": round(100 * sum(x < 0 for x in total) / len(res), 1),
            "median_6mo": round(statistics.median(total)), "by_month": [round(x) for x in by_month]}


# ---------------- main ----------------
def main():
    random.seed(7)
    refresh = "--refresh" in sys.argv
    os.makedirs(DATA_DIR, exist_ok=True)
    lines = []

    def out(s=""):
        print(s)
        lines.append(s)

    px_holder, data = [None], {}
    for sym in MARKETS:
        try:
            bars = get_data(sym, refresh, px_holder)
        except Exception as e:
            print(f"{sym}: failed to load data ({e})")
            continue
        days = len({trade_day(b["dt"]) for b in bars})
        need = 30 if sym in SHORT_DATA else 60
        if days < need:
            print(f"{sym}: only {days} days of data, need {need}+. Skipping (add a CSV in data/).")
            continue
        data[sym] = bars

    if SHORT_DATA:
        out("NOTE: tested on ~60 days of free Yahoo data (no Topstep login). Fewer trades = less reliable results.")
        out("      Treat a PASS as 'worth paper trading', not proof. A Topstep login gives a full year of data.\n")
    out("Checks: settings must work on months they were never tuned on, neighboring settings must also work,")
    out("and neither half of the unseen months can be a loser. Account simulations keep losing streaks")
    out("together and count dips during the day against the max loss limit.\n")
    out(f"Backtest run {datetime.now():%Y-%m-%d %H:%M} | slippage {SLIP_TICKS} tick | fees ${FEE_RT}/contract | "
        f"risk ${BASE_RISK}/trade while selecting")
    pair_of = lambda sym: data.get(PAIRS.get(sym))
    chosen = {}
    for sym, bars in data.items():
        days = sorted({trade_day(b["dt"]) for b in bars})
        cut = days[int(len(days) * IN_SAMPLE)]
        out(f"\n=== {sym}: {days[0]} to {days[-1]} ({len(days)} days). Unseen test data starts {cut} ===")
        out(f"{'strategy':13} | {'TRAIN: trades  win%   PF    P&L':32} | {'TEST: trades  win%   PF    P&L':31} | result")
        passes = []
        test_days = [d for d in days if d >= cut]
        mid = test_days[len(test_days) // 2] if test_days else cut
        for name, grid in GRIDS.items():
            if name == "smt" and pair_of(sym) is None:
                continue
            keys = list(grid)
            tried = {}                                   # settings -> (training metrics, all trades)
            for vals in itertools.product(*(range(len(grid[k])) for k in keys)):   # keys are positions in the grid
                p_ = {k: grid[k][i] for k, i in zip(keys, vals)}
                tr = simulate(bars, name, p_, SPECS[sym], BASE_RISK, pair_of(sym))
                tried[vals] = (metrics([t for t in tr if t["day"] < cut]), tr)
            min_ins = 15 if sym in SHORT_DATA else 30

            def stable(vals):
                """Settings next door (one setting changed) must mostly work too.
                A lone spike surrounded by losers is luck, not an edge."""
                nb = [v for v in tried if sum(a != b for a, b in zip(v, vals)) == 1]
                good = sum(1 for v in nb if tried[v][0] and tried[v][0]["pf"] >= 1.0)
                return not nb or good >= len(nb) / 2

            ranked = sorted((v for v, (m, _) in tried.items() if m and m["n"] >= min_ins and m["pf"] >= 1.15),
                            key=lambda v: -score(tried[v][0]))
            pick = next((v for v in ranked if stable(v)), None)
            if pick is None:
                out(f"{name:13} | {'no stable profitable settings on training data' if ranked else 'no profitable settings on training data'}")
                continue
            p = {k: grid[k][i] for k, i in zip(keys, pick)}
            ins, tr = tried[pick]
            sc = score(ins)
            oos = metrics([t for t in tr if t["day"] >= cut])
            h1 = metrics([t for t in tr if cut <= t["day"] < mid])
            h2 = metrics([t for t in tr if t["day"] >= mid])
            min_n = 5 if sym in SHORT_DATA else 10
            # unseen months must be profitable overall, and neither half can be a clear loser
            halves_ok = all(h is None or h["n"] < 3 or h["pf"] >= 0.9 for h in (h1, h2))
            # Stricter checks: (1) the edge shows up in most of the training months, not one lucky stretch;
            # (2) it still makes money on the unseen months if every fill is a tick worse on both sides.
            tdays = sorted({t["day"] for t in tr if t["day"] < cut})
            thirds = [tdays[len(tdays) * k // 3: len(tdays) * (k + 1) // 3] for k in range(3)] if len(tdays) >= 9 else []
            seg = [metrics([t for t in tr if t["day"] in set(th)]) for th in thirds]
            steady = not seg or sum(1 for m in seg if m and m["total"] > 0) >= 2
            costly = sum(t["pnl"] - t.get("cost1", 0) for t in tr if t["day"] >= cut)
            ok = bool(oos and oos["n"] >= min_n and oos["pf"] >= 1.10 and oos["total"] > 0 and halves_ok
                      and steady and costly > 0)
            if ok and name in OVERNIGHT:
                # overnight bar is higher (the first overnight batch passed tests and still lost live):
                # more unseen trades, PF 1.2+, and still profitable with fills 2 ticks worse on both sides
                costly2 = sum(t["pnl"] - 2 * t.get("cost1", 0) for t in tr if t["day"] >= cut)
                ok = oos["n"] >= 2 * min_n + 5 and oos["pf"] >= 1.2 and costly2 > 0
            fmt = lambda m: (f"{m['n']:6} {m['win']:5.1f}% {m['pf']:5.2f} {m['total']:+9.0f}" if m else "  no trades")
            why = "" if ok or not (oos and oos["total"] > 0) else (
                "  (one half of the unseen months lost)" if not halves_ok else
                "  (only worked in one stretch of the training months)" if not steady else
                "  (not profitable with worse fills)" if costly <= 0 else "")
            out(f"{name:13} | {fmt(ins):32} | {fmt(oos):31} | {'PASS' if ok else 'FAIL'}{why}")
            if not ok:
                continue
            # Protective filters: keep each one only if it helps (or doesn't hurt) on both halves.
            opts = {"shock": False, "lunch": False, "streak": False}
            base = min(sc, score(oos))
            for f in ("shock", "lunch", "streak"):
                trial = dict(opts, **{f: True})
                trs = simulate(bars, name, p, SPECS[sym], BASE_RISK, pair_of(sym), **trial)
                i2 = metrics([t for t in trs if t["day"] < cut])
                o2 = metrics([t for t in trs if t["day"] >= cut])
                if i2 and o2 and min(score(i2), score(o2)) >= base:
                    opts, base = trial, min(score(i2), score(o2))
            passes.append((base, name, p, opts))

        # Portfolio: add more setups to this market only if the combination does better on BOTH
        # the training and the unseen months (more trades, smoother equity, higher pass rate).
        passes.sort(key=lambda x: -x[0])
        legs, best_sc = [], None
        for sc, name, p, opts in passes[:6]:
            trial = legs + [(name, p, opts)]
            trs = simulate_legs(bars, trial, SPECS[sym], BASE_RISK, pair_of(sym))
            i2 = metrics([t for t in trs if t["day"] < cut])
            o2 = metrics([t for t in trs if t["day"] >= cut])
            if not (i2 and o2):
                continue
            s2 = min(score(i2), score(o2))
            if best_sc is None or s2 > best_sc * 1.05:          # must add at least 5% to earn its place
                legs, best_sc, best_oos = trial, s2, o2
            if len(legs) >= 3:
                break
        if legs:
            chosen[sym] = {"legs": legs, "cut": cut, "test": {k: round(v, 2) for k, v in best_oos.items()}}
            names = {"shock": "shock pause", "lunch": "skips lunch", "streak": "2-loss stop"}
            out(f"--> {sym}: {len(legs)} setup{'s' if len(legs) > 1 else ''} combined "
                f"(test: {best_oos['n']} trades, PF {best_oos['pf']:.2f}, {best_oos['total']:+.0f})")
            for name, p, opts in legs:
                f = ", ".join(names[k] for k, v in opts.items() if v)
                out(f"    {name} {json.dumps(p)}" + (f"  [{f}]" if f else ""))
        else:
            out(f"--> {sym}: nothing held up on unseen data. The bot will NOT trade {sym}.")

    if not chosen:
        out("\nNo strategy passed. Do not trade live. That's the backtester protecting you.")
        open("backtest_report.txt", "w").write("\n".join(lines))
        return

    out(f"\n=== Account simulations ({COMBINE['runs']} runs each, unseen test days only) ===")
    out("risk/trade | trades | Combine: pass  fail  days | Express (3 months): you keep  breach")
    best_x = None
    table = []
    levels = set(RISK_LEVELS) | set(EXPRESS_RISK_LEVELS) | ({YOUR_RISK} if YOUR_RISK else set())
    dailies = {}
    # every unseen trading day counts, including days Swing didn't trade (so "days to pass" and
    # "3 months" are real calendar trading days, not just days with trades)
    test_days = sorted({trade_day(b["dt"]) for sym, cfg in chosen.items() for b in data[sym]
                        if trade_day(b["dt"]) >= cfg["cut"] and trade_day(b["dt"]).weekday() < 5})
    for r in sorted(levels):
        ntr = 0
        daily = {}
        dailies[r] = daily
        for sym, cfg in chosen.items():
            run = {}
            for t in simulate_legs(data[sym], cfg["legs"], SPECS[sym], r, pair_of(sym)):
                if t["day"] >= cfg["cut"]:
                    ntr += 1
                    d = daily.setdefault(t["day"], {"pnl": 0.0, "low": 0.0})
                    c = run.get(t["day"], 0.0) + t["pnl"]
                    run[t["day"]] = c
                    d["pnl"] += t["pnl"]
                    d.setdefault("lows", {})[sym] = min(d.get("lows", {}).get(sym, 0.0), c)
            for d in daily.values():          # markets can dip at the same time: add the dips (cautious)
                d["low"] = sum(d.get("lows", {}).values())
        for day in test_days:
            daily.setdefault(day, {"pnl": 0.0, "low": 0.0})
        combine_level = r in RISK_LEVELS or r == YOUR_RISK
        pr, fr, md = combine_mc(daily) if combine_level else (None, None, None)
        ev, br = express_mc(daily)
        comb = (f"{pr:5.1f}% {fr:5.1f}% {md if md else '-':>5}" if pr is not None else "        (not used)")
        table.append({"risk": r, "trades": ntr, "pass": None if pr is None else round(pr, 1),
                      "fail": None if fr is None else round(fr, 1), "days": md,
                      "keep": round(ev), "breach": round(br, 1), "yours": r == YOUR_RISK})
        mark = "  <- your setting" if r == YOUR_RISK else ""
        out(f"   ${r:>4}   | {ntr:6} |      {comb} |              ${ev:>8,.0f}  {br:5.1f}%{mark}")
        # funded accounts: the most money among sizes that rarely lose the account. Losing one costs
        # more than fees (you have to pass a new Combine first), so high-breach sizes are never picked.
        if r in EXPRESS_RISK_LEVELS and br <= MAX_FUNDED_BREACH and (best_x is None or ev > best_x[1] * 1.03):
            best_x = (r, ev, br)
    # Combines: among sizes that pass at least MIN_PASS% of the time, the one that passes fastest
    # (faster pass = sooner to a funded account = more money). If none reach the floor, the highest pass rate.
    rows = [x for x in table if x["risk"] in RISK_LEVELS and x["pass"] is not None]
    ok = [x for x in rows if x["pass"] >= MIN_PASS and x["fail"] <= 100 - MIN_PASS]
    if ok:
        pick = min(ok, key=lambda x: (x["days"] if x["days"] else 10**6, -x["pass"], x["risk"]))
    else:
        top = max(x["pass"] for x in rows)
        pick = min((x for x in rows if x["pass"] >= top - 1), key=lambda x: (x["days"] if x["days"] else 10**6, x["risk"]))
    r, pr, fr, md = pick["risk"], pick["pass"], pick["fail"], pick["days"]
    if best_x is None:                  # every size breaches too often: take the safest one
        safest = min((x for x in table if x["risk"] in EXPRESS_RISK_LEVELS), key=lambda x: (x["breach"], -x["keep"]))
        best_x = (safest["risk"], safest["keep"], safest["breach"])
    rx, ev, br = best_x
    if ok:
        out(f"\n--> Combines: ${r}/trade passes fastest among sizes with {MIN_PASS:.0f}%+ pass rate "
            f"({pr:.1f}% pass, {fr:.1f}% fail, about {md} trading days)")
    else:
        out(f"\n--> Combines: no size reached a {MIN_PASS:.0f}% pass rate. Best is ${r}/trade ({pr:.1f}% pass). "
            f"Paper trade longer before paying for a Combine.")
    out(f"    (a lost funded account counted as ${EXPRESS['replace_cost']:,.0f} in fees, from Settings)")
    out(f"    (funded sizes that lose the account more than {MAX_FUNDED_BREACH:.0f}% of the time are skipped)")
    out(f"--> Express Funded: ${rx}/trade keeps the most money (about ${ev:,.0f} per account per 3 months, "
        f"{br:.1f}% breach), with half size until a cushion builds")
    yours = next((x for x in table if x["yours"]), None)
    if yours:
        out(f"--> YOUR SETTING ${YOUR_RISK}/trade (used on every account): {yours['trades']} trades in the test, "
            f"Combine {yours['pass']:.1f}% pass / {yours['fail']:.1f}% fail, funded keeps about ${yours['keep']:,} "
            f"per 3 months with a {yours['breach']:.1f}% chance of losing the account.")
    out("\nNews: the live bot also pauses around scheduled US news (CPI, jobs, Fed) using the free calendar."
        "\nThat part isn't in this backtest (no free history of past news times), so live results should be calmer.")
    out("\nLimits of this test: daily P&L is used for the drawdown check (intraday dips can be worse),"
        "\nmarkets can change, and simultaneous positions across markets aren't modeled."
        "\nRe-run this every month. Paper trade before paying for a Combine.")

    # ---- Scale plan: which account size and which $/trade make the whole business most likely to hit the goal ----
    out(f"\n=== Scale plan: {PLAN['slots']} funded accounts, goal ${PLAN['goal']:,.0f}/month after all fees ===")
    out("Buys Combines until 5 funded accounts run, trades them all on the same signals, takes every payout")
    out("Topstep allows (5 winning days of $150+, up to half the balance), and pays every fee and activation.")
    keys = sorted(set().union(*(set(d) for d in dailies.values())))
    rows_t = {x["risk"]: x for x in table}
    plans = []
    for sname, sz in SIZES.items():
        okc = []
        for rc in RISK_LEVELS:
            pr_s, fr_s = size_combine_mc(day_path(dailies[rc]), sz)
            if pr_s >= MIN_PASS:
                okc.append((rc, pr_s))
        okx = [rx_ for rx_ in EXPRESS_RISK_LEVELS if rows_t[rx_]["breach"] <= MAX_FUNDED_BREACH]
        if not okc or not okx:
            out(f"  {sname}: no size meets your {MIN_PASS:.0f}% pass floor and {MAX_FUNDED_BREACH:.0f}% funded-loss limit")
            continue
        for rc, pr_s in okc:
            for rx_ in okx:
                sm = plan_summary(fleet_mc(keys, dailies[rc], dailies[rx_], sz, runs=400))
                plans.append({"size": sname, "risk_combine": rc, "risk_funded": rx_, "combine_pass": round(pr_s, 1), **sm})
    plan = None
    if plans:
        plans.sort(key=lambda x: (-x["p_goal"], -x["median_month"], x["p_loss_6mo"]))
        top = [x for x in plans if x["p_goal"] >= plans[0]["p_goal"] - 3][:6]     # re-check the leaders with more runs
        for sname in SIZES:                                                       # and the best of each account size
            best_s = next((x for x in plans if x["size"] == sname), None)
            if best_s and best_s not in top:
                top.append(best_s)
        for x in top:
            x.update(plan_summary(fleet_mc(keys, dailies[x["risk_combine"]], dailies[x["risk_funded"]], SIZES[x["size"]])))
        for x in top:      # the same plan if live trading only keeps half the edge (it usually does worse than tests)
            st_ = plan_summary(fleet_mc(keys, stressed(dailies[x["risk_combine"]]), stressed(dailies[x["risk_funded"]]),
                                        SIZES[x["size"]]))
            x["stress"] = {k: st_[k] for k in ("p_goal", "median_month", "low_month", "p_loss_6mo")}
        # most likely to reach the goal even if live trading is worse than the test, then the bigger typical month
        top.sort(key=lambda x: (-(x["stress"]["p_goal"] + x["p_goal"]) / 2, -x["stress"]["median_month"], x["p_loss_6mo"]))
        plan = top[0]
        out("size  combine $/trade  funded $/trade | chance of goal  typical month  bad month (1 in 10)  lose money 6 mo"
            " | if live keeps half the edge: chance  typical month")
        for x in top:
            out(f"{x['size']:>4}  ${x['risk_combine']:>5} ({x['combine_pass']:.0f}% pass)  ${x['risk_funded']:>5}        |"
                f"     {x['p_goal']:5.1f}%      ${x['median_month']:>8,}     ${x['low_month']:>8,}        {x['p_loss_6mo']:5.1f}%"
                f"   |   {x['stress']['p_goal']:5.1f}%   ${x['stress']['median_month']:>8,}")
        sz = SIZES[plan["size"]]
        out(f"\n--> PLAN: buy 5 x {plan['size']} Combines (${sz['fee']}/month each). Swing trades ${plan['risk_combine']}/trade on Combines "
            f"and ${plan['risk_funded']}/trade on funded accounts" + (" (x2.25 automatically on 150K accounts)" if plan["size"] == "150K" else "") + ".")
        out(f"    Each failed Combine is replaced; each pass costs the ${PLAN['activation']} activation.")
        out(f"    Chance of averaging ${PLAN['goal']:,.0f}+/month in months 4-6: {plan['p_goal']}%. Typical month then: "
            f"${plan['median_month']:,}. 1 in 10 runs: ${plan['low_month']:,} or less. Chance of losing money over 6 months: {plan['p_loss_6mo']}%.")
        out("    Typical month by month: " + ", ".join(f"M{i + 1} ${v:,}" for i, v in enumerate(plan["by_month"])))
        out(f"    If live trading keeps only half the tested edge: {plan['stress']['p_goal']}% chance, typical month "
            f"${plan['stress']['median_month']:,}, {plan['stress']['p_loss_6mo']}% chance of losing money over 6 months.")
        # trade the plan's sizes
        r, rx = plan["risk_combine"], plan["risk_funded"]
        pr, fr, md = rows_t[r]["pass"], rows_t[r]["fail"], rows_t[r]["days"]
        ev, br = rows_t[rx]["keep"], rows_t[rx]["breach"]
    if SHORT_DATA:
        out("\nThese numbers come from a short price history, so they're rough. Swing keeps every day it downloads,"
            "\nso each weekly re-run tests on more history and the plan gets more trustworthy.")

    def leg_cfg(name, p, o):
        return {"strategy": name, "params": p, "shock_filter": o["shock"], "skip_lunch": o["lunch"],
                "loss_streak_stop": o["streak"]}
    cfg_out = {"generated": datetime.now().isoformat(timespec="minutes"), "risk_per_trade": r,
               "combine_pass_rate": round(pr, 1), "combine_fail_rate": round(fr, 1),
               "risk_express": rx, "express_keep_3mo": round(ev), "express_breach": round(br, 1), "risk_table": table, "your_risk": YOUR_RISK,
               "min_pass": MIN_PASS, "max_breach": MAX_FUNDED_BREACH, "generated_ts": time.time(),
               "plan": plan, "plan_goal": PLAN["goal"], "short_data": bool(SHORT_DATA),
               "markets": {s: dict(leg_cfg(*c["legs"][0]), legs=[leg_cfg(*l) for l in c["legs"]], test_stats=c["test"])
                           for s, c in chosen.items()}}
    with open("best_config.json", "w") as f:
        json.dump(cfg_out, f, indent=2)
    with open("backtest_report.txt", "w") as f:
        f.write("\n".join(lines))
    print("\nSaved best_config.json and backtest_report.txt")


if __name__ == "__main__":
    main()
