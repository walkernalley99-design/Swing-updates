"""
Paper trading without a Topstep account.

Pulls free price data from Yahoo Finance (NQ, ES and GC futures, about 10 minutes
delayed) and simulates fills on a virtual 50K account. It answers the same calls as
the Topstep API, so the bot runs unchanged: same strategies, stops, targets, runners
and risk limits. Nothing is ever sent to a broker.
"""
import json, os, time
from datetime import datetime, timedelta, timezone
import requests

FEED = {"MNQ": ("NQ=F", 0.25, 0.50), "MES": ("ES=F", 0.25, 1.25), "MGC": ("GC=F", 0.10, 1.00),
        "MCL": ("CL=F", 0.01, 1.00)}
FEE_PER_SIDE = 0.75          # $ per micro contract per side, roughly Topstep's
SLIP_TICKS = 1
STATE_FILE = "paper_state.json"
BAR = timedelta(minutes=5)


YAHOO_HOSTS = ("query1.finance.yahoo.com", "query2.finance.yahoo.com")
HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                         "Chrome/124.0 Safari/537.36",
           "Accept": "application/json,text/plain,*/*", "Accept-Language": "en-US,en;q=0.9"}

class FeedError(Exception):
    pass

def yahoo_bars(session, symbol, rng="5d", interval="5m"):
    """5-minute bars from Yahoo's free feed. Tries both of Yahoo's servers, backs off when it's busy."""
    session.headers.update(HEADERS)
    last = None
    for attempt in range(4):
        host = YAHOO_HOSTS[attempt % 2]
        try:
            r = session.get(f"https://{host}/v8/finance/chart/{symbol}",
                            params={"interval": interval, "range": rng, "includePrePost": "true"}, timeout=20)
            if r.status_code == 200 and r.json().get("chart", {}).get("result"):
                break
            last = f"HTTP {r.status_code}"
        except (requests.RequestException, ValueError) as e:
            last = type(e).__name__
        time.sleep(2 + 4 * attempt if last and "429" not in last else 10 + 10 * attempt)
    else:
        raise FeedError(last or "no data")
    res = r.json()["chart"]["result"][0]
    q = res["indicators"]["quote"][0]
    out = []
    for i, t in enumerate(res.get("timestamp") or []):
        o, h, l, c, v = (q[k][i] for k in ("open", "high", "low", "close", "volume"))
        if None in (o, h, l, c):
            continue
        out.append({"t": datetime.fromtimestamp(t, timezone.utc).isoformat(), "o": o, "h": h, "l": l, "c": c, "v": v or 0})
    return out


class PaperPX:
    def __init__(self, start_balance=50_000):
        self.s = requests.Session()
        self.s.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        self.cache = {}
        try:
            with open(STATE_FILE) as f:
                self.st = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.st = {"balance": start_balance, "positions": {}, "orders": [], "trades": [], "next_id": 1}
        # Make sure free prices are reachable. Keep trying for a few minutes before giving up.
        err = None
        for wait in (0, 20, 40, 60, 90):
            time.sleep(wait)
            try:
                yahoo_bars(self.s, "NQ=F", "1d")
                err = None
                break
            except Exception as e:
                err = str(e) or type(e).__name__
                import sys
                print(f"Waiting for free market prices (Yahoo: {err})...", file=sys.stderr, flush=True)
        if err:
            blocked = any(c in err for c in ("403", "429", "401"))
            raise SystemExit(
                ("Yahoo Finance is refusing price requests from this internet connection" if blocked else
                 "Couldn't get free market data from Yahoo Finance") + f" ({err}). " +
                ("This is common on cloud servers. Paper trading needs Yahoo's free prices; Swing keeps retrying "
                 "on its own. To trade with Topstep's own prices instead, connect Topstep in Settings."
                 if blocked else "Check the internet connection. Swing keeps retrying on its own."))

    # ---------- data ----------
    def _sym(self, cid):
        return cid.split(".")[3]

    def _bars(self, sym):
        t, bars = self.cache.get(sym, (0, None))
        if bars is None or time.time() - t > 20:
            bars = yahoo_bars(self.s, FEED[sym][0])
            self.cache[sym] = (time.time(), bars)
        return bars

    def _save(self):
        with open(STATE_FILE + ".tmp", "w") as f:
            json.dump(self.st, f)
        os.replace(STATE_FILE + ".tmp", STATE_FILE)

    # ---------- fills ----------
    def _fill(self, cid, side, size, price, bar_t):
        sym = self._sym(cid)
        pv = FEED[sym][2] / FEED[sym][1]
        pos = self.st["positions"].get(cid, {"qty": 0, "avg": 0.0})
        q = size if side == 0 else -size
        pnl = None
        if pos["qty"] == 0 or (pos["qty"] > 0) == (q > 0):
            new = pos["qty"] + q
            pos["avg"] = (pos["avg"] * abs(pos["qty"]) + price * abs(q)) / abs(new)
            pos["qty"] = new
        else:
            closing = min(abs(q), abs(pos["qty"]))
            direction = 1 if pos["qty"] > 0 else -1
            pnl = (price - pos["avg"]) * direction * closing * pv
            pos["qty"] += q
            if pos["qty"] != 0 and (pos["qty"] > 0) == (q > 0):
                pos["avg"] = price                                  # flipped through zero
        fee = FEE_PER_SIDE * size
        self.st["balance"] += (pnl or 0) - fee
        self.st["trades"].append({"contractId": cid, "creationTimestamp": bar_t, "profitAndLoss": pnl, "fees": fee,
                                  "side": side, "size": size, "price": price})
        if pos["qty"] == 0:
            self.st["positions"].pop(cid, None)
            self.st["orders"] = [o for o in self.st["orders"] if o["contractId"] != cid]   # OCO: drop the other exit
        else:
            self.st["positions"][cid] = pos

    def _process(self, cid):
        """Check resting stops/targets against new bars (exits only, never bigger than the position)."""
        orders = [o for o in self.st["orders"] if o["contractId"] == cid]
        if not orders:
            return
        sym = self._sym(cid)
        tick = FEED[sym][1]
        for b in self._bars(sym):
            for o in [x for x in self.st["orders"] if x["contractId"] == cid]:
                if b["t"] <= o["placed"]:
                    continue
                pos = self.st["positions"].get(cid)
                if not pos:
                    break
                size = min(o["size"], abs(pos["qty"]))
                buy = o["side"] == 0
                px = None
                if o["type"] == 4:                                   # stop
                    if buy and b["h"] >= o["stopPrice"]:
                        px = max(o["stopPrice"], b["o"]) + SLIP_TICKS * tick
                    elif not buy and b["l"] <= o["stopPrice"]:
                        px = min(o["stopPrice"], b["o"]) - SLIP_TICKS * tick
                elif o["type"] == 1:                                 # limit
                    if buy and b["l"] <= o["limitPrice"]:
                        px = o["limitPrice"]
                    elif not buy and b["h"] >= o["limitPrice"]:
                        px = o["limitPrice"]
                if px is not None:
                    self.st["orders"] = [x for x in self.st["orders"] if x["id"] != o["id"]]
                    self._fill(cid, o["side"], size, px, b["t"])
        self._save()

    def _process_all(self):
        for cid in {o["contractId"] for o in self.st["orders"]}:
            self._process(cid)

    # ---------- Topstep-style API ----------
    def post(self, path, body):
        if path == "Account/search":
            return {"accounts": [{"id": 1, "name": "PAPER-50K", "canTrade": True, "balance": round(self.st["balance"], 2)}]}
        if path == "Contract/search":
            sym = body["searchText"]
            if sym not in FEED:
                return {"contracts": []}
            return {"contracts": [{"id": f"CON.F.US.{sym}.PAPER", "activeContract": True,
                                   "tickSize": FEED[sym][1], "tickValue": FEED[sym][2]}]}
        if path == "History/retrieveBars":
            sym = self._sym(body["contractId"])
            self._process(body["contractId"])
            return {"bars": self._bars(sym)[:-1]}                     # last bar is still forming
        if path == "Position/searchOpen":
            self._process_all()
            return {"positions": [{"contractId": c, "type": 1 if p["qty"] > 0 else 2, "size": abs(p["qty"]),
                                   "averagePrice": round(p["avg"], 2)} for c, p in self.st["positions"].items()]}
        if path == "Order/searchOpen":
            return {"orders": [{"id": o["id"], "contractId": o["contractId"], "type": o["type"], "side": o["side"],
                                "size": o["size"], "stopPrice": o.get("stopPrice"), "limitPrice": o.get("limitPrice")}
                               for o in self.st["orders"]]}
        if path == "Order/place":
            cid = body["contractId"]
            bars = self._bars(self._sym(cid))
            last = bars[-1]
            oid = self.st["next_id"]
            self.st["next_id"] += 1
            if body["type"] == 2:                                    # market
                tick = FEED[self._sym(cid)][1]
                px = last["c"] + (SLIP_TICKS * tick if body["side"] == 0 else -SLIP_TICKS * tick)
                self._fill(cid, body["side"], body["size"], px, last["t"])
            else:
                self.st["orders"].append({"id": oid, "contractId": cid, "type": body["type"], "side": body["side"],
                                          "size": body["size"], "stopPrice": body.get("stopPrice"),
                                          "limitPrice": body.get("limitPrice"), "placed": last["t"]})
            self._save()
            return {"success": True, "orderId": oid}
        if path == "Order/cancel":
            self.st["orders"] = [o for o in self.st["orders"] if o["id"] != body["orderId"]]
            self._save()
            return {"success": True}
        if path == "Order/modify":
            for o in self.st["orders"]:
                if o["id"] == body["orderId"]:
                    for k in ("size", "stopPrice", "limitPrice"):
                        if body.get(k) is not None:
                            o[k] = body[k]
            self._save()
            return {"success": True}
        if path == "Position/closeContract":
            cid = body["contractId"]
            pos = self.st["positions"].get(cid)
            if pos:
                last = self._bars(self._sym(cid))[-1]
                tick = FEED[self._sym(cid)][1]
                side = 1 if pos["qty"] > 0 else 0
                px = last["c"] + (-SLIP_TICKS * tick if side == 1 else SLIP_TICKS * tick)
                self._fill(cid, side, abs(pos["qty"]), px, last["t"])
                self._save()
            return {"success": True}
        if path == "Trade/search":
            since = body.get("startTimestamp", "")
            return {"trades": [t for t in self.st["trades"] if t["creationTimestamp"] >= since]}
        raise RuntimeError(f"Paper mode doesn't support {path}")
