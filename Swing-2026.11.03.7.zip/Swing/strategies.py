"""
Shared strategy logic used by BOTH backtest.py and topstep_bot.py,
so what you backtest is exactly what trades live.

Each strategy is a pair (prepare, signal):
  prepare(bars, params)         -> precomputed indicators
  signal(bars, i, params, ctx)  -> ("long"|"short", stop_points, target_points) or None
Signals are evaluated on the close of bar i; entry happens right after.
"""
from collections import deque
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

ET = ZoneInfo("America/New_York")
UTC = ZoneInfo("UTC")
HARD_EXIT = [15, 50]      # everything is flat by 3:50 PM ET (Topstep requires flat by 4:10 PM ET)
PAIRS = {"MNQ": "MES", "MES": "MNQ"}   # correlated pairs for SMT divergence
RISK_ON = {"MNQ", "MES"}               # same-direction trades here double the same bet

# Time windows from your notes (all Eastern time)
KILLZONES = [[[3, 0], [4, 0]], [[10, 0], [11, 0]], [[14, 0], [15, 0]]]           # Silver Bullet hours
MACROS = [[[2, 33], [3, 0]], [[3, 50], [4, 10]], [[8, 50], [9, 10]], [[9, 50], [10, 10]],
          [[10, 50], [11, 10]], [[11, 50], [12, 10]], [[13, 10], [13, 40]], [[15, 15], [15, 45]]]


# ---------------- time helpers ----------------
def parse_bars(raw):
    out = []
    for b in raw:
        t = str(b["t"])
        if t.replace(".", "", 1).isdigit():
            dt = datetime.fromtimestamp(float(t), tz=UTC)
        else:
            dt = datetime.fromisoformat(t.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
        out.append({"t": t, "dt": dt.astimezone(ET), "o": float(b["o"]), "h": float(b["h"]),
                    "l": float(b["l"]), "c": float(b["c"]), "v": float(b.get("v") or 0)})
    out.sort(key=lambda x: x["dt"])
    return out

def trade_day(dt):
    """Futures trading day starts 6 PM ET the evening before."""
    return (dt + timedelta(hours=6)).date()

def _m(hm):
    return hm[0] * 60 + hm[1]

def add_min(hm, mins):
    t = (_m(hm) + mins) % 1440
    return [t // 60, t % 60]

def in_window(dt, start, end):
    """True if dt's clock time is in [start, end). Handles windows past midnight."""
    s, e, t = _m(start), _m(end), dt.hour * 60 + dt.minute
    return s <= t < e if s < e else (t >= s or t < e)

def in_any(dt, windows):
    return any(in_window(dt, w[0], w[1]) for w in windows)

def next_at(dt, hm):
    t = dt.replace(hour=hm[0], minute=hm[1], second=0, microsecond=0)
    return t if t > dt else t + timedelta(days=1)

def exit_time(entry_dt, p):
    t = next_at(entry_dt, HARD_EXIT)
    return min(t, next_at(entry_dt, p["exit"])) if p.get("exit") else t


# ---------------- indicators ----------------
def ema(vals, n):
    if not vals:
        return []
    k, out = 2 / (n + 1), [vals[0]]
    for v in vals[1:]:
        out.append(v * k + out[-1] * (1 - k))
    return out

def atr(bars, n=14):
    if not bars:
        return []
    trs = [bars[0]["h"] - bars[0]["l"]]
    for p, b in zip(bars, bars[1:]):
        trs.append(max(b["h"] - b["l"], abs(b["h"] - p["c"]), abs(b["l"] - p["c"])))
    return ema(trs, n)

def rsi(closes, n):
    out, ag, al = [50.0] * len(closes), 0.0, 0.0
    for i in range(1, len(closes)):
        ch = closes[i] - closes[i - 1]
        g, l = max(ch, 0), max(-ch, 0)
        if i <= n:
            ag += g / n
            al += l / n
        else:
            ag = (ag * (n - 1) + g) / n
            al = (al * (n - 1) + l) / n
        if i >= n:
            out[i] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    return out


def sma(vals, n):
    out, run = [], 0.0
    for i, v in enumerate(vals):
        run += v
        if i >= n:
            run -= vals[i - n]
        out.append(run / min(i + 1, n))
    return out

def rolling_ext(vals, n, mode):
    """Highest (mode='max') or lowest value over the last n values, including the current one."""
    dq, out = deque(), []
    for i, v in enumerate(vals):
        while dq and dq[0] <= i - n:
            dq.popleft()
        while dq and (vals[dq[-1]] <= v if mode == "max" else vals[dq[-1]] >= v):
            dq.pop()
        dq.append(i)
        out.append(vals[dq[0]])
    return out

def vwap(bars):
    """Session VWAP, resets each trading day (6 PM ET)."""
    out, day, pv, vv = [], None, 0.0, 0.0
    for b in bars:
        td = trade_day(b["dt"])
        if td != day:
            day, pv, vv = td, 0.0, 0.0
        v = b.get("v") or 1.0
        pv += (b["h"] + b["l"] + b["c"]) / 3 * v
        vv += v
        out.append(pv / vv)
    return out

def trama(bars, n):
    """Trend Regularity Adaptive Moving Average (LuxAlgo's TRAMA)."""
    hst = rolling_ext([b["h"] for b in bars], n, "max")
    lst = rolling_ext([b["l"] for b in bars], n, "min")
    flags = [0.0] + [1.0 if (hst[i] > hst[i - 1] or lst[i] < lst[i - 1]) else 0.0 for i in range(1, len(bars))]
    tc = [x * x for x in sma(flags, n)]
    out = []
    for i, b in enumerate(bars):
        out.append(b["c"] if i == 0 else out[-1] + tc[i] * (b["c"] - out[-1]))
    return out

def htf_ok(side, close, htf, i):
    """Timeframe alignment: only trade with the higher-timeframe trend (if enabled)."""
    if htf is None:
        return True
    return close > htf[i] if side == "long" else close < htf[i]


# ---------------- 1. trend: EMA crossover with trend filter ----------------
def trend_prepare(bars, p, pair=None):
    c = [b["c"] for b in bars]
    return {"f": ema(c, p["fast"]), "s": ema(c, p["slow"]), "t": ema(c, p.get("trend", 50)), "atr": atr(bars)}

def trend_signal(bars, i, p, x):
    if i < 60 or not in_window(bars[i]["dt"], *p["window"]):
        return None
    f, s, t, c = x["f"], x["s"], x["t"], bars[i]["c"]
    stop = p["stop_atr"] * x["atr"][i]
    if f[i - 1] <= s[i - 1] and f[i] > s[i] and c > t[i]:
        return ("long", stop, stop * p["rr"])
    if f[i - 1] >= s[i - 1] and f[i] < s[i] and c < t[i]:
        return ("short", stop, stop * p["rr"])
    return None


# ---------------- 2/3. range breakout (Opening Range or Asia session) ----------------
def breakout_prepare(bars, p, pair=None):
    rs = p["range_start"]
    re = add_min(rs, p["range_min"])
    rng = {}
    for b in bars:
        if in_window(b["dt"], rs, re):
            r = rng.setdefault(trade_day(b["dt"]), [b["h"], b["l"]])
            r[0], r[1] = max(r[0], b["h"]), min(r[1], b["l"])
    first, done = {}, set()
    for i, b in enumerate(bars):
        td = trade_day(b["dt"])
        if td in done or td not in rng or not in_window(b["dt"], re, p["entry_end"]):
            continue
        hi, lo = rng[td]
        if b["c"] > hi:
            first[i] = ("long", hi - lo)
            done.add(td)
        elif b["c"] < lo:
            first[i] = ("short", hi - lo)
            done.add(td)
    return {"first": first, "atr": atr(bars)}

def breakout_signal(bars, i, p, x):
    if p.get("nr7"):
        if "nr7" not in x:
            x["nr7"] = nr7_days(bars)
        if trade_day(bars[i]["dt"]) not in x["nr7"]:
            return None
    hit = x["first"].get(i)
    if not hit:
        return None
    side, width = hit
    stop = max(p["stop_frac"] * width, 0.5 * x["atr"][i])
    return (side, stop, stop * p["rr"])


# ---------------- 4. pullback: RSI(2) dip in the direction of trend ----------------
def pullback_prepare(bars, p, pair=None):
    c = [b["c"] for b in bars]
    return {"t": ema(c, p["trend"]), "r": rsi(c, 2), "atr": atr(bars)}

def pullback_signal(bars, i, p, x):
    if i < p["trend"] or not in_window(bars[i]["dt"], *p["window"]):
        return None
    c, r, t, lo = bars[i]["c"], x["r"], x["t"], p["rsi_lo"]
    stop = p["stop_atr"] * x["atr"][i]
    if c > t[i] and r[i] < lo <= r[i - 1]:
        return ("long", stop, stop * p["rr"])
    if c < t[i] and r[i] > 100 - lo >= r[i - 1]:
        return ("short", stop, stop * p["rr"])
    return None


# ======== Strategies built from your Notion trading notes ========

def precomputed_signal(bars, i, p, x):
    return x["sig"].get(i)

# ---------------- 5. Silver Bullet: liquidity sweep -> FVG entry in a kill zone/macro ----------------
# Notes: liquidity rests above highs / below lows; the market sweeps it, then finds a
# fair value gap and "shoots in the other direction". Stop goes beyond the liquidity
# that was swept. Volume confirms the move; trade with the higher timeframe.
def sb_prepare(bars, p, pair=None):
    n, L, K = len(bars), p["lookback"], p["sweep_bars"]
    hi = rolling_ext([b["h"] for b in bars], L, "max")
    lo = rolling_ext([b["l"] for b in bars], L, "min")
    a = atr(bars)
    htf = ema([b["c"] for b in bars], p["htf_ema"]) if p.get("htf_ema") else None
    vavg = sma([b["v"] for b in bars], 20)
    sig, ssl, bsl = {}, None, None
    for i in range(max(L, 20) + 2, n):
        b, disp = bars[i], bars[i - 1]
        if b["l"] < lo[i - 1]:
            ssl = [i, b["l"]]                    # sell-side liquidity taken
        if b["h"] > hi[i - 1]:
            bsl = [i, b["h"]]                    # buy-side liquidity taken
        if not in_any(b["dt"], p["windows"]):
            continue
        vol_ok = not p.get("vol_mult") or vavg[i - 2] <= 0 or disp["v"] >= p["vol_mult"] * vavg[i - 2]
        if ssl and i - ssl[0] <= K and b["l"] > bars[i - 2]["h"] and disp["c"] > disp["o"] \
                and vol_ok and htf_ok("long", b["c"], htf, i):
            stop = b["c"] - ssl[1] + p["stop_buf"] * a[i]
            if 0 < stop <= 4 * a[i]:
                sig[i] = ("long", stop, stop * p["rr"])
            ssl = None
        elif bsl and i - bsl[0] <= K and b["h"] < bars[i - 2]["l"] and disp["c"] < disp["o"] \
                and vol_ok and htf_ok("short", b["c"], htf, i):
            stop = bsl[1] - b["c"] + p["stop_buf"] * a[i]
            if 0 < stop <= 4 * a[i]:
                sig[i] = ("short", stop, stop * p["rr"])
            bsl = None
    return {"sig": sig}

# ---------------- 6. VWAP + TRAMA momentum (with optional RSI) ----------------
# Notes: close above VWAP and TRAMA = bullish momentum (long); below both = short.
# RSI: oversold while price reclaims VWAP/TRAMA = stronger long; overbought = stronger short.
def vt_prepare(bars, p, pair=None):
    n = len(bars)
    c = [b["c"] for b in bars]
    vw, tr, r, a = vwap(bars), trama(bars, p["trama_len"]), rsi(c, 14), atr(bars)
    htf = ema(c, p["htf_ema"]) if p.get("htf_ema") else None
    sig = {}
    for i in range(p["trama_len"] + 7, n):
        if not in_window(bars[i]["dt"], *p["window"]):
            continue
        up, was_up = c[i] > vw[i] and c[i] > tr[i], c[i - 1] > vw[i - 1] and c[i - 1] > tr[i - 1]
        dn, was_dn = c[i] < vw[i] and c[i] < tr[i], c[i - 1] < vw[i - 1] and c[i - 1] < tr[i - 1]
        stop = p["stop_atr"] * a[i]
        recent = r[i - 6:i + 1]
        if up and not was_up and htf_ok("long", c[i], htf, i) \
                and (p["rsi_mode"] != "extreme" or min(recent) < 35):
            sig[i] = ("long", stop, stop * p["rr"])
        elif dn and not was_dn and htf_ok("short", c[i], htf, i) \
                and (p["rsi_mode"] != "extreme" or max(recent) > 65):
            sig[i] = ("short", stop, stop * p["rr"])
    return {"sig": sig}

# ---------------- 7. SMT divergence (MNQ vs MES) ----------------
# Notes: one correlated asset takes a high/low while the other fails to = likely reversal.
# Entry needs confirmation: a close beyond the previous candle (change in state of delivery).
def smt_prepare(bars, p, pair=None):
    sig = {}
    if not pair:
        return {"sig": sig}
    n, L, K = len(bars), p["lookback"], p["confirm_bars"]
    pidx = {b["dt"]: j for j, b in enumerate(pair)}
    plo = rolling_ext([b["l"] for b in pair], L, "min")
    phi = rolling_ext([b["h"] for b in pair], L, "max")
    lo = rolling_ext([b["l"] for b in bars], L, "min")
    hi = rolling_ext([b["h"] for b in bars], L, "max")
    a = atr(bars)
    bull = bear = None
    for i in range(L + 2, n):
        b = bars[i]
        j = pidx.get(b["dt"])
        if j is not None and j > L:
            pb = pair[j]
            if b["l"] < lo[i - 1] and pb["l"] >= plo[j - 1]:
                bull = [i, b["l"]]               # we swept the low, the pair didn't
            if b["h"] > hi[i - 1] and pb["h"] <= phi[j - 1]:
                bear = [i, b["h"]]
        if not in_any(b["dt"], p["windows"]):
            continue
        if bull and 0 < i - bull[0] <= K and b["c"] > bars[i - 1]["h"]:
            stop = b["c"] - min(bull[1], b["l"]) + p["stop_buf"] * a[i]
            if 0 < stop <= 4 * a[i]:
                sig[i] = ("long", stop, stop * p["rr"])
            bull = None
        elif bear and 0 < i - bear[0] <= K and b["c"] < bars[i - 1]["l"]:
            stop = max(bear[1], b["h"]) - b["c"] + p["stop_buf"] * a[i]
            if 0 < stop <= 4 * a[i]:
                sig[i] = ("short", stop, stop * p["rr"])
            bear = None
    return {"sig": sig}


# ======== Models from your Notion screenshots ========

def pivots(bars, k=2):
    """Swing highs / lows (k bars on each side)."""
    ph, pl = [], []
    for j in range(k, len(bars) - k):
        h, l = bars[j]["h"], bars[j]["l"]
        if all(h > bars[j - m]["h"] for m in range(1, k + 1)) and all(h >= bars[j + m]["h"] for m in range(1, k + 1)):
            ph.append((j, h))
        if all(l < bars[j - m]["l"] for m in range(1, k + 1)) and all(l <= bars[j + m]["l"] for m in range(1, k + 1)):
            pl.append((j, l))
    return ph, pl

def eq_against(side, i, price, piv, atr_i, n=96, tol=0.1, k=2):
    """Blake / PDI rule: no longs with equal lows below, no shorts with equal highs above."""
    ph, pl = piv
    pts = pl if side == "long" else ph
    lv = sorted(v for j, v in pts if i - n <= j <= i - k and (v < price if side == "long" else v > price))
    return any(b - a <= tol * atr_i for a, b in zip(lv, lv[1:]))

def _target(side, close, stop, p, pool):
    """Target = R multiple, or the opposite liquidity pool ("liq"). Skips trades under 1R."""
    if p.get("target") == "liq" and pool is not None:
        tp = (pool - close) if side == "long" else (close - pool)
        return tp if tp >= stop else None
    return stop * p["rr"]

def _emit(sig, i, side, close, stop, p, a_i, piv, pool=None):
    if not (0 < stop <= 4 * a_i):
        return
    if p.get("no_eq") and eq_against(side, i, close, piv, a_i):
        return
    tp = _target(side, close, stop, p, pool)
    if tp:
        sig[i] = (side, stop, tp)


# ---------------- 8. Venom (deferred turtle soup) ----------------
# At least 1 candle closes beyond a liquidity pool, then entry at the close of the
# candle that comes back inside. Stop beyond the sweep. Target: opposite pool or R.
def venom_prepare(bars, p, pair=None):
    n, L = len(bars), p["lookback"]
    hi = rolling_ext([b["h"] for b in bars], L, "max")
    lo = rolling_ext([b["l"] for b in bars], L, "min")
    a, piv = atr(bars), pivots(bars)
    sig, dn, up = {}, None, None
    for i in range(L + 2, n):
        b = bars[i]
        if dn is None and b["c"] < lo[i - 1]:
            dn = {"pool": lo[i - 1], "start": i, "ext": b["l"], "opp": hi[i - 1]}
        elif dn:
            dn["ext"] = min(dn["ext"], b["l"])
        if up is None and b["c"] > hi[i - 1]:
            up = {"pool": hi[i - 1], "start": i, "ext": b["h"], "opp": lo[i - 1]}
        elif up:
            up["ext"] = max(up["ext"], b["h"])
        if dn and i - dn["start"] > p["max_below"]:
            dn = None
        if up and i - up["start"] > p["max_below"]:
            up = None
        if not in_any(b["dt"], p["windows"]):
            continue
        if dn and i > dn["start"] and b["c"] > dn["pool"]:
            _emit(sig, i, "long", b["c"], b["c"] - dn["ext"] + p["stop_buf"] * a[i], p, a[i], piv, dn["opp"])
            dn = None
        elif up and i > up["start"] and b["c"] < up["pool"]:
            _emit(sig, i, "short", b["c"], up["ext"] - b["c"] + p["stop_buf"] * a[i], p, a[i], piv, up["opp"])
            up = None
    return {"sig": sig}


# ---------------- 9. Silver Bullet hourly framework (TTrades) ----------------
# Use the previous hourly candle (9:00 for the 10-11 window) high/low. In the window,
# a sweep of that high/low followed by a CISD (close through the open of the candle
# that made the extreme) = entry. Stop beyond the sweep. Target: other side of the hour.
def hsb_prepare(bars, p, pair=None):
    n = len(bars)
    a, piv = atr(bars), pivots(bars)
    hours = {}
    for b in bars:
        for hs in p["sessions"]:
            if in_window(b["dt"], hs, add_min(hs, 60)):
                r = hours.setdefault((trade_day(b["dt"]), tuple(hs)), [b["h"], b["l"]])
                r[0], r[1] = max(r[0], b["h"]), min(r[1], b["l"])
    sig, state = {}, {}
    for i in range(3, n):
        b = bars[i]
        hs = next((h for h in p["sessions"] if in_window(b["dt"], add_min(h, 60), add_min(h, 120))), None)
        if hs is None:
            continue
        key = (trade_day(b["dt"]), tuple(hs))
        if key not in hours:
            continue
        H, Lo = hours[key]
        st = state.setdefault(key, {"hi": None, "lo": None, "done": False})
        if st["done"]:
            continue
        if b["h"] > H and (st["hi"] is None or b["h"] > st["hi"][0]):
            ob = next((bars[j]["o"] for j in range(i, max(i - 6, 0), -1) if bars[j]["c"] > bars[j]["o"]), b["o"])
            st["hi"] = [b["h"], ob]
        if b["l"] < Lo and (st["lo"] is None or b["l"] < st["lo"][0]):
            ob = next((bars[j]["o"] for j in range(i, max(i - 6, 0), -1) if bars[j]["c"] < bars[j]["o"]), b["o"])
            st["lo"] = [b["l"], ob]
        if st["hi"] and b["c"] < st["hi"][1]:
            _emit(sig, i, "short", b["c"], st["hi"][0] - b["c"] + p["stop_buf"] * a[i], p, a[i], piv, Lo)
            st["done"] = True
        elif st["lo"] and b["c"] > st["lo"][1]:
            _emit(sig, i, "long", b["c"], b["c"] - st["lo"][0] + p["stop_buf"] * a[i], p, a[i], piv, H)
            st["done"] = True
    return {"sig": sig}


# ---------------- 10. PDI (Pre-Distribution Inversion) ----------------
# Accumulation -> manipulation leg through the range leaves an FVG -> price closes
# back through that FVG (inversion) = entry. Not taken if the inversion close is too
# far from the ideal entry, outside the time windows, or against EQH/EQL.
def pdi_prepare(bars, p, pair=None):
    n, L = len(bars), p["lookback"]
    hi = rolling_ext([b["h"] for b in bars], L, "max")
    lo = rolling_ext([b["l"] for b in bars], L, "min")
    a, piv = atr(bars), pivots(bars)
    sig, mu, md = {}, None, None
    for i in range(L + 3, n):
        b = bars[i]
        if b["h"] > hi[i - 1]:
            mu = mu if mu and i - mu["start"] <= p["max_manip"] else {"start": i, "ext": b["h"], "fvg": None}
            mu["ext"] = max(mu["ext"], b["h"])
        if b["l"] < lo[i - 1]:
            md = md if md and i - md["start"] <= p["max_manip"] else {"start": i, "ext": b["l"], "fvg": None}
            md["ext"] = min(md["ext"], b["l"])
        if mu and i - mu["start"] > p["max_manip"]:
            mu = None
        if md and i - md["start"] > p["max_manip"]:
            md = None
        if mu and b["l"] > bars[i - 2]["h"] and i >= mu["start"] - 2:
            mu["fvg"] = (bars[i - 2]["h"], b["l"])            # bullish FVG in the up-manipulation
        if md and b["h"] < bars[i - 2]["l"] and i >= md["start"] - 2:
            md["fvg"] = (b["h"], bars[i - 2]["l"])            # bearish FVG in the down-manipulation
        if mu:
            mu["ext"] = max(mu["ext"], b["h"])
        if md:
            md["ext"] = min(md["ext"], b["l"])
        if not in_any(b["dt"], p["windows"]):
            continue
        if mu and mu["fvg"] and b["c"] < mu["fvg"][0]:
            if mu["fvg"][0] - b["c"] <= p["max_dist"] * a[i]:
                _emit(sig, i, "short", b["c"], mu["ext"] - b["c"] + p["stop_buf"] * a[i], p, a[i], piv)
            mu = None
        elif md and md["fvg"] and b["c"] > md["fvg"][1]:
            if b["c"] - md["fvg"][1] <= p["max_dist"] * a[i]:
                _emit(sig, i, "long", b["c"], b["c"] - md["ext"] + p["stop_buf"] * a[i], p, a[i], piv)
            md = None
    return {"sig": sig}


# ---------------- 11. Shulk model ----------------
# 1 after CISD  2 OB above FVG  3 OB wick doesn't cross the FVG C.E.
# 4 next candle closes above FVG  5 entry after that close  6 stop at FVG C.E. (mirror for shorts)
def shulk_prepare(bars, p, pair=None):
    n, L = len(bars), p["lookback"]
    hi = rolling_ext([b["h"] for b in bars], L, "max")
    lo = rolling_ext([b["l"] for b in bars], L, "min")
    a, piv = atr(bars), pivots(bars)
    sig, last_ssl, last_bsl, bull, bear = {}, -10**9, -10**9, None, None
    for i in range(L + 3, n):
        b = bars[i]
        if b["l"] < lo[i - 1]:
            last_ssl = i
        if b["h"] > hi[i - 1]:
            last_bsl = i
        # FVG after a sweep + displacement = CISD context
        if b["l"] > bars[i - 2]["h"] and bars[i - 1]["c"] > bars[i - 1]["o"] and i - last_ssl <= p["sweep_bars"]:
            top, bot = b["l"], bars[i - 2]["h"]
            bull = {"top": top, "ce": (top + bot) / 2, "k": i, "ob": None}
        if b["h"] < bars[i - 2]["l"] and bars[i - 1]["c"] < bars[i - 1]["o"] and i - last_bsl <= p["sweep_bars"]:
            bot, top = b["h"], bars[i - 2]["l"]
            bear = {"bot": bot, "ce": (top + bot) / 2, "k": i, "ob": None}
        win = in_any(b["dt"], p["windows"])
        if bull and i > bull["k"]:
            if i - bull["k"] > p["ob_bars"]:
                bull = None
            elif bull["ob"] is not None and win and b["c"] > bull["top"] and b["c"] > bars[bull["ob"]]["h"]:
                _emit(sig, i, "long", b["c"], b["c"] - bull["ce"] + p["stop_buf"] * a[i], p, a[i], piv)
                bull = None
            elif bull and b["l"] <= bull["top"] and b["l"] > bull["ce"] and min(b["o"], b["c"]) >= bull["top"]:
                bull["ob"] = i                                 # OB above FVG, wick into it, not past C.E.
            elif bull and b["l"] <= bull["ce"]:
                bull = None
        if bear and i > bear["k"]:
            if i - bear["k"] > p["ob_bars"]:
                bear = None
            elif bear["ob"] is not None and win and b["c"] < bear["bot"] and b["c"] < bars[bear["ob"]]["l"]:
                _emit(sig, i, "short", b["c"], bear["ce"] - b["c"] + p["stop_buf"] * a[i], p, a[i], piv)
                bear = None
            elif bear and b["h"] >= bear["bot"] and b["h"] < bear["ce"] and max(b["o"], b["c"]) <= bear["bot"]:
                bear["ob"] = i
            elif bear and b["h"] >= bear["ce"]:
                bear = None
    return {"sig": sig}


# ======== Ideas from other well-known, rule-based traders ========

def _rth_days(bars):
    """Per trading day: regular-hours (9:30-16:00 ET) high, low, close, and the index of the 9:30 bar."""
    days = {}
    for i, b in enumerate(bars):
        if in_window(b["dt"], [9, 30], [16, 0]):
            d = days.setdefault(trade_day(b["dt"]), {"h": b["h"], "l": b["l"], "c": b["c"], "open_i": i})
            d["h"], d["l"], d["c"] = max(d["h"], b["h"]), min(d["l"], b["l"]), b["c"]
    return days

def adx(bars, n=14):
    """Wilder's ADX with +DI / -DI."""
    pdm, mdm, trs = [0.0], [0.0], [bars[0]["h"] - bars[0]["l"]] if bars else []
    for p, b in zip(bars, bars[1:]):
        up, dn = b["h"] - p["h"], p["l"] - b["l"]
        pdm.append(up if up > dn and up > 0 else 0.0)
        mdm.append(dn if dn > up and dn > 0 else 0.0)
        trs.append(max(b["h"] - b["l"], abs(b["h"] - p["c"]), abs(b["l"] - p["c"])))
    def wild(x):
        out, s_ = [], 0.0
        for i, v in enumerate(x):
            s_ = v if i == 0 else s_ - s_ / n + v
            out.append(s_)
        return out
    tr_s, p_s, m_s = wild(trs), wild(pdm), wild(mdm)
    pdi = [100 * p / t if t else 0 for p, t in zip(p_s, tr_s)]
    mdi = [100 * m / t if t else 0 for m, t in zip(m_s, tr_s)]
    dx = [100 * abs(a - b) / (a + b) if a + b else 0 for a, b in zip(pdi, mdi)]
    out, s_ = [], 0.0
    for i, v in enumerate(dx):
        s_ = v if i == 0 else (s_ * (n - 1) + v) / n
        out.append(s_)
    return out, pdi, mdi

# ---------------- 12. Holy Grail (Linda Raschke) ----------------
# Strong trend (ADX above 30), first pullback to the 20 EMA, enter when price breaks
# the prior candle in the trend direction. Stop beyond the pullback.
def hg_prepare(bars, p, pair=None):
    n = len(bars)
    c = [b["c"] for b in bars]
    e20, a = ema(c, 20), atr(bars)
    ax, pdi, mdi = adx(bars, 14)
    sig, touched_up, touched_dn = {}, None, None
    for i in range(40, n):
        b = bars[i]
        strong = ax[i - 1] >= p["adx_min"]
        if strong and pdi[i - 1] > mdi[i - 1] and b["l"] <= e20[i]:
            touched_up = i if touched_up is None else touched_up
        if strong and mdi[i - 1] > pdi[i - 1] and b["h"] >= e20[i]:
            touched_dn = i if touched_dn is None else touched_dn
        if not in_window(b["dt"], *p["window"]):
            continue
        if touched_up is not None and i > touched_up and b["c"] > bars[i - 1]["h"] and i - touched_up <= 6:
            low = min(x["l"] for x in bars[touched_up:i + 1])
            stop = b["c"] - low + 0.1 * a[i]
            if 0 < stop <= 4 * a[i]:
                sig[i] = ("long", stop, stop * p["rr"])
            touched_up = None
        elif touched_dn is not None and i > touched_dn and b["c"] < bars[i - 1]["l"] and i - touched_dn <= 6:
            high = max(x["h"] for x in bars[touched_dn:i + 1])
            stop = high - b["c"] + 0.1 * a[i]
            if 0 < stop <= 4 * a[i]:
                sig[i] = ("short", stop, stop * p["rr"])
            touched_dn = None
        if touched_up is not None and i - touched_up > 6:
            touched_up = None
        if touched_dn is not None and i - touched_dn > 6:
            touched_dn = None
    return {"sig": sig}

# ---------------- 13. Gap fill ----------------
# Index futures often fill a modest overnight gap back to yesterday's close. Fade the
# gap only after the first 5-minute candle moves toward the fill. Target: yesterday's close.
def gap_prepare(bars, p, pair=None):
    days = _rth_days(bars)
    keys = sorted(days)
    a = atr(bars)
    sig = {}
    for k_prev, k in zip(keys, keys[1:]):
        d, prev = days[k], days[k_prev]
        i = d["open_i"]
        if i + 1 >= len(bars):
            continue
        rng = prev["h"] - prev["l"]
        o = bars[i]["o"]
        gap = o - prev["c"]
        if rng <= 0 or not (p["min_gap"] * rng <= abs(gap) <= p["max_gap"] * rng):
            continue
        b = bars[i]                                                   # first 5-min candle confirms
        if gap > 0 and b["c"] < b["o"]:
            stop = b["h"] - b["c"] + 0.1 * a[i]
            tp = b["c"] - prev["c"]
            if 0 < stop <= 4 * a[i] and tp >= stop * p["min_rr"]:
                sig[i] = ("short", stop, tp)
        elif gap < 0 and b["c"] > b["o"]:
            stop = b["c"] - b["l"] + 0.1 * a[i]
            tp = prev["c"] - b["c"]
            if 0 < stop <= 4 * a[i] and tp >= stop * p["min_rr"]:
                sig[i] = ("long", stop, tp)
    return {"sig": sig}

# ---------------- 14. Previous-day high/low sweep (Turtle Soup, Raschke & Connors) ----------------
# Price runs yesterday's high or low, then closes back inside: the breakout failed.
# Stop beyond the sweep, target the middle of yesterday's range (or R).
def pdhl_prepare(bars, p, pair=None):
    days = _rth_days(bars)
    keys = sorted(days)
    prev_of = {k: days[pk] for pk, k in zip(keys, keys[1:])}
    a = atr(bars)
    sig, state = {}, {}
    for i, b in enumerate(bars):
        td = trade_day(b["dt"])
        prev = prev_of.get(td)
        if not prev:
            continue
        st = state.setdefault(td, {"hi": None, "lo": None, "done": False})
        if b["h"] > prev["h"]:
            st["hi"] = max(st["hi"] or b["h"], b["h"])
        if b["l"] < prev["l"]:
            st["lo"] = min(st["lo"] or b["l"], b["l"])
        if st["done"] or not in_any(b["dt"], p["windows"]):
            continue
        mid = (prev["h"] + prev["l"]) / 2
        if st["hi"] and b["c"] < prev["h"]:
            stop = st["hi"] - b["c"] + 0.1 * a[i]
            tp = (b["c"] - mid) if p["target"] == "mid" else stop * p["rr"]
            if 0 < stop <= 4 * a[i] and tp >= stop:
                sig[i] = ("short", stop, tp)
                st["done"] = True
        elif st["lo"] and b["c"] > prev["l"]:
            stop = b["c"] - st["lo"] + 0.1 * a[i]
            tp = (mid - b["c"]) if p["target"] == "mid" else stop * p["rr"]
            if 0 < stop <= 4 * a[i] and tp >= stop:
                sig[i] = ("long", stop, tp)
                st["done"] = True
    return {"sig": sig}

# ---------------- Opening range filters (Toby Crabel, initial balance) ----------------
def nr7_days(bars):
    """Trading days that follow an NR7 day (narrowest range of the last 7): compression before expansion."""
    days = _rth_days(bars)
    keys = sorted(days)
    out = set()
    for j in range(7, len(keys)):
        rngs = [days[k]["h"] - days[k]["l"] for k in keys[j - 7:j]]
        if rngs[-1] == min(rngs):
            out.add(keys[j])
    return out


# ---------------- 15. Snap-back mean reversion ----------------
# Price stretches more than ~2 standard deviations from its 20-period (15-minute) average,
# then starts to come back. Enter on the first close back inside the band; target the
# average; stop beyond the extreme.
def snap_prepare(bars, p, pair=None):
    n, w = len(bars), p["window"]
    c = [b["c"] for b in bars]
    a = atr(bars)
    mean, sd = [0.0] * n, [0.0] * n
    s1 = s2 = 0.0
    for i, v in enumerate(c):
        s1 += v
        s2 += v * v
        if i >= w:
            s1 -= c[i - w]
            s2 -= c[i - w] ** 2
        k = min(i + 1, w)
        mean[i] = s1 / k
        sd[i] = max(s2 / k - mean[i] ** 2, 0) ** 0.5
    htf = ema(c, p["htf_ema"]) if p.get("htf_ema") else None
    sig = {}
    for i in range(w + 2, n):
        b = bars[i]
        if sd[i] <= 0 or sd[i - 1] <= 0 or not in_window(b["dt"], *p["window_time"]):
            continue
        z, zp = (c[i] - mean[i]) / sd[i], (c[i - 1] - mean[i - 1]) / sd[i - 1]
        ext_lo = min(x["l"] for x in bars[i - 3:i + 1])
        ext_hi = max(x["h"] for x in bars[i - 3:i + 1])
        if zp <= -p["z"] < z and htf_ok("long", c[i], htf, i):
            stop = c[i] - ext_lo + 0.1 * a[i]
            tp = mean[i] - c[i]
            if 0 < stop <= 4 * a[i] and tp >= stop * p["min_rr"]:
                sig[i] = ("long", stop, tp)
        elif zp >= p["z"] > z and htf_ok("short", c[i], htf, i):
            stop = ext_hi - c[i] + 0.1 * a[i]
            tp = c[i] - mean[i]
            if 0 < stop <= 4 * a[i] and tp >= stop * p["min_rr"]:
                sig[i] = ("short", stop, tp)
    return {"sig": sig}


# ======== More public, rule-based strategies ========

def _hm(dt):
    return [dt.hour, dt.minute]

# ---------------- 16. Intraday momentum (Gao, Han, Li & Zhou, "Market Intraday Momentum",
# Journal of Financial Economics 2018) ----------------
# The move from yesterday's close to 10:00 AM tends to continue in the last part of the day.
# Enter late in the session in that direction; Swing is flat by 3:50 PM.
def imom_prepare(bars, p, pair=None):
    days = _rth_days(bars)
    keys = sorted(days)
    prev_close = {k: days[pk]["c"] for pk, k in zip(keys, keys[1:])}
    a = atr(bars)
    sig, first30 = {}, {}
    for i, b in enumerate(bars):
        td = trade_day(b["dt"])
        if _hm(b["dt"]) == [9, 55]:                 # bar that closes at 10:00
            first30[td] = b["c"]
        if _hm(b["dt"]) != p["sig_time"] or td not in first30 or td not in prev_close:
            continue
        move = first30[td] - prev_close[td]
        if abs(move) < p["min_atr"] * a[i] or move == 0:
            continue
        stop = p["stop_atr"] * a[i]
        sig[i] = ("long" if move > 0 else "short", stop, stop * p["rr"])
    return {"sig": sig}

# ---------------- 17. Volatility breakout (Larry Williams, "Long-Term Secrets to Short-Term Trading") ----------------
# Buy when price runs a set share of yesterday's range above today's open (sell below).
# Range expansion after the open tends to keep going into the close.
def volbrk_prepare(bars, p, pair=None):
    days = _rth_days(bars)
    keys = sorted(days)
    prev = {k: days[pk] for pk, k in zip(keys, keys[1:])}
    a = atr(bars)
    sig, done = {}, set()
    for i, b in enumerate(bars):
        td = trade_day(b["dt"])
        if td in done or td not in prev or td not in days or not in_window(b["dt"], *p["window"]):
            continue
        o = bars[days[td]["open_i"]]["o"]
        rng = prev[td]["h"] - prev[td]["l"]
        if rng <= 0 or i <= days[td]["open_i"]:
            continue
        up, dn = o + p["k"] * rng, o - p["k"] * rng
        stop = p["stop_atr"] * a[i]
        if b["c"] > up:
            sig[i] = ("long", stop, stop * p["rr"]); done.add(td)
        elif b["c"] < dn:
            sig[i] = ("short", stop, stop * p["rr"]); done.add(td)
    return {"sig": sig}

# ---------------- 18. VWAP band fade (standard-deviation bands around the session VWAP) ----------------
# Price that stretches 2+ standard deviations from VWAP and closes back inside the band
# tends to drift back toward VWAP. Target: VWAP. Stop: beyond the stretch.
def vwapband_prepare(bars, p, pair=None):
    n = len(bars)
    a = atr(bars)
    c = [b["c"] for b in bars]
    vw, sd = [], []
    day = None
    for b in bars:
        td = trade_day(b["dt"])
        if td != day:
            day, sv, spv, spv2 = td, 0.0, 0.0, 0.0
        v = b.get("v") or 1.0
        tp = (b["h"] + b["l"] + b["c"]) / 3
        sv += v; spv += tp * v; spv2 += tp * tp * v
        m = spv / sv
        vw.append(m); sd.append(max(spv2 / sv - m * m, 0) ** 0.5)
    htf = ema(c, p["htf_ema"]) if p.get("htf_ema") else None
    sig = {}
    for i in range(30, n):
        b = bars[i]
        if sd[i] <= 0 or sd[i - 1] <= 0 or not in_window(b["dt"], *p["window"]):
            continue
        z, zp = (c[i] - vw[i]) / sd[i], (c[i - 1] - vw[i - 1]) / sd[i - 1]
        lo3 = min(x["l"] for x in bars[i - 3:i + 1]); hi3 = max(x["h"] for x in bars[i - 3:i + 1])
        if zp <= -p["z"] < z and htf_ok("long", c[i], htf, i):
            stop, tp = c[i] - lo3 + 0.1 * a[i], vw[i] - c[i]
            if 0 < stop <= 4 * a[i] and tp >= stop * p["min_rr"]:
                sig[i] = ("long", stop, tp)
        elif zp >= p["z"] > z and htf_ok("short", c[i], htf, i):
            stop, tp = hi3 - c[i] + 0.1 * a[i], c[i] - vw[i]
            if 0 < stop <= 4 * a[i] and tp >= stop * p["min_rr"]:
                sig[i] = ("short", stop, tp)
    return {"sig": sig}

# ---------------- 19. Overnight range sweep at the New York open ----------------
# The overnight session (6 PM to 9:30 AM) leaves a high and a low where stops collect. When the
# open runs one of them and then closes back inside, the breakout failed: trade back into the range.
def onsweep_prepare(bars, p, pair=None):
    a = atr(bars)
    rng = {}
    for b in bars:
        if not in_window(b["dt"], [9, 30], [18, 0]):
            r = rng.setdefault(trade_day(b["dt"]), [b["h"], b["l"]])
            r[0], r[1] = max(r[0], b["h"]), min(r[1], b["l"])
    sig, st = {}, {}
    for i, b in enumerate(bars):
        td = trade_day(b["dt"])
        if td not in rng or not in_window(b["dt"], *p["window"]):
            continue
        H, Lo = rng[td]
        s = st.setdefault(td, {"hi": None, "lo": None, "done": False})
        if b["h"] > H:                              # [bar of the first sweep, most extreme price]
            s["hi"] = [i, b["h"]] if s["hi"] is None else [s["hi"][0], max(s["hi"][1], b["h"])]
        if b["l"] < Lo:
            s["lo"] = [i, b["l"]] if s["lo"] is None else [s["lo"][0], min(s["lo"][1], b["l"])]
        if s["done"]:
            continue
        mid = (H + Lo) / 2
        if s["hi"] and b["c"] < H and i - s["hi"][0] <= p["max_back"]:
            stop = s["hi"][1] - b["c"] + p["stop_buf"] * a[i]
            tp = (b["c"] - mid) if p["target"] == "mid" else stop * p["rr"]
            if 0 < stop <= 4 * a[i] and tp >= stop:
                sig[i] = ("short", stop, tp); s["done"] = True
        elif s["lo"] and b["c"] > Lo and i - s["lo"][0] <= p["max_back"]:
            stop = b["c"] - s["lo"][1] + p["stop_buf"] * a[i]
            tp = (mid - b["c"]) if p["target"] == "mid" else stop * p["rr"]
            if 0 < stop <= 4 * a[i] and tp >= stop:
                sig[i] = ("long", stop, tp); s["done"] = True
    return {"sig": sig}

# ---------------- 21. London sweep of the Asian range ("Judas swing") ----------------
# Asia (about 8 PM to 2 AM ET) usually builds a tight range. Early London often runs one side of it
# to take the stops resting there, then reverses. When London pokes past the Asian high/low and closes
# back inside, trade back into the range (target: the middle of the range, or a set reward).
def lonsweep_prepare(bars, p, pair=None):
    a = atr(bars)
    rs, re = p["range"]
    rng = {}
    for b in bars:
        if in_window(b["dt"], rs, re):
            r = rng.setdefault(trade_day(b["dt"]), [b["h"], b["l"]])
            r[0], r[1] = max(r[0], b["h"]), min(r[1], b["l"])
    sig, st = {}, {}
    for i, b in enumerate(bars):
        td = trade_day(b["dt"])
        if td not in rng or not in_window(b["dt"], *p["window"]):
            continue
        H, Lo = rng[td]
        if H - Lo <= 0 or H - Lo > p["max_range_atr"] * a[i] * 4:
            continue                                  # skip days when Asia already moved a lot
        s = st.setdefault(td, {"hi": None, "lo": None, "done": False})
        if b["h"] > H:
            s["hi"] = [i, b["h"]] if s["hi"] is None else [s["hi"][0], max(s["hi"][1], b["h"])]
        if b["l"] < Lo:
            s["lo"] = [i, b["l"]] if s["lo"] is None else [s["lo"][0], min(s["lo"][1], b["l"])]
        if s["done"]:
            continue
        mid = (H + Lo) / 2
        if s["hi"] and b["c"] < H and i - s["hi"][0] <= p["max_back"]:
            stop = s["hi"][1] - b["c"] + p["stop_buf"] * a[i]
            tp = (b["c"] - mid) if p["target"] == "mid" else stop * p["rr"]
            if 0 < stop <= 4 * a[i] and tp >= stop:
                sig[i] = ("short", stop, tp); s["done"] = True
        elif s["lo"] and b["c"] > Lo and i - s["lo"][0] <= p["max_back"]:
            stop = b["c"] - s["lo"][1] + p["stop_buf"] * a[i]
            tp = (mid - b["c"]) if p["target"] == "mid" else stop * p["rr"]
            if 0 < stop <= 4 * a[i] and tp >= stop:
                sig[i] = ("long", stop, tp); s["done"] = True
    return {"sig": sig}

# ---------------- 20. Volatility squeeze breakout (John Carter, "Mastering the Trade") ----------------
# When Bollinger Bands contract inside Keltner Channels the market is coiling. Trade the first
# bar after the squeeze releases, in the direction of momentum.
def squeeze_prepare(bars, p, pair=None):
    n = len(bars)
    c = [b["c"] for b in bars]
    m20, a20 = sma(c, 20), atr(bars, 20)
    a = atr(bars)
    sd = []
    for i in range(n):
        w = c[max(0, i - 19):i + 1]
        mu = sum(w) / len(w)
        sd.append((sum((v - mu) ** 2 for v in w) / len(w)) ** 0.5)
    hh = rolling_ext([b["h"] for b in bars], 20, "max")
    ll = rolling_ext([b["l"] for b in bars], 20, "min")
    sig, run = {}, 0
    for i in range(25, n):
        on = 2 * sd[i] < 1.5 * a20[i]                # Bollinger (2 sd) inside Keltner (1.5 ATR)
        if on:
            run += 1
            continue
        fired, run = run >= p["min_sq"], 0
        if not fired or not in_window(bars[i]["dt"], *p["window"]):
            continue
        mom = c[i] - ((hh[i] + ll[i]) / 2 + m20[i]) / 2
        stop = p["stop_atr"] * a[i]
        if mom > 0:
            sig[i] = ("long", stop, stop * p["rr"])
        elif mom < 0:
            sig[i] = ("short", stop, stop * p["rr"])
    return {"sig": sig}


STRATEGIES = {
    "silver_bullet": (sb_prepare, precomputed_signal),
    "vwap_trama": (vt_prepare, precomputed_signal),
    "smt": (smt_prepare, precomputed_signal),
    "venom": (venom_prepare, precomputed_signal),
    "hourly_sb": (hsb_prepare, precomputed_signal),
    "pdi": (pdi_prepare, precomputed_signal),
    "shulk": (shulk_prepare, precomputed_signal),
    "holy_grail": (hg_prepare, precomputed_signal),
    "gap_fill": (gap_prepare, precomputed_signal),
    "pdhl": (pdhl_prepare, precomputed_signal),
    "snapback": (snap_prepare, precomputed_signal),
    "imom": (imom_prepare, precomputed_signal),
    "volbrk": (volbrk_prepare, precomputed_signal),
    "vwapband": (vwapband_prepare, precomputed_signal),
    "onsweep": (onsweep_prepare, precomputed_signal),
    "squeeze": (squeeze_prepare, precomputed_signal),
    "trend": (trend_prepare, trend_signal),
    "orb": (breakout_prepare, breakout_signal),
    "asia": (breakout_prepare, breakout_signal),
    # London and Asia sessions
    "london": (breakout_prepare, breakout_signal),    # breakout of the Asian range at the London open
    "london_sweep": (lonsweep_prepare, precomputed_signal),
    "asia_fade": (vwapband_prepare, precomputed_signal),   # VWAP band fade during the quiet Asian session
    "pullback": (pullback_prepare, pullback_signal),
}

# What kind of setup each strategy is (the app shows this instead of strategy names)
SETUP = {"silver_bullet": "Reversal", "hourly_sb": "Reversal", "venom": "Reversal", "pdi": "Reversal",
         "shulk": "Reversal", "smt": "Reversal", "pdhl": "Reversal", "vwap_trama": "Momentum", "trend": "Trend",
         "holy_grail": "Pullback", "pullback": "Pullback", "orb": "Breakout", "asia": "Breakout", "gap_fill": "Gap fill",
         "snapback": "Mean reversion", "imom": "Momentum", "volbrk": "Breakout", "vwapband": "Mean reversion",
         "onsweep": "Reversal", "squeeze": "Breakout",
         "london": "Breakout", "london_sweep": "Reversal", "asia_fade": "Mean reversion"}

def get_signal(name, bars, p, pair=None):
    """Live use: signal on the most recent completed bar."""
    prep, sig = STRATEGIES[name]
    return sig(bars, len(bars) - 1, p, prep(bars, p, pair))
