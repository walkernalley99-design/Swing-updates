"""
Swing - automated futures trading for Topstep.

Double-click "Start Swing" (Windows) or "Start Swing.command" (Mac).
It opens a dashboard in your browser where you can:
  - start / stop the bot, or flatten everything
  - see each account's balance, today's P&L, open positions and limits
  - run the backtest and see which strategies passed
  - see your P&L calendar
  - change settings (API key, accounts, risk, practice mode)
Optional: control it from your phone on the same Wi-Fi (Settings > Phone access).
"""
import json, os, re, socket, subprocess, sys, threading, time, webbrowser, secrets
from datetime import datetime
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from http.cookies import SimpleCookie

APP_DIR = os.path.dirname(os.path.abspath(__file__))
PORT = 8765
SETTINGS = os.path.join(APP_DIR, "settings.json")
PRESETS = {  # Topstep account sizes: start balance, max loss limit, profit target, max micros
    "50K": (50_000, 2_000, 3_000, 50), "100K": (100_000, 3_000, 6_000, 100), "150K": (150_000, 4_500, 9_000, 150)}

API = "https://api.topstepx.com/api"
procs = {"bot": None, "backtest": None}
NEWS = {"events": [], "ok": True, "headlines": []}

def news_loop():
    """Keeps the calendar and headlines fresh for the dashboard, even when the bot is off."""
    os.chdir(APP_DIR)
    import news as N
    while True:
        try:
            cfg = N.settings(load_settings().get("news"))
            NEWS["events"], NEWS["ok"] = N.calendar()
            NEWS["headlines"] = N.headlines(cfg["keywords"])
        except Exception:
            pass
        time.sleep(120)
lock = threading.Lock()


def path(name):
    return os.path.join(APP_DIR, name)

def read_json(name, default=None):
    for i in range(10):                        # Windows: a file being swapped in can be busy for a moment
        try:
            with open(path(name)) as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return default
        except PermissionError:
            time.sleep(0.05 * (i + 1))
    return default

_TAIL = {}

def tail(name, lines=150):
    """Last lines of a log. Cached until the file changes (the app asks for these every few seconds)."""
    try:
        st = os.stat(path(name))
    except OSError:
        return []
    key = (name, lines)
    hit = _TAIL.get(key)
    if hit and hit[0] == (st.st_mtime_ns, st.st_size):
        return list(hit[1])
    try:
        with open(path(name), errors="replace") as f:
            if st.st_size > 2_000_000:          # big log: only read the end
                f.seek(st.st_size - 2_000_000)
                f.readline()
            out = f.readlines()[-lines:]
    except FileNotFoundError:
        return []
    _TAIL[key] = ((st.st_mtime_ns, st.st_size), out)
    return list(out)

def load_settings():
    s = None
    for _ in range(5):                       # never treat a busy/unreadable file as "no settings"
        s = read_json("settings.json", None)
        if s is not None or not os.path.exists(SETTINGS):
            break
        time.sleep(0.05)
    if s is None and os.path.exists(SETTINGS) and os.path.getsize(SETTINGS) > 0:
        raise RuntimeError("settings.json can't be read")
    s = s or {}
    s["api_key"] = reveal_secret(s.get("api_key", ""))
    s.setdefault("username", "")
    s.setdefault("api_key", "")
    s.setdefault("mode", "paper" if not s.get("api_key") else ("practice" if s.get("dry_run", True) else "live"))
    s.setdefault("venue", "paper" if s["mode"] == "paper" else "topstep")
    s.setdefault("real_orders", s["mode"] == "live")
    s.setdefault("topstep_accounts", [])
    s["mode"] = "paper" if s["venue"] == "paper" else ("live" if s["real_orders"] else "practice")
    s["dry_run"] = s["mode"] == "practice"
    s.setdefault("accounts", [{"match": "", "type": "combine", "size": "50K", "risk": "auto"}])
    s.setdefault("remote_access", False)
    s.setdefault("news", {})
    s.setdefault("rules", {"giveback": True, "loss_streak_all": False})
    s.setdefault("payouts", [])
    s.setdefault("funded_cost", 200)
    s.setdefault("risk_override", None)          # None = Swing picks from the backtest; a number = $ per trade
    s.setdefault("auto_update", True)            # install new versions by itself (Settings can turn it off)
    s.setdefault("cloud_url", "")                # set: this computer opens the cloud Swing instead of its own
    s.setdefault("monthly_goal", 10000)          # the scale plan aims for this much a month after fees
    s.setdefault("min_pass", 75)                 # Combine sizes must pass at least this % of the time in testing
    s.setdefault("auto_reopt", True)             # re-run the backtest every weekend (and after a setup is benched)
    import notify as NT
    s["notify"] = NT.settings(s.get("notify"))
    s.setdefault("pin", "")                      # old passcode (before accounts); only used to claim the account
    s.setdefault("owner", None)                  # {"name", "salt", "hash"}: the Swing account
    s.setdefault("sessions", {})                 # sign-in token -> expiry (unix time)
    s.setdefault("setup_done", bool(s.get("owner")) or os.path.exists(path("best_config.json")))
    s.setdefault("token", secrets.token_hex(16))
    return s

SETTINGS_LOCK = threading.RLock()

# ---------------- keeping your Topstep API key safe on disk ----------------
# Windows: encrypted with your Windows login (DPAPI), so the file is useless if copied to another PC.
# Linux servers: the settings file is readable only by Swing's own user.
def _dpapi(data, protect):
    import ctypes
    from ctypes import wintypes as w
    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", w.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    buf = ctypes.create_string_buffer(data, len(data))
    blob_in = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    blob_out = BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
    if not fn(ctypes.byref(blob_in), None, None, None, None, 0x1, ctypes.byref(blob_out)):   # 0x1 = no UI
        raise OSError("DPAPI failed")
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)

def protect_secret(v):
    if not v or os.name != "nt":
        return v
    try:
        import base64
        enc = "dpapi:" + base64.b64encode(_dpapi(v.encode(), True)).decode()
        return enc if reveal_secret(enc) == v else v          # only keep it encrypted if it reads back right
    except Exception:
        return v

def reveal_secret(v):
    if not isinstance(v, str) or not v.startswith("dpapi:"):
        return v or ""
    try:
        import base64
        return _dpapi(base64.b64decode(v[6:]), False).decode()
    except Exception:
        return ""

def save_settings(s):
    if "venue" in s:
        s["mode"] = "paper" if s["venue"] == "paper" else ("live" if s.get("real_orders") else "practice")
        s["dry_run"] = s["mode"] == "practice"
    tmp = SETTINGS + ".tmp"
    out = dict(s)
    out["api_key"] = protect_secret(s.get("api_key", ""))
    with SETTINGS_LOCK:                   # write whole, then swap: readers never see a half-written file
        with open(tmp, "w") as f:
            json.dump(out, f, indent=2)
        if os.name != "nt":
            os.chmod(tmp, 0o600)          # only Swing's own user can read it
        for i in range(40):               # Windows refuses the swap while something is reading the file: retry
            try:
                os.replace(tmp, SETTINGS)
                break
            except PermissionError:
                if i == 39:
                    raise
                time.sleep(0.05)

def guess_type(name):
    n = name.upper()
    if "PRAC" in n:
        return "practice"
    if any(k in n for k in ("XFA", "EXPRESS", "EFA", "FUNDED")):
        return "express"
    return "combine"

def guess_size(name, balance):
    n = name.upper()
    for k in ("150K", "100K", "50K"):
        if k in n:
            return k
    b = balance or 50_000
    return "50K" if b < 75_000 else "100K" if b < 125_000 else "150K"

def topstep_login(username, api_key):
    import requests
    try:
        r = requests.post(f"{API}/Auth/loginKey", json={"userName": username, "apiKey": api_key}, timeout=15).json()
    except Exception:
        return None, "Couldn't reach TopstepX. Check your internet connection."
    if not r.get("success"):
        return None, "TopstepX didn't accept that username and API key. Check both and try again."
    sess = requests.Session()
    sess.headers["Authorization"] = f"Bearer {r['token']}"
    return sess, None

def fetch_topstep_accounts(s):
    """Log in and merge the live account list with the saved choices (on/off, type, size, risk)."""
    sess, err = topstep_login(s["username"], s["api_key"])
    if err:
        return err
    try:
        accts = sess.post(f"{API}/Account/search", json={"onlyActiveAccounts": True}, timeout=15).json().get("accounts", [])
    except Exception:
        return "Connected, but couldn't load your accounts. Try Refresh in a minute."
    old = {a["id"]: a for a in s.get("topstep_accounts", [])}
    merged = []
    for x in accts:
        prev = old.get(x["id"], {})
        merged.append({"id": x["id"], "name": x["name"], "balance": x.get("balance"), "can_trade": bool(x.get("canTrade")),
                       "enabled": prev.get("enabled", False), "type": prev.get("type") or guess_type(x["name"]),
                       "size": prev.get("size") or guess_size(x["name"], x.get("balance")), "risk": prev.get("risk", "auto")})
    s["topstep_accounts"] = merged
    s["connected"] = True
    save_settings(s)
    return None

def bot_accounts(s):
    """Convert the app's simple account rows into the bot's ACCOUNTS format."""
    out = []
    for a in s["accounts"]:
        start, mll, target, micros = PRESETS.get(a.get("size", "50K"), PRESETS["50K"])
        combine = a.get("type") == "combine"
        out.append({"match": a.get("match", ""), "type": a.get("type", "combine"), "start_balance": start,
                    "mll": mll, "profit_target": target if combine else 0,
                    "consistency": 0.5 if combine else 0, "max_micros": micros, "risk": a.get("risk", "auto")})
    return out

def running(name):
    p = procs[name]
    return p is not None and p.poll() is None

def child_env(s):
    env = dict(os.environ)
    env["PX_USERNAME"], env["PX_API_KEY"] = s["username"], s["api_key"]
    return env

def start_bot():
    with lock:
        if running("bot"):
            return "The bot is already running."
        s = load_settings()
        if s.get("cloud_url"):
            return "This computer shows your cloud Swing, which does the trading. Nothing runs here."
        if s["mode"] != "paper":
            if not s["username"] or not s["api_key"]:
                return "Connect your Topstep account in Settings, or switch to Paper."
            if not any(a.get("enabled") for a in s["topstep_accounts"]):
                return "Turn on at least one Topstep account in Settings."
        if s["mode"] == "live" and not read_json("best_config.json"):
            return "Run the backtest first. Live trading needs its results."
        try:
            os.remove(path("STOP"))
        except FileNotFoundError:
            pass
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        procs["bot"] = subprocess.Popen([sys.executable, path("topstep_bot.py")], cwd=APP_DIR, env=child_env(s),
                                        stdout=subprocess.DEVNULL, stderr=open_log("bot_errors.log", "a"),
                                        creationflags=flags)
        if not s.get("autostart"):
            s["autostart"] = True
            save_settings(s)
        return None

def stop_bot(flatten=False, remember=True):
    with lock:
        if remember:
            s = load_settings()
            if s.get("autostart"):
                s["autostart"] = False
                save_settings(s)
        if not running("bot"):
            return "The bot isn't running."
        if flatten:
            open(path("STOP"), "w").close()        # bot closes every position, then exits
            try:
                procs["bot"].wait(timeout=60)
            except subprocess.TimeoutExpired:
                procs["bot"].terminate()
        else:
            procs["bot"].terminate()                # open trades keep their stop + target at Topstep
        return None

def open_log(name, mode):
    """Open a log file; if Windows has it locked (another program has it open), use a fresh one."""
    try:
        return open(path(name), mode)
    except PermissionError:
        base, ext = os.path.splitext(name)
        return open(path(f"{base}_{int(time.time())}{ext}"), mode)

def start_backtest(full=False):
    with lock:
        if running("backtest"):
            return "A backtest is already running."
        s = load_settings()
        has_csv = any(os.path.exists(path(f"data/{m}.csv")) or os.path.exists(path(f"data/{m}_api.csv"))
                      for m in ("MNQ", "MES", "MGC"))
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        procs["backtest"] = subprocess.Popen([sys.executable, "-u", path("backtest.py")] + (["--all"] if full else []),
                                             cwd=APP_DIR,
                                             env=child_env(s), stdout=open_log("backtest_output.log", "w"),
                                             stderr=subprocess.STDOUT, creationflags=flags)
        return None

# ---------------- Swing account (username + password) ----------------
SESSION_DAYS = 90
_FAILS = {}            # ip -> [count, first failure time]

def hash_pw(pw, salt):
    import hashlib
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200_000).hex()

def make_owner(name, pw):
    salt = secrets.token_hex(16)
    return {"name": name.strip(), "salt": salt, "hash": hash_pw(pw, salt)}

def check_pw(owner, name, pw):
    return bool(owner) and name.strip().lower() == owner["name"].lower() and \
        secrets.compare_digest(hash_pw(pw, owner["salt"]), owner["hash"])

def new_session(s):
    tok = secrets.token_urlsafe(32)
    now = time.time()
    s["sessions"] = {k: v for k, v in s.get("sessions", {}).items() if v > now}
    s["sessions"][tok] = now + SESSION_DAYS * 86400
    save_settings(s)
    return f"sw={tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_DAYS * 86400}"

def account_problem(name, pw):
    if not re.fullmatch(r"[A-Za-z0-9_.@-]{3,40}", (name or "").strip()):
        return "Pick a username of 3+ letters or numbers (no spaces)."
    if len(pw or "") < 8:
        return "Use a password of at least 8 characters."
    return None

def listening_remote(s):
    return bool(s["remote_access"] and (s.get("owner") or s.get("pin")))

def lan_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sk:
            sk.connect(("8.8.8.8", 80))
            return sk.getsockname()[0]
    except OSError:
        return "127.0.0.1"

def news_cfg(s):
    import news as N
    return N.settings(s.get("news"))

ACTIVITY = re.compile(r"ENTERED|STOPPED|first target|EOD|reversal|DRY RUN|Kill switch|FLATTENED|exit time|NEWS|VOLATILITY|no stop")

_ACT = {"key": None, "lines": []}

def activity():
    try:
        st = os.stat(path("bot.log"))
        key = (st.st_mtime_ns, st.st_size)
    except OSError:
        return []
    if key != _ACT["key"]:
        _ACT.update(key=key, lines=[l for l in tail("bot.log", 4000) if ACTIVITY.search(l)][-150:])
    return list(_ACT["lines"])

def state():
    s = load_settings()
    status = read_json("status.json", {}) or {}
    fresh = bool(status) and time.time() - status.get("ts", 0) < 120
    report = "".join(tail("backtest_report.txt", 400))
    return {
        "bot": {"running": running("bot"), "dry_run": s["mode"] == "practice", "mode": s["mode"]},
        "paper": read_json("paper_state.json"),
        "backtest": {"running": running("backtest"), "output": tail("backtest_output.log", 60), "report": report},
        "status": status if fresh else {},
        "config": read_json("best_config.json"),
        "picks": picks_list(),
        "history": read_json("bot_state.json", {}) or {},
        "log": tail("bot.log", 200),
        "activity": activity(),
        "briefs": (read_json("briefs.json", []) or [])[-10:],
        "news": {"events": NEWS["events"], "ok": NEWS["ok"], "headlines": NEWS["headlines"],
                 "cfg": news_cfg(s)},
        "errors": tail("bot_errors.log", 20) if not running("bot") else [],
        "starting": ([l.strip() for l in tail("bot_errors.log", 3) if l.strip()][-1:] or [""])[0]
                    if running("bot") and not fresh else "",
        "settings": {"username": s["username"], "has_key": bool(s["api_key"]), "dry_run": s["dry_run"], "mode": s["mode"],
                     "accounts": s["accounts"], "remote_access": s["remote_access"], "account": (s.get("owner") or {}).get("name"),
                     "setup_done": s.get("setup_done"), "host": s.get("host", "pc"), "cloud_url": s.get("cloud_url"),
                     "auto_update": s.get("auto_update", True), "version": local_version(),
                     "update": dict(UPDATE, feed=bool(feed_url(s))),
                     "venue": s["venue"], "real_orders": s["real_orders"], "connected": bool(s.get("connected")),
                     "topstep_accounts": s["topstep_accounts"], "rules": s["rules"], "notify": s["notify"],
                     "payouts": s["payouts"], "funded_cost": s["funded_cost"], "risk_override": s["risk_override"],
                     "min_pass": s["min_pass"], "monthly_goal": s["monthly_goal"], "auto_reopt": s["auto_reopt"], "last_reopt": s.get("last_reopt"),
                     "phone_url": f"http://{lan_ip()}:{PORT}",
                     "anywhere_url": (tailscale_https() or f"http://{tailscale_ip()}:{PORT}") if s["remote_access"] and tailscale_ip() else None},
        "ui_version": ui_version(),
        "server_utc_offset": int(datetime.now().astimezone().utcoffset().total_seconds() // 60),
    }


PROGRAM = ("version.json", "app.py", "topstep_bot.py", "strategies.py", "backtest.py", "news.py", "notify.py", "paper.py",
           "dashboard.html", "icon.png", "icon.ico", "README.txt", "install_cloud.sh", "install_pi.sh",
           "Swing.vbs", "Start Swing.bat", "Add Desktop Icon.bat")

UPDATABLE = re.compile(r"^(?:[\w .-]+/)?([A-Za-z_]+\.py|dashboard\.html|version\.json|install_\w+\.sh|README\.txt|"
                       r"icon\.(?:png|ico)|Start Swing\.(?:bat|command)|Add Desktop Icon\.bat|Swing\.vbs)$")

def install_zip(data):
    """Install Swing's program files from a Swing.zip. Settings, keys, history and results are never touched.
    The running app notices the new files and restarts itself on them."""
    import io, zipfile
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        return "That isn't a Swing.zip file.", 0
    files = {}
    for info in z.infolist():
        m = UPDATABLE.match(info.filename)
        if m and not info.is_dir() and ".." not in info.filename:
            files[m.group(1)] = z.read(info)
    if "app.py" not in files or "topstep_bot.py" not in files:
        return "That zip doesn't look like Swing (no app.py / topstep_bot.py).", 0
    for name, blob in files.items():          # write each file whole, then swap it in
        tmp = path(name + ".new")
        with open(tmp, "wb") as f:
            f.write(blob)
        os.replace(tmp, path(name))
    print(f"Update installed: {len(files)} files. Restarting with the new version.")
    return None, len(files)

# ---------------- automatic updates ----------------
# Swing checks a small "latest.json" file online every few hours:
#   {"version": "2026.11.03.2", "zip": "https://.../Swing.zip", "sha256": "...", "notes": "What's new"}
# When there's a newer version it downloads Swing.zip, checks it isn't damaged (sha256), and installs it
# while no trade is open. Turn it off in Settings.
UPDATE_FEED = "https://raw.githubusercontent.com/walkernalley99-design/swing-updates/main/latest.json"
UPDATE = {"checked": None, "latest": None, "notes": None, "error": None, "pending": False}

def local_version():
    v = read_json("version.json", {}) or {}
    return v.get("version", "0")

def _vkey(v):
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-]", str(v)))

def feed_url(s):
    u = (s.get("update_feed") or UPDATE_FEED or "").strip()
    return "" if "OWNER/REPO" in u else u

def trades_open():
    st = read_json("status.json", {}) or {}
    return any(a.get("positions") for a in st.get("accounts", []))

def check_update(install=True):
    """Look for a newer Swing; install it when it's safe. Returns a short message."""
    import hashlib
    import requests as rq
    s = load_settings()
    url = feed_url(s)
    if not url:
        UPDATE["error"] = "Automatic updates aren't set up for this copy yet."
        return UPDATE["error"]
    try:
        info = rq.get(url, timeout=15, headers={"Cache-Control": "no-cache"}).json()
    except Exception as e:
        UPDATE["error"] = f"Couldn't check for updates ({type(e).__name__})."
        return UPDATE["error"]
    UPDATE.update(checked=time.strftime("%b %d %I:%M %p"), latest=info.get("version"), notes=info.get("notes"), error=None)
    if _vkey(info.get("version", "0")) <= _vkey(local_version()):
        UPDATE["pending"] = False
        return "Swing is up to date."
    if not install:
        UPDATE["pending"] = True
        return f"Version {info.get('version')} is available."
    if trades_open():
        UPDATE["pending"] = True
        return "An update is ready. It installs once no trade is open."
    try:
        blob = rq.get(info["zip"], timeout=60).content
    except Exception as e:
        UPDATE["error"] = f"Couldn't download the update ({type(e).__name__})."
        return UPDATE["error"]
    if info.get("sha256") and hashlib.sha256(blob).hexdigest() != info["sha256"].lower():
        UPDATE["error"] = "The update download was damaged. Swing will try again later."
        return UPDATE["error"]
    err, _ = install_zip(blob)
    if err:
        UPDATE["error"] = err
        return err
    UPDATE["pending"] = False
    return f"Updated to {info.get('version')}. Restarting…"

def _auto_update():
    time.sleep(90)                              # let Swing settle after starting
    while True:
        try:
            if load_settings().get("auto_update", True) and not running("backtest"):
                check_update(install=True)
        except Exception as e:
            UPDATE["error"] = f"Update check failed ({type(e).__name__})."
        time.sleep(30 * 60 if UPDATE.get("pending") else 3 * 3600)

def support_zip():
    """Logs and results for getting help. Never includes your API key, password or sign-ins."""
    import io, zipfile
    s = load_settings()
    safe = {k: v for k, v in s.items() if k not in ("api_key", "owner", "sessions", "pin", "token", "notify")}
    safe["username"] = "(set)" if s.get("username") else ""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("settings (no secrets).json", json.dumps(safe, indent=2))
        z.writestr("about.txt", f"Swing {local_version()} on {sys.platform}, Python {sys.version.split()[0]}\n")
        for f in ("bot.log", "bot_errors.log", "app_output.log", "app_errors.log", "backtest_output.log", "backtest_report.txt",
                  "status.json", "best_config.json", "version.json"):
            if os.path.exists(path(f)):
                z.writestr(f, "".join(tail(f, 3000)) if f.endswith(".log") else open(path(f), errors="replace").read())
        # everything needed to review the trading itself: every fill, the saved picks and the price history
        for f in ("bot_state.json", "paper_state.json", "setup_ledger.json", "live_state.json"):
            if os.path.exists(path(f)):
                z.write(path(f), f)
        if not os.path.exists(path("data/long/updated.txt")):
            t = threading.Thread(target=long_history, daemon=True)   # first time: try to fetch it now
            t.start()
            t.join(timeout=100)
        elif not os.path.exists(path("data/long/MNQ_1m.csv")):
            t = threading.Thread(target=long_history, kwargs={"force": True}, daemon=True)   # add the 1-minute data
            t.start()
            t.join(timeout=150)
        for folder in ("picks", "data", "data/long"):
            d = path(folder)
            if os.path.isdir(d):
                for fn in sorted(os.listdir(d)):
                    fp = os.path.join(d, fn)
                    if fn.endswith((".json", ".csv", ".txt")) and os.path.getsize(fp) < 40_000_000:
                        z.write(fp, f"{folder}/{fn}")
    return buf.getvalue()

def picks_list():
    """Every saved set of backtest picks, newest first, with how it actually traded while it was in use."""
    log_ = read_json("picks/log.json", []) or []
    if not log_:
        return []
    trips = []
    for acct in (read_json("bot_state.json", {}) or {}).values():
        if isinstance(acct, dict):
            for d in (acct.get("days") or {}).values():
                trips += [t for t in d.get("trips") or [] if t.get("exit_time") or t.get("time")]
    stamp = lambda t: datetime.fromisoformat(t.get("exit_time") or t["time"]).timestamp()
    res = {}
    for i, e in enumerate(log_):
        end = log_[i + 1]["from"] if i + 1 < len(log_) else 9e18
        r = res.setdefault(e["id"], {"trades": 0, "wins": 0, "net": 0.0, "days": 0.0, "last": 0})
        r["days"] += (min(end, time.time()) - e["from"]) / 86400
        r["last"] = max(r["last"], e["from"])
        for t in trips:
            try:
                if e["from"] <= stamp(t) < end:
                    r["trades"] += 1
                    r["wins"] += (t.get("net") or 0) > 0
                    r["net"] += t.get("net") or 0
            except (ValueError, TypeError):
                pass
    cur = log_[-1]["id"]
    out = []
    for pid, r in sorted(res.items(), key=lambda kv: -kv[1]["last"]):
        c = read_json(f"picks/{pid}.json")
        if not c:
            continue
        out.append({"id": pid, "label": c.get("label"), "generated": c.get("generated"), "markets": sorted((c.get("markets") or {}).keys()),
                    "pass": c.get("combine_pass_rate"), "current": pid == cur, "trades": r["trades"],
                    "wins": r["wins"], "net": round(r["net"], 2), "days": round(r["days"], 1)})
    return out[:12]

# The picks Swing ran on Monday Nov 2, 2026 (its +$740 day), read back from the bot's own log. They were
# overwritten by later backtests before picks were being saved, so they're restored here as a saved set.
MONDAY_ID, MONDAY_FROM, MONDAY_TO = "1793483957", 1793483957.0, 1793802210.0
MONDAY_PICKS = {
    "generated": "2026-10-31T17:59", "generated_ts": MONDAY_FROM, "risk_per_trade": 200, "short_data": True,
    "label": "Monday Nov 2 picks (restored)",
    "markets": {
        "MNQ": {"strategy": "asia", "params": {"range_start": [20, 0], "range_min": 60, "entry_end": [1, 0],
                                               "stop_frac": 0.5, "rr": 2.0, "exit": [3, 0]}},
        "MES": {"strategy": "hourly_sb", "params": {"sessions": [[9, 0]], "stop_buf": 0.1, "target": "liq", "rr": 2.0,
                                                    "no_eq": True, "partial": True}},
        "MCL": {"strategy": "silver_bullet", "params": {
            "windows": [[[3, 0], [4, 0]], [[10, 0], [11, 0]], [[14, 0], [15, 0]]], "lookback": 24, "sweep_bars": 6,
            "stop_buf": 0.1, "rr": 2.0, "htf_ema": 0, "vol_mult": 0, "partial": False}},
    },
}

def restore_monday_picks():
    try:
        os.makedirs(path("picks"), exist_ok=True)
        fp = path(f"picks/{MONDAY_ID}.json")
        if os.path.exists(fp):
            return
        c = json.loads(json.dumps(MONDAY_PICKS))
        for m in c["markets"].values():
            m.update(shock_filter=True, skip_lunch=False, loss_streak_stop=True)
            m["legs"] = [dict(m)]
        with open(fp, "w") as f:
            json.dump(c, f)
        log_ = read_json("picks/log.json", []) or []
        if not log_:                                  # no history yet: the picks in use now come after these
            cur = read_json("best_config.json") or {}
            cid = str(int(cur.get("generated_ts") or 0))
            if cur and cid != "0":
                with open(path(f"picks/{cid}.json"), "w") as f:
                    json.dump(cur, f)
                log_ = [{"id": cid, "from": cur["generated_ts"]}]
        # in use from Oct 31 until the afternoon of Nov 4; "gap" marks picks that were never saved
        log_ = [{"id": MONDAY_ID, "from": MONDAY_FROM}, {"id": "gap", "from": MONDAY_TO}] + \
               [e for e in log_ if e.get("from", 0) > MONDAY_TO]
        with open(path("picks/log.json"), "w") as f:
            json.dump(log_[-30:], f)
    except Exception:
        import traceback
        traceback.print_exc()

_LONG_LOCK = threading.Lock()

def long_history(force=False):
    if not _LONG_LOCK.acquire(blocking=False):
        return                                        # already downloading
    try:
        _long_history(force)
    finally:
        _LONG_LOCK.release()

def _long_history(force=False):
    """Research data: 2 years of hourly and 10 years of daily prices for every market (free from Yahoo).
    Not used for trading; it's what lets new setups be tested over many market conditions, not 12 weeks.
    Refreshed once a day, saved in data/long/ and included in the support file, with a note of what worked."""
    d = path("data/long")
    os.makedirs(d, exist_ok=True)
    stamp = os.path.join(d, "updated.txt")
    if not force and os.path.exists(stamp) and time.time() - os.path.getmtime(stamp) < 20 * 3600:
        return
    notes = [time.strftime("%Y-%m-%d %H:%M")]
    try:
        import requests as rq
        from paper import yahoo_bars, FEED
    except Exception as e:
        notes.append(f"setup failed: {e!r}")
        FEED = {}
    sess = rq.Session() if FEED else None
    got = 0
    for sym, (ysym, _, _) in FEED.items():
        for interval, ranges in (("1h", ("730d", "2y", "1y")), ("1d", ("10y", "5y"))):
            bars, err = None, None
            for rng in ranges:
                try:
                    bars = yahoo_bars(sess, ysym, rng=rng, interval=interval)
                    if bars:
                        break
                except Exception as e:
                    err = repr(e)[:120]
                time.sleep(1)
            if not bars:
                notes.append(f"{sym} {interval}: failed ({err})")
                continue
            tmp = os.path.join(d, f"{sym}_{interval}.csv.tmp")
            with open(tmp, "w") as f:
                f.write("time,open,high,low,close,volume\n")
                for b in bars:
                    f.write(f"{b['t']},{b['o']},{b['h']},{b['l']},{b['c']},{b['v']}\n")
            os.replace(tmp, os.path.join(d, f"{sym}_{interval}.csv"))
            notes.append(f"{sym} {interval}: {len(bars)} bars from {bars[0]['t'][:10]}")
            got += 1
            time.sleep(1.5)
    # 1-minute prices: Yahoo keeps about 30 days, a week per request. Swing keeps adding to its own file, so
    # the history grows. This is what a 1-minute entry model (sweep, then inversion) needs to be tested.
    for sym in ("MNQ", "MES", "MGC", "MCL"):
        if sym not in FEED:
            continue
        fp = os.path.join(d, f"{sym}_1m.csv")
        rows = {}
        if os.path.exists(fp):
            try:
                with open(fp) as f:
                    next(f)
                    for line in f:
                        rows[line.split(",", 1)[0]] = line.rstrip("\n")
            except (OSError, StopIteration):
                rows = {}
        before, now_, err = len(rows), time.time(), None
        for wk in range(4, -1, -1):
            a, b = now_ - (wk + 1) * 6 * 86400, now_ - wk * 6 * 86400
            if a < now_ - 29 * 86400:
                a = now_ - 29 * 86400
            try:
                for x in yahoo_bars(sess, FEED[sym][0], interval="1m", period=(a, b)):
                    rows[x["t"]] = f"{x['t']},{x['o']},{x['h']},{x['l']},{x['c']},{x['v']}"
            except Exception as e:
                err = repr(e)[:100]
            time.sleep(1.5)
        if rows:
            with open(fp + ".tmp", "w") as f:
                f.write("time,open,high,low,close,volume\n" + "\n".join(rows[k] for k in sorted(rows)) + "\n")
            os.replace(fp + ".tmp", fp)
        notes.append(f"{sym} 1m: {len(rows)} bars (+{len(rows) - before})" + (f", last error {err}" if err else ""))
    with open(os.path.join(d, "status.txt"), "w") as f:
        f.write("\n".join(notes) + "\n")
    if got:
        with open(stamp, "w") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M"))

def _long_history_loop():
    time.sleep(20)
    while True:
        try:
            long_history()
        except Exception:
            pass
        time.sleep(6 * 3600)

# Picks chosen by research on 2.4 years of hourly and 10 years of daily prices (Nov 13, 2026), instead of the
# weekly 12-week backtest, whose picks lost money the week after in 4 of 6 weeks when replayed.
RESEARCH_ID = "1794830000"
NY = [[9, 45], [15, 30]]
DAY = {"shock_filter": True, "skip_lunch": False, "loss_streak_stop": True}
RESEARCH_PICKS = {
    "generated": "2026-11-16T07:00", "generated_ts": 1794830000.0, "risk_per_trade": 200,
    "label": "Overnight drift + New York",
    "note": ("Chosen by testing on 2.4 years of hourly prices, not the weekly backtest. It's the one idea that made "
             "money both in the year it was picked on and the 16 months after: buy 1 S&P micro at the 6 PM ET "
             "reopen, sell at 9 AM ET, with a safety stop 2% below. In those tests a 50K account earned about "
             "$350 a month on average, and had about a 1 in 5 chance of hitting the max loss limit within 6 months. "
             "Recent weeks have been a weak stretch for it. New York hours (9:45 AM to 3:30 PM ET) add the four day "
             "setups that held up best on your last 12 weeks: Nasdaq pullback, Gold VWAP, Oil trend and Oil VWAP. "
             "No day setup passed the multi-year test, and picked in advance these came out roughly break-even, so "
             "treat them as a test on paper."),
    "markets": {
        "MES": {"strategy": "overnight_drift",
                "params": {"start": [18, 0], "start_end": [18, 30], "stop_pct": 2.0, "rr": 20, "exit": [9, 0],
                           "fixed_size": 1}},
        "MNQ": {"strategy": "holy_grail", "params": {"adx_min": 25, "partial": True, "rr": 1.5, "window": NY}, **DAY},
        "MGC": {"strategy": "vwap_trama", "params": {"htf_ema": 240, "partial": False, "rr": 1.5, "rsi_mode": "none",
                                                     "stop_atr": 1.5, "trama_len": 50, "window": NY}, **DAY},
        "MCL": {"strategy": "trend", **DAY, "legs_": [
            ("trend", {"fast": 9, "rr": 2.0, "slow": 21, "stop_atr": 2.0, "window": NY}),
            ("vwap_trama", {"htf_ema": 0, "partial": False, "rr": 2.5, "rsi_mode": "none", "stop_atr": 1.5,
                            "trama_len": 50, "window": NY})]},
    },
}

def apply_research_picks():
    """One time: save the researched picks, make them the active ones and stop the weekly re-run from replacing
    them. Past picks keeps everything else, so any earlier set is one tap away."""
    try:
        s = load_settings()
        if s.get("research_v2"):
            return
        os.makedirs(path("picks"), exist_ok=True)
        c = json.loads(json.dumps(RESEARCH_PICKS))
        for sym, m in c["markets"].items():
            if sym == "MES":
                m.update(shock_filter=False, skip_lunch=False, loss_streak_stop=False)
            legs = m.pop("legs_", None)
            if legs:
                m["params"] = legs[0][1]
                m["legs"] = [dict(strategy=n, params=p, **DAY) for n, p in legs]
            else:
                m["legs"] = [dict(m)]
        with open(path(f"picks/{RESEARCH_ID}.json"), "w") as f:
            json.dump(c, f)
        cur = read_json("best_config.json") or {}
        log_ = read_json("picks/log.json", []) or []
        cid = str(int(cur.get("generated_ts") or 0))
        if cur and cid != "0" and not os.path.exists(path(f"picks/{cid}.json")):
            with open(path(f"picks/{cid}.json"), "w") as f:
                json.dump(cur, f)
            log_.append({"id": cid, "from": cur["generated_ts"]})
            with open(path("picks/log.json"), "w") as f:
                json.dump(log_[-30:], f)
        use_picks(RESEARCH_ID)
        s = load_settings()
        s["research_v1"] = s["research_v2"] = True
        s["auto_reopt"] = False
        save_settings(s)
    except Exception:
        import traceback
        traceback.print_exc()

def enable_backtest_v3():
    """The backtest now tests all 10 markets, keeps the researched overnight model when it passes its multi-year
    check, and only accepts a day setup when most of its settings made money. So the weekly re-run is back on."""
    try:
        s = load_settings()
        if not s.get("research_v3"):
            s["research_v3"] = True
            s["auto_reopt"] = True
            save_settings(s)
    except Exception:
        pass

def fresh_start_v4():
    """One time (Nov 16, 2026): start fresh on the 1-minute sweep-and-inversion model only. Older picks stay saved
    under Edge, Older picks. The backtest now tests just this model unless 'full' is asked for."""
    try:
        s = load_settings()
        if s.get("fresh_v4"):
            return
        import backtest as B
        leg = {"strategy": "sweep1m", "params": dict(B.SWEEP_DEFAULT), "shock_filter": True, "skip_lunch": False,
               "loss_streak_stop": True, "tested": {"status": "trial", "days": 0}}
        cfg = {"generated": time.strftime("%Y-%m-%dT%H:%M"), "generated_ts": time.time(), "risk_per_trade": 200,
               "focus": "sweep", "label": "Sweep and inversion", "note": B.SWEEP_NOTE,
               "markets": {m: dict(leg, legs=[dict(leg)]) for m in B.SWEEP_MARKETS}}
        os.makedirs(path("picks"), exist_ok=True)
        pid = str(int(cfg["generated_ts"]))
        cur = read_json("best_config.json") or {}
        log_ = read_json("picks/log.json", []) or []
        cid = str(int(cur.get("generated_ts") or 0))
        if cur and cid != "0" and not os.path.exists(path(f"picks/{cid}.json")):
            with open(path(f"picks/{cid}.json"), "w") as f:
                json.dump(cur, f)
            log_.append({"id": cid, "from": cur["generated_ts"]})
            with open(path("picks/log.json"), "w") as f:
                json.dump(log_[-30:], f)
        with open(path(f"picks/{pid}.json"), "w") as f:
            json.dump(cfg, f)
        use_picks(pid)
        s = load_settings()
        s.update(fresh_v4=True, focus="sweep", auto_reopt=True, research_v1=True, research_v2=True, research_v3=True)
        save_settings(s)
        threading.Thread(target=long_history, kwargs={"force": True}, daemon=True).start()   # get the 1-minute prices
    except Exception:
        import traceback
        traceback.print_exc()

def sweep_windows_v5():
    """One time: add the London open (3-5 AM ET) to the sweep model in the picks already in use."""
    try:
        s = load_settings()
        if s.get("sweep_v5"):
            return
        import backtest as B
        c = read_json("best_config.json") or {}
        changed = False
        for m in (c.get("markets") or {}).values():
            for leg in [m] + (m.get("legs") or []):
                if leg.get("strategy") == "sweep1m" and leg["params"].get("windows") != B.SWEEP_WINDOWS:
                    leg["params"]["windows"] = B.SWEEP_WINDOWS
                    changed = True
        if changed:
            if c.get("focus") == "sweep":
                c["note"] = B.SWEEP_NOTE
            tmp = path("best_config.json.tmp")
            with open(tmp, "w") as f:
                json.dump(c, f, indent=2)
            os.replace(tmp, path("best_config.json"))
            pid = str(int(c.get("generated_ts") or 0))
            if os.path.exists(path(f"picks/{pid}.json")):
                with open(path(f"picks/{pid}.json"), "w") as f:
                    json.dump(c, f)
            if running("bot"):
                stop_bot(False, remember=False)
                time.sleep(1)
                start_bot()
        s = load_settings()
        s["sweep_v5"] = True
        save_settings(s)
    except Exception:
        import traceback
        traceback.print_exc()

def sweep_partials_v6():
    """One time: turn on partial profits for the sweep model in the picks already in use."""
    try:
        s = load_settings()
        if s.get("sweep_v6"):
            return
        c = read_json("best_config.json") or {}
        changed = False
        for m in (c.get("markets") or {}).values():
            for leg in [m] + (m.get("legs") or []):
                if leg.get("strategy") == "sweep1m" and not leg["params"].get("partial"):
                    leg["params"]["partial"] = True
                    changed = True
        if changed:
            if c.get("focus") == "sweep":
                import backtest as B
                c["note"] = B.SWEEP_NOTE
            tmp = path("best_config.json.tmp")
            with open(tmp, "w") as f:
                json.dump(c, f, indent=2)
            os.replace(tmp, path("best_config.json"))
            pid = str(int(c.get("generated_ts") or 0))
            if os.path.exists(path(f"picks/{pid}.json")):
                with open(path(f"picks/{pid}.json"), "w") as f:
                    json.dump(c, f)
            if running("bot"):
                stop_bot(False, remember=False)
                time.sleep(1)
                start_bot()
        s = load_settings()
        s["sweep_v6"] = True
        save_settings(s)
    except Exception:
        import traceback
        traceback.print_exc()

def sweep_rules_v7():
    """One time (Nov 17, 2026): the stricter sweep rules - session levels, SMT, wider minimum stop, one trade per
    window, London 2-5 AM and New York 9:30-11 AM ET only (evening dropped)."""
    try:
        s = load_settings()
        if s.get("sweep_v7"):
            return
        import backtest as B
        c = read_json("best_config.json") or {}
        changed = False
        for m in (c.get("markets") or {}).values():
            for leg in [m] + (m.get("legs") or []):
                if leg.get("strategy") == "sweep1m":
                    leg["params"] = dict(B.SWEEP_DEFAULT)
                    leg["tested"] = {"status": "trial", "days": (leg.get("tested") or {}).get("days", 0)}
                    changed = True
        if changed:
            if c.get("focus") == "sweep":
                c["note"] = B.SWEEP_NOTE
            tmp = path("best_config.json.tmp")
            with open(tmp, "w") as f:
                json.dump(c, f, indent=2)
            os.replace(tmp, path("best_config.json"))
            pid = str(int(c.get("generated_ts") or 0))
            if os.path.exists(path(f"picks/{pid}.json")):
                with open(path(f"picks/{pid}.json"), "w") as f:
                    json.dump(c, f)
            if running("bot"):
                stop_bot(False, remember=False)
                time.sleep(1)
                start_bot()
        s = load_settings()
        s["sweep_v7"] = True
        save_settings(s)
    except Exception:
        import traceback
        traceback.print_exc()

def use_picks(pid):
    if not re.fullmatch(r"\d+", str(pid or "")) or not os.path.exists(path(f"picks/{pid}.json")):
        return "Those picks aren't saved anymore."
    if running("backtest"):
        return "Wait for the backtest to finish first."
    c = read_json(f"picks/{pid}.json")
    tmp = path("best_config.json.tmp")
    with open(tmp, "w") as f:
        json.dump(c, f, indent=2)
    os.replace(tmp, path("best_config.json"))
    log_ = read_json("picks/log.json", []) or []
    log_.append({"id": str(pid), "from": time.time()})
    with open(path("picks/log.json"), "w") as f:
        json.dump(log_[-30:], f)
    if running("bot"):
        stop_bot(False, remember=False)
        time.sleep(1)
        return start_bot()
    return None

def trades_csv():
    """Every finished trade Swing has recorded, for your records or taxes."""
    import csv, io
    hist = read_json("bot_state.json", {}) or {}
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["date", "account", "market", "side", "contracts", "setup", "session", "entry time", "exit time",
                "entry", "exit", "stop", "net P&L ($)", "result"])
    rows = []
    for acct in hist.values():
        if not isinstance(acct, dict):
            continue
        for day, d in (acct.get("days") or {}).items():
            for t in d.get("trips") or []:
                rows.append([day, t.get("account", acct.get("name", "")), t.get("market"), t.get("side"), t.get("size"),
                             t.get("strategy"), t.get("session"), t.get("time"), t.get("exit_time"), t.get("entry"),
                             t.get("exit"), t.get("stop"), t.get("net"), t.get("outcome")])
    for r in sorted(rows, key=lambda r: str(r[7])):
        w.writerow(r)
    return out.getvalue().encode("utf-8-sig")

def package_zip():
    """Swing's program files (never settings, keys or history) as Swing.zip."""
    import io, zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in PROGRAM:
            if os.path.exists(path(f)):
                z.write(path(f), "Swing/" + f)
    return buf.getvalue()

def page():
    """Read fresh from disk, so an updated dashboard shows up on the computer and phone without a restart."""
    try:
        with open(path("dashboard.html"), encoding="utf-8") as f:
            return f.read()
    except OSError:
        return "missing dashboard.html"

def ui_version():
    try:
        return int(os.path.getmtime(path("dashboard.html")))
    except OSError:
        return 0

_TS = {"ip": None, "at": 0}

_TSH = {"url": None, "at": 0}

def tailscale_https():
    """A secure https:// address for this Swing on your Tailscale network, when Tailscale HTTPS is serving it."""
    if time.time() - _TSH["at"] < 300:
        return _TSH["url"]
    url = None
    for exe in ("tailscale", r"C:\Program Files\Tailscale\tailscale.exe"):
        try:
            kw = dict(capture_output=True, text=True, timeout=5,
                      creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            serve = subprocess.run([exe, "serve", "status", "--json"], **kw).stdout
            if str(PORT) not in serve:
                break
            name = json.loads(subprocess.run([exe, "status", "--json"], **kw).stdout)["Self"]["DNSName"].rstrip(".")
            url = f"https://{name}"
            break
        except (OSError, subprocess.SubprocessError, ValueError, KeyError):
            continue
    _TSH.update(url=url, at=time.time())
    return url

def tailscale_ip():
    """This computer's private Tailscale address (reachable from your phone anywhere), if Tailscale is installed."""
    if time.time() - _TS["at"] < 60:
        return _TS["ip"]
    ip = None
    for exe in ("tailscale", r"C:\Program Files\Tailscale\tailscale.exe"):
        try:
            out = subprocess.run([exe, "ip", "-4"], capture_output=True, text=True, timeout=4,
                                 creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0).stdout.split()
            if out and out[0].startswith("100."):
                ip = out[0]
                break
        except (OSError, subprocess.SubprocessError):
            continue
    _TS.update(ip=ip, at=time.time())
    return ip

class Server(ThreadingHTTPServer):
    """Only one Swing may listen on the port. (Windows otherwise lets a second copy share it,
    and the two copies would answer at random and both trade.)"""
    allow_reuse_address = os.name != "nt"

    def server_bind(self):
        if os.name == "nt":
            self.socket.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", -5), 1)
        super().server_bind()

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def local(self):
        """A request from this same computer (also when it uses the computer's own network address)."""
        return self.client_address[0] in ("127.0.0.1", "::1", lan_ip())

    def admin(self):
        """Keys, access and updates: whoever is signed in to the Swing account."""
        return self.authed()

    def authed(self):
        """Signed in to the Swing account."""
        s = load_settings()
        if not s.get("owner"):
            return False                     # first, create the account (sign-in page)
        c = SimpleCookie(self.headers.get("Cookie", ""))
        tok = c["sw"].value if "sw" in c else None
        return bool(tok) and s.get("sessions", {}).get(tok, 0) > time.time()

    def login_state(self):
        s = load_settings()
        return {"login": True, "setup": not s.get("owner"), "need_pin": not s.get("owner") and not self.local()
                and bool(s.get("pin")), "blocked": not s.get("owner") and not self.local() and not s.get("pin")}

    def account_api(self, b):
        """Sign in, create the account, sign out, change password."""
        s = load_settings()
        ip = self.client_address[0]
        if self.path == "/api/login":
            f = _FAILS.get(ip)
            if f and f[0] >= 8 and time.time() - f[1] < 600:
                return self.send(429, json.dumps({"error": "Too many tries. Wait 10 minutes."}))
            if check_pw(s.get("owner"), b.get("name", ""), b.get("password", "")):
                _FAILS.pop(ip, None)
                return self.send(200, "{}", extra={"Set-Cookie": new_session(s)})
            time.sleep(1)
            f = _FAILS.setdefault(ip, [0, time.time()])
            f[0] += 1
            return self.send(403, json.dumps({"error": "Wrong username or password."}))
        if self.path == "/api/account/create":
            if s.get("owner"):
                return self.send(400, json.dumps({"error": "This Swing already has an account. Sign in instead."}))
            if not self.local() and not (s.get("pin") and b.get("pin") == s["pin"]):
                return self.send(403, json.dumps({"error": "Enter the passcode you picked when you installed Swing."
                                                  if s.get("pin") else "Create the account on the computer Swing runs on."}))
            err = account_problem(b.get("name"), b.get("password"))
            if err:
                return self.send(400, json.dumps({"error": err}))
            if not b.get("accept_terms"):
                return self.send(400, json.dumps({"error": "Read and accept the terms to use Swing."}))
            s["owner"] = make_owner(b["name"], b["password"])
            s["terms_accepted"] = time.strftime("%Y-%m-%d %H:%M")
            s["pin"] = ""
            return self.send(200, "{}", extra={"Set-Cookie": new_session(s)})
        if self.path == "/api/account/link":
            # "I already have a Swing account": sign in with the account from your cloud Swing. This computer
            # then opens that Swing (same trades, settings and history everywhere) and stops trading on its own.
            if s.get("owner"):
                return self.send(400, json.dumps({"error": "This Swing already has an account. Sign in instead."}))
            if not self.local():
                return self.send(403, json.dumps({"error": "Do this on the computer Swing runs on."}))
            u = (b.get("url") or "").strip().rstrip("/")
            if u and not u.startswith("http"):
                u = "http://" + u
            if not re.fullmatch(r"https?://[\w.\-]+(:\d+)?", u or ""):
                return self.send(400, json.dumps({"error": "Enter your Swing's address, like http://100.72.165.2:8765"}))
            import requests as rq
            try:
                r = rq.post(u + "/api/login", json={"name": b.get("name", ""), "password": b.get("password", "")}, timeout=10)
            except Exception:
                return self.send(400, json.dumps({"error": "Can't reach that Swing. Is Tailscale on and signed in on this computer?"}))
            if r.status_code == 404:
                return self.send(400, json.dumps({"error": "That Swing is an older version without accounts. Update it first."}))
            if r.status_code != 200:
                msg = (r.json().get("error") if r.headers.get("content-type", "").startswith("application/json") else None)
                return self.send(403, json.dumps({"error": msg or "Wrong username or password."}))
            s["owner"] = make_owner(b["name"], b["password"])
            s.update(cloud_url=u + "/", setup_done=True, autostart=False, terms_accepted=time.strftime("%Y-%m-%d %H:%M"))
            if running("bot"):
                stop_bot(False)
            return self.send(200, json.dumps({"redirect": u + "/"}), extra={"Set-Cookie": new_session(s)})
        if self.path == "/api/logout":
            c = SimpleCookie(self.headers.get("Cookie", ""))
            if "sw" in c:
                s.get("sessions", {}).pop(c["sw"].value, None)
                save_settings(s)
            return self.send(200, "{}", extra={"Set-Cookie": "sw=; Path=/; Max-Age=0"})
        if self.path == "/api/account/password":
            if not self.authed():
                return self.send(401, json.dumps(self.login_state()))
            if not check_pw(s.get("owner"), s["owner"]["name"], b.get("old", "")):
                return self.send(403, json.dumps({"error": "Your current password isn't right."}))
            err = account_problem(s["owner"]["name"], b.get("new"))
            if err:
                return self.send(400, json.dumps({"error": err}))
            s["owner"] = make_owner(s["owner"]["name"], b["new"])
            s["sessions"] = {}                     # sign out everywhere else
            return self.send(200, "{}", extra={"Set-Cookie": new_session(s)})

    def send(self, code, body, ctype="application/json", extra=None):
        data = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            return {}

    def update_upload(self):
        """Install a new version from Swing.zip (from Claude), e.g. from your phone when Swing runs on a server.
        Only Swing's own program files are replaced. Your settings, keys, history and results are never touched."""
        if not self.admin():
            return self.send(403, json.dumps({"error": "Updating needs the computer, or phone access on a server install."}))
        n = int(self.headers.get("Content-Length") or 0)
        if not 0 < n <= 20 * 1024 * 1024:
            return self.send(400, json.dumps({"error": "That file is empty or too big for a Swing update."}))
        err, count = install_zip(self.rfile.read(n))
        if err:
            return self.send(400, json.dumps({"error": err}))
        return self.send(200, json.dumps({"updated": count}))

    def do_GET(self):
        self._safe(self._do_GET)

    def do_POST(self):
        self._safe(self._do_POST)

    def _safe(self, fn):
        """Never leave a button hanging: any unexpected error comes back as a message and goes in app_errors.log."""
        try:
            fn()
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            import traceback
            try:
                with open(path("app_errors.log"), "a") as f:
                    f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {self.command} {self.path}\n{traceback.format_exc()}\n")
            except OSError:
                pass
            try:
                self.send(500, json.dumps({"error": f"Swing hit an error ({type(e).__name__}: {e}). "
                                                    "In Settings, download the support file and send it to whoever helps you."}))
            except Exception:
                pass

    def _do_GET(self):
        if self.path in ("/", "/index.html"):
            cu = load_settings().get("cloud_url")
            if cu and self.local():            # this computer shows your cloud Swing: one Swing everywhere
                return self.send(302, "", "text/plain", extra={"Location": cu})
            return self.send(200, page(), "text/html; charset=utf-8")
        if self.path == "/?local=1" or self.path == "/local":
            return self.send(200, page(), "text/html; charset=utf-8")
        if self.path == "/Swing.zip" and self.authed():   # this Swing's program, to put on a cloud server
            return self.send(200, package_zip(), "application/zip",
                             extra={"Content-Disposition": 'attachment; filename="Swing.zip"'})
        if self.path == "/icon.png" and os.path.exists(path("icon.png")):
            return self.send(200, open(path("icon.png"), "rb").read(), "image/png")
        if self.path == "/manifest.webmanifest":
            return self.send(200, json.dumps({"name": "Swing", "short_name": "Swing", "start_url": "/", "display": "standalone",
                                              "background_color": "#F4F6FA", "theme_color": "#FFFFFF",
                                              "icons": [{"src": "/icon.png", "sizes": "512x512", "type": "image/png"}]}),
                             "application/manifest+json")
        if self.path == "/api/support.zip" and self.authed():
            return self.send(200, support_zip(), "application/zip",
                             extra={"Content-Disposition": 'attachment; filename="swing-support.zip"'})
        if self.path == "/api/trades.csv" and self.authed():
            return self.send(200, trades_csv(), "text/csv; charset=utf-8",
                             extra={"Content-Disposition": 'attachment; filename="swing-trades.csv"'})
        if self.path == "/api/state":
            if not self.authed():
                return self.send(401, json.dumps(self.login_state()))
            return self.send(200, json.dumps(state()))
        self.send(404, "{}")

    def _do_POST(self):
        if self.path == "/api/update":
            return self.update_upload()
        b = self.body()
        if self.path in ("/api/login", "/api/account/create", "/api/logout", "/api/account/password", "/api/account/link"):
            return self.account_api(b)
        if not self.authed():
            return self.send(401, json.dumps(self.login_state()))
        err = None
        if self.path == "/api/bot/start":
            err = start_bot()
        elif self.path == "/api/bot/stop":
            err = stop_bot(False)
        elif self.path == "/api/bot/flatten":
            err = stop_bot(True)
        elif self.path == "/api/picks/use":
            err = use_picks(b.get("id"))
        elif self.path == "/api/backtest/start":
            err = start_backtest(bool(b.get("full")))
        elif self.path == "/api/settings":
            b.pop("pin", None)
            s = load_settings()
            TRADING = ("venue", "real_orders", "topstep_accounts", "risk_override", "rules", "news", "accounts", "min_pass")
            before = json.dumps({k: s.get(k) for k in TRADING}, sort_keys=True)
            for k in ("username", "accounts", "remote_access", "news", "venue", "real_orders", "rules", "notify", "funded_cost", "risk_override", "min_pass", "auto_reopt", "monthly_goal", "setup_done", "auto_update"):
                if k in b:
                    s[k] = b[k]
            if "topstep_accounts" in b:             # only the choices; names/balances come from Topstep
                choice = {x["id"]: x for x in b["topstep_accounts"]}
                for acc in s["topstep_accounts"]:
                    c = choice.get(acc["id"], {})
                    for k in ("enabled", "type", "size", "risk"):
                        if k in c:
                            acc[k] = c[k]
            if sum(1 for x in s["topstep_accounts"] if x.get("enabled") and x.get("type") == "express") > 5:
                return self.send(400, json.dumps({"error": "Topstep allows at most 5 Express Funded accounts at once."}))
            s["mode"] = "paper" if s["venue"] == "paper" else ("live" if s["real_orders"] else "practice")
            ro = s.get("risk_override")
            if ro not in (None, ""):
                try:
                    ro = round(float(str(ro).replace("$", "").replace(",", "")))
                except ValueError:
                    return self.send(400, json.dumps({"error": "Enter risk per trade as a dollar amount, like 100."}))
                if not 10 <= ro <= 1000:
                    return self.send(400, json.dumps({"error": "Risk per trade has to be between $10 and $1,000."}))
                s["risk_override"] = ro
            else:
                s["risk_override"] = None
            try:
                s["min_pass"] = round(float(s.get("min_pass") or 75))
            except (TypeError, ValueError):
                return self.send(400, json.dumps({"error": "Enter the pass rate as a number, like 75."}))
            if not 50 <= s["min_pass"] <= 99:
                return self.send(400, json.dumps({"error": "Keep the pass rate floor between 50% and 99%."}))
            s["auto_reopt"] = bool(s.get("auto_reopt"))
            try:
                s["monthly_goal"] = round(float(str(s.get("monthly_goal") or 10000).replace("$", "").replace(",", "")))
            except ValueError:
                return self.send(400, json.dumps({"error": "Enter the monthly goal in dollars, like 10000."}))
            if not 500 <= s["monthly_goal"] <= 200000:
                return self.send(400, json.dumps({"error": "Keep the monthly goal between $500 and $200,000."}))
            if b.get("api_key"):
                s["api_key"] = b["api_key"]
            s["dry_run"] = s["mode"] == "practice"
            if s["remote_access"] and not s.get("owner"):
                return self.send(400, json.dumps({"error": "Create your Swing account first (username and password)."}))
            bind_before = load_settings()
            save_settings(s)
            if listening_remote(bind_before) != listening_remote(s):
                request_restart("phone access changed")       # listen on the network (or stop) right away
            changed = json.dumps({k: s.get(k) for k in TRADING}, sort_keys=True) != before
            if running("bot") and changed:          # apply trading changes right away
                stop_bot(False, remember=False)
                time.sleep(1)
                e2 = start_bot()
                err = "Saved and restarted the bot." if not e2 else f"Saved, but the bot couldn't restart: {e2}"
        elif self.path == "/api/topstep/connect":
            if not self.admin():
                return self.send(403, json.dumps({"error": "Connect your Topstep account from the computer."}))
            s = load_settings()
            s["username"] = (b.get("username") or s["username"]).strip()
            if b.get("api_key"):
                s["api_key"] = b["api_key"].strip()
            err = fetch_topstep_accounts(s)
            if not err:
                s = load_settings()
                s["venue"] = "topstep"
                s["mode"] = "live" if s["real_orders"] else "practice"
                save_settings(s)
        elif self.path == "/api/topstep/refresh":
            err = fetch_topstep_accounts(load_settings())
        elif self.path == "/api/topstep/disconnect":
            if running("bot"):
                err = "Stop the bot before disconnecting."
            else:
                s = load_settings()
                s.update({"api_key": "", "connected": False, "topstep_accounts": [], "venue": "paper",
                          "real_orders": False, "mode": "paper"})
                save_settings(s)
        elif self.path == "/api/payouts":
            s = load_settings()
            if b.get("remove") is not None:
                s["payouts"] = [p for i, p in enumerate(s["payouts"]) if i != int(b["remove"])]
            else:
                try:
                    amt = round(float(str(b.get("amount", "")).replace("$", "").replace(",", "")), 2)
                except ValueError:
                    return self.send(400, json.dumps({"error": "Enter the payout amount in dollars."}))
                if amt <= 0:
                    return self.send(400, json.dumps({"error": "Enter the payout amount in dollars."}))
                s["payouts"].append({"date": time.strftime("%Y-%m-%d"), "amount": amt})
            save_settings(s)
        elif self.path == "/api/update/check":
            msg = check_update(install=True)
            return self.send(200, json.dumps({"message": msg}))
        elif self.path == "/api/cloud/use":
            s = load_settings()
            u = (b.get("url") or "").strip().rstrip("/")
            if u:
                if not re.fullmatch(r"https?://[\w.\-]+(:\d+)?", u):
                    return self.send(400, json.dumps({"error": "Enter the address like http://100.72.165.2:8765"}))
                try:
                    import requests as rq
                    ok = rq.get(u + "/manifest.webmanifest", timeout=6).status_code == 200
                except Exception:
                    ok = False
                if not ok:
                    return self.send(400, json.dumps({"error": "Can't reach your cloud Swing at that address. Is Tailscale on and signed in on this computer?"}))
                if running("bot"):
                    stop_bot(False)                 # only the cloud trades
            s = load_settings()
            s["cloud_url"] = u + "/" if u else ""
            if u:
                s["autostart"] = False
            save_settings(s)
        elif self.path == "/api/notify/test":
            import notify as NT
            cfg = dict(load_settings()["notify"], enabled=True)
            if not NT.send(cfg, "Swing is connected", "Notifications are working. You'll get trade alerts and briefs here."):
                err = "Couldn't send. Check this computer's internet connection."
        elif self.path == "/api/paper/reset":
            if running("bot"):
                err = "Stop the bot before resetting the paper account."
            else:
                for f in ("paper_state.json", "bot_state.json"):
                    try:
                        os.remove(path(f))
                    except FileNotFoundError:
                        pass
        elif self.path == "/api/quit":
            self.send(200, "{}")
            if running("bot"):
                procs["bot"].terminate()
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        else:
            return self.send(404, "{}")
        ok = not err or err.startswith("Saved and")
        self.send(200 if ok else 400, json.dumps({"error": err} if err else {}))


def open_window(url):
    """Open Swing in its own app window (no tabs, no address bar, its own taskbar icon).
    Uses Microsoft Edge's app mode, which every Windows 10/11 PC has. Falls back to the browser."""
    if os.name == "nt":
        roots = [os.environ.get(k) for k in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")]
        for r in filter(None, roots):
            edge = os.path.join(r, "Microsoft", "Edge", "Application", "msedge.exe")
            if os.path.exists(edge):
                try:
                    subprocess.Popen([edge, f"--app={url}", "--window-size=1200,860",
                                      f"--user-data-dir={path('.window')}",   # its own profile: a separate app
                                      "--no-first-run", "--no-default-browser-check"],
                                     creationflags=subprocess.CREATE_NO_WINDOW)
                    return
                except OSError:
                    break
    elif sys.platform == "darwin":
        chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if os.path.exists(chrome):
            try:
                subprocess.Popen([chrome, f"--app={url}", f"--user-data-dir={path('.window')}"])
                return
            except OSError:
                pass
    webbrowser.open(url)

RESTART = {"why": None, "server": None}
RESTART_CODE = 3        # "Start Swing.bat" and the Pi service start Swing again when it exits with this

def request_restart(why):
    """Restart the app (the bot keeps its stops and targets at Topstep and resumes on its own)."""
    if RESTART["why"] or not RESTART["server"]:
        return
    RESTART["why"] = why
    threading.Timer(1.5, RESTART["server"].shutdown).start()

CODE_APP = ("app.py", "news.py", "notify.py", "paper.py")
CODE_BOT = ("topstep_bot.py", "strategies.py", "news.py", "notify.py", "paper.py")

def _code_watch():
    """When Claude updates Swing's files, use the new version right away: the bot restarts with new bot code,
    the app restarts itself with new app code. Waits while a backtest runs."""
    def stamp(files):
        return tuple(os.path.getmtime(path(f)) if os.path.exists(path(f)) else 0 for f in files)
    app0, bot0 = stamp(CODE_APP), stamp(CODE_BOT)
    while True:
        time.sleep(10)
        if running("backtest"):
            continue
        a, bt = stamp(CODE_APP), stamp(CODE_BOT)
        if a != app0:
            time.sleep(5)                       # let all the files finish copying
            print("Swing was updated: restarting with the new version.")
            request_restart("update")
            return
        if bt != bot0:
            time.sleep(5)
            bot0 = stamp(CODE_BOT)
            if running("bot"):
                stop_bot(False, remember=False)
                time.sleep(1)
                err = start_bot()
                print("Bot updated: restarted with the new version." if not err else f"Bot update: couldn't restart ({err})")

def fix_shortcuts():
    """Windows: make the Swing icons open Swing as its own app (not the old console/browser launcher)."""
    if os.name != "nt":
        return
    exe = os.environ.get("SWING_EXE")          # started from Swing.exe: the icons open Swing.exe
    if exe:
        target, args = exe, ""
    elif os.path.exists(path("Swing.vbs")):
        target, args = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "System32", "wscript.exe"), f'"{path("Swing.vbs")}"'
    else:
        return
    ps = ("$w=New-Object -ComObject WScript.Shell; "
          "foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){"
          "$p=$d+'\\Swing.lnk'; if(Test-Path $p){ if($w.CreateShortcut($p).TargetPath -match 'msedge'){ continue } }; "
          f"$s=$w.CreateShortcut($p); $s.TargetPath='{target}'; "
          f"$s.Arguments='{args}'; $s.WorkingDirectory='{APP_DIR}'; "
          f"$s.IconLocation='{path('icon.ico')}'; $s.Description='Swing'; $s.Save() }}")
    try:
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps], timeout=20,
                       capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
    except (OSError, subprocess.SubprocessError):
        pass

def main():
    threading.Thread(target=fix_shortcuts, daemon=True).start()
    restore_monday_picks()
    apply_research_picks()
    enable_backtest_v3()
    fresh_start_v4()
    sweep_windows_v5()
    sweep_partials_v6()
    sweep_rules_v7()
    threading.Thread(target=_long_history_loop, daemon=True).start()
    s = load_settings()
    save_settings(s)
    host = "0.0.0.0" if listening_remote(s) else "127.0.0.1"
    url = f"http://127.0.0.1:{PORT}"
    server = None
    for attempt in range(40 if os.environ.get("SWING_RESTARTED") else 1):   # after an update the port can take a moment
        try:
            server = Server((host, PORT), Handler)
            break
        except OSError:
            time.sleep(3)
    if server is None:
        open_window(url)                # already running: just show it
        return
    threading.Thread(target=news_loop, daemon=True).start()
    def _watchdog():
        """If the bot should be running but stopped (internet drop, crash), bring it back, backing off up to 10 min."""
        wait = 60
        while True:
            time.sleep(wait)
            if load_settings().get("autostart") and not running("bot") and not running("backtest"):
                err = start_bot()
                print("Watchdog restarted the bot." if not err else f"Watchdog couldn't restart the bot: {err}")
                wait = min(wait * 2, 600)
            else:
                wait = 60
    threading.Thread(target=_watchdog, daemon=True).start()
    def _after_backtest():
        """When a backtest finishes while the bot runs, restart the bot so it trades the new results."""
        seen = None
        while True:
            time.sleep(5)
            p = procs["backtest"]
            if p is None or p is seen or p.poll() is None:
                continue
            seen = p
            if p.returncode == 0 and running("bot"):
                stop_bot(False, remember=False)
                time.sleep(1)
                err = start_bot()
                print("Backtest finished: restarted the bot with the new results." if not err
                      else f"Backtest finished, but the bot couldn't restart: {err}")
    threading.Thread(target=_after_backtest, daemon=True).start()
    def _reoptimize():
        """Keep the setups fresh without you doing anything: re-run the backtest every weekend, and on a weekday
        evening (market closed, 4-5:30 PM ET) when a setup got benched for losing live. The bot then restarts
        with the new picks, so benched setups get replaced by whatever tests best now."""
        from zoneinfo import ZoneInfo
        from datetime import datetime
        et = ZoneInfo("America/New_York")
        while True:
            time.sleep(300)
            try:
                s = load_settings()
                if not s.get("auto_reopt") or running("backtest"):
                    continue
                cfg = read_json("best_config.json", {}) or {}
                age = time.time() - (cfg.get("generated_ts") or os.path.getmtime(path("best_config.json"))
                                     if os.path.exists(path("best_config.json")) else 0)
                now = datetime.now(et)
                weekend = now.weekday() == 5 or (now.weekday() == 6 and now.hour < 16)
                evening = now.weekday() < 5 and (16, 0) <= (now.hour, now.minute) < (17, 30)
                benched = (read_json("status.json", {}) or {}).get("benched") or {}
                why = None
                if weekend and age > 5 * 86400:
                    why = "weekly refresh"
                elif evening and benched and age > 2 * 86400:
                    why = f"{len(benched)} setup(s) benched for losing live"
                if why:
                    err = start_backtest()
                    s["last_reopt"] = f"{now:%b %d %I:%M %p} ET ({why})"
                    save_settings(s)
                    print(f"Auto re-optimize: {why}" + (f" ({err})" if err else ""))
            except Exception as e:
                print(f"Auto re-optimize skipped: {e}")
    threading.Thread(target=_reoptimize, daemon=True).start()
    def _open():
        try:
            open_window(url)
        except Exception:
            pass
    if not s.get("allow_remote_admin") and not os.environ.get("SWING_RESTARTED"):   # no new tab after an update
        threading.Timer(0.8, _open).start()
    if s.get("autostart"):                       # it was running before a restart or power cut: resume
        def _resume():
            err = start_bot()
            print("Resumed the bot." if not err else f"Couldn't resume the bot: {err}")
        threading.Timer(5, _resume).start()
    print(f"Swing is open at {url}  (close this window or use Quit in the app to exit)")
    RESTART["server"] = server
    threading.Thread(target=_code_watch, daemon=True).start()
    threading.Thread(target=_auto_update, daemon=True).start()
    try:
        server.serve_forever()
    finally:
        if running("bot"):
            procs["bot"].terminate()
        server.server_close()
    if RESTART["why"]:
        sys.exit(RESTART_CODE)


if __name__ == "__main__":
    main()
