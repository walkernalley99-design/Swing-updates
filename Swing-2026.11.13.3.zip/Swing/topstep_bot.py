"""
Swing: the trading engine (TopstepX / ProjectX Gateway API)

Everything the "Capital Rush" pitch claims, but you own it:
  - Fully autonomous: finds signals, sizes, enters, sets stop + target, exits
  - Trades 3 markets at once: MNQ (Nasdaq), MES (S&P 500), MGC (Gold)
  - Runs on multiple Topstep accounts at once (Combines + up to 5 Express Funded)
  - Risk settings you can change: conservative / moderate / aggressive

Plus what actually keeps an account alive:
  - Trailing Max Loss Limit guard (shrinks size, then stops, before a breach)
  - Daily loss limit + daily profit cap (protects the consistency rule)
  - Stops trading a Combine once its profit target is reached
  - Cross-account hedge blocker (Topstep bans opposite positions across accounts)
  - Correlation cap (max open positions per account; MNQ and MES move together)
  - News blackout windows, auto-flatten before the close
  - Runners: optional half-off at 1R, then stop to break-even (from your trading notes)
  - Kill switch: create a file named STOP next to this script to flatten and quit
  - P&L calendar dashboard (pnl_calendar.html) updated every evening

Strategies and settings come from best_config.json, written by backtest.py.
Run the backtester first; the bot only trades markets whose strategy held up on
data it was never tuned on, at the risk level with the highest Combine pass rate.

START WITH DRY_RUN = True, then a Practice account for weeks.
No strategy is guaranteed to profit. This is a tool, not a money machine.
"""
import os, json, time, calendar, logging
from datetime import datetime, timedelta, timezone, date
from zoneinfo import ZoneInfo
import requests
import strategies as S
import news as N
import notify as NT

# ============================ CONFIG ============================
API = "https://api.topstepx.com/api"
USERNAME = os.environ.get("PX_USERNAME", "")
API_KEY = os.environ.get("PX_API_KEY", "")
CONFIG_FILE = "best_config.json"   # written by backtest.py
RETIRED = {"london", "london_sweep", "asia_fade", "eu_orb", "eu_drift"}   # overnight models retired after losing live
PAPER = False                      # True = no Topstep account: free delayed data + simulated fills (paper.py)
NEWS = N.settings()                # news + volatility protections (changed in the app's Settings)
RULES = {"giveback": True, "loss_streak_all": False}
NOTIFY = NT.settings()                                 # phone notifications (app Settings)
HOST = "pc"               # "cloud" when installed with install_cloud.sh
MIN_PASS_SETTING = None    # Settings: lowest Combine pass rate Swing accepts (None = from the backtest)
RISK_OVERRIDE = None                                   # your own $ per trade from Settings (None = from backtest)   # protect profits / 2-losses-in-a-row stop (app Settings)
DRY_RUN = True                     # True = log only, never place orders

# Risk settings. "risk" = max $ lost per trade if the stop hits.
RISK_PRESETS = {
    "conservative": {"risk": 50,  "daily_loss": 200, "daily_cap": 400,  "max_trades": 3},
    "moderate":     {"risk": 100, "daily_loss": 350, "daily_cap": 700,  "max_trades": 5},
    "aggressive":   {"risk": 200, "daily_loss": 600, "daily_cap": 1200, "max_trades": 6},
}
# "auto" = moderate daily limits + the per-trade risk the backtester found had the
# highest Combine pass rate. Filled in at startup from best_config.json.

# One entry per account type. "match" = text in the TopstepX account name
# ("" matches every tradable account). First matching entry wins.
ACCOUNTS = [
    {"match": "", "type": "combine", "start_balance": 50_000, "mll": 2_000,
     "profit_target": 3_000, "consistency": 0.50, "max_micros": 50, "risk": "auto"},
    # {"match": "XFA", "type": "express", "start_balance": 50_000, "mll": 2_000,
    #  "profit_target": 0, "consistency": 0, "max_micros": 50, "risk": "conservative"},
]

# Used only in DRY_RUN if best_config.json doesn't exist yet
DEFAULT_STRATEGY = {"strategy": "trend", "params": {"fast": 9, "slow": 21, "stop_atr": 1.5, "rr": 2.0,
                                                    "window": [[9, 45], [15, 30]]}}
DEFAULT_MARKETS = ("MNQ", "MES", "MGC", "MCL")

BAR_MINUTES = 5
MAX_CONTRACTS_PER_TRADE = 5        # must match MAX_CONTRACTS in backtest.py
MAX_OPEN_POSITIONS = 2             # per account, across all markets
NEWS_TIMES = [(8, 30), (10, 0), (14, 0)]   # old fixed times; the live calendar in news.py replaces these
NEWS_BLACKOUT_MIN = 5
FLATTEN = (15, 50)                 # matches strategies.HARD_EXIT
LOOP_SECONDS = 15
STATE_FILE = "bot_state.json"
CALENDAR_FILE = "pnl_calendar.html"
ET = ZoneInfo("America/New_York")
# ================================================================

# Settings saved by the app (app.py) override the defaults above.
try:
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.json")) as _f:
        _s = json.load(_f)
    USERNAME = os.environ.get("PX_USERNAME") or _s.get("username") or USERNAME
    API_KEY = os.environ.get("PX_API_KEY") or _s.get("api_key") or API_KEY
    NEWS = N.settings(_s.get("news"))
    NOTIFY = NT.settings(_s.get("notify"))
    if _s.get("risk_override"):
        RISK_OVERRIDE = float(_s["risk_override"])
    HOST = _s.get("host", "pc")
    if _s.get("min_pass") is not None:
        MIN_PASS_SETTING = float(_s["min_pass"])
    RULES.update({k: bool(v) for k, v in (_s.get("rules") or {}).items() if k in RULES})
    if _s.get("venue"):
        _mode = "paper" if _s["venue"] == "paper" else ("live" if _s.get("real_orders") else "practice")
    else:
        _mode = _s.get("mode") or ("practice" if _s.get("dry_run", True) else "live")
    PAPER = _mode == "paper"
    DRY_RUN = _mode == "practice"
    _picked = [x for x in _s.get("topstep_accounts", []) if x.get("enabled")]
    if _picked:                    # accounts switched on in the app (matched by id)
        _sizes = {"50K": (50_000, 2_000, 3_000, 50), "100K": (100_000, 3_000, 6_000, 100),
                  "150K": (150_000, 4_500, 9_000, 150)}
        ACCOUNTS = []
        for _a in _picked:
            _st, _mll, _tg, _mic = _sizes.get(_a.get("size", "50K"), _sizes["50K"])
            _comb = _a.get("type") == "combine"
            ACCOUNTS.append({"id": _a["id"], "match": _a["name"], "type": _a.get("type", "combine"),
                             "start_balance": _st, "mll": _mll, "profit_target": _tg if _comb else 0,
                             "consistency": 0.5 if _comb else 0, "max_micros": _mic, "risk": _a.get("risk", "auto")})
    elif _s.get("accounts"):
        _sizes = {"50K": (50_000, 2_000, 3_000, 50), "100K": (100_000, 3_000, 6_000, 100),
                  "150K": (150_000, 4_500, 9_000, 150)}
        ACCOUNTS = []
        for _a in _s["accounts"]:
            _st, _mll, _tg, _mic = _sizes.get(_a.get("size", "50K"), _sizes["50K"])
            _comb = _a.get("type") == "combine"
            ACCOUNTS.append({"match": _a.get("match", ""), "type": _a.get("type", "combine"),
                             "start_balance": _st, "mll": _mll, "profit_target": _tg if _comb else 0,
                             "consistency": 0.5 if _comb else 0, "max_micros": _mic,
                             "risk": _a.get("risk", "auto")})
except (FileNotFoundError, json.JSONDecodeError):
    pass
if PAPER:   # one virtual 50K Combine; orders are simulated, so they're "placed" for real in the sim
    DRY_RUN = False
    ACCOUNTS = [{"match": "PAPER", "type": "combine", "start_balance": 50_000, "mll": 2_000, "profit_target": 3_000,
                 "consistency": 0.5, "max_micros": 50, "risk": "auto"}]

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s",
                    handlers=[logging.StreamHandler(), logging.FileHandler("bot.log")])
log = logging.getLogger()


class PX:
    def __init__(self):
        self.s = requests.Session()
        self.login()

    def login(self):
        try:
            r = self.s.post(f"{API}/Auth/loginKey",
                            json={"userName": USERNAME, "apiKey": API_KEY}, timeout=15).json()
        except (requests.RequestException, ValueError):
            raise SystemExit("Couldn't reach TopstepX. Check your internet connection.")
        if not r.get("success"):
            raise SystemExit("TopstepX rejected the login. Check your username and API key in Settings.")
        self.s.headers["Authorization"] = f"Bearer {r['token']}"
        self.login_time = time.time()

    def post(self, path, body):
        if time.time() - self.login_time > 20 * 3600:
            self.login()
        r = self.s.post(f"{API}/{path}", json=body, timeout=15)
        r.raise_for_status()
        data = r.json()
        if data.get("success") is False:
            raise RuntimeError(f"{path} failed: {data}")
        return data


class Account:
    def __init__(self, info, cfg):
        self.id, self.name, self.cfg = info["id"], info["name"], cfg
        self.capped = None
        key = cfg["risk"]
        if key in ("auto", "custom") and RISK_OVERRIDE:
            cfg["risk"] = key = "custom"      # your fixed $ amount: no automatic scaling by account size
            kind = "express" if cfg.get("type") == "express" else "combine"
            cap = risk_cap(kind, RISK_OVERRIDE)
            if cap and cap < RISK_OVERRIDE:   # your amount fails the safety floor: use the biggest size that passes
                key = "custom_" + kind
                RISK_PRESETS[key] = {"risk": cap, "daily_loss": 3 * cap, "daily_cap": 7 * cap, "max_trades": 6}
                self.capped = {"asked": RISK_OVERRIDE, "used": cap}
                log.warning(f"[{self.name}] ${RISK_OVERRIDE:.0f}/trade is too big for this {kind} account "
                            f"({CAPS['why'][kind]}). Using ${cap:.0f}/trade.")
        elif key == "auto" and cfg.get("type") == "express":
            key = "auto_express"
        self.p = RISK_PRESETS[key]
        self.trades_today, self.halted, self.risk = 0, None, 0
        self.trips = []
        self.peak = 0.0


def round_tick(price, tick):
    return round(round(price / tick) * tick, 4)

def in_blackout(now):
    for h, m in NEWS_TIMES:
        t = now.replace(hour=h, minute=m, second=0, microsecond=0)
        if abs((now - t).total_seconds()) <= NEWS_BLACKOUT_MIN * 60:
            return True
    return False


# ---------------- API helpers ----------------
def find_contract(px, sym):
    cs = px.post("Contract/search", {"searchText": sym, "live": False}).get("contracts", [])
    cs = [c for c in cs if f".{sym}." in c["id"]] or cs
    if not cs:
        log.error(f"No contract found for {sym}")
        return None
    c = next((x for x in cs if x.get("activeContract")), cs[0])
    c["point_value"] = c["tickValue"] / c["tickSize"]
    return c

def get_bars(px, cid):
    end = datetime.now(timezone.utc)
    d = px.post("History/retrieveBars", {
        "contractId": cid, "live": False,
        "startTime": (end - timedelta(days=5)).isoformat(), "endTime": end.isoformat(),
        "unit": 2, "unitNumber": BAR_MINUTES, "limit": 1500, "includePartialBar": False})
    return S.parse_bars(d.get("bars", []))

def get_positions(px, acct_id):
    return px.post("Position/searchOpen", {"accountId": acct_id}).get("positions", [])

def session_start():
    """Topstep trading day starts 6pm ET the previous evening."""
    now = datetime.now(ET)
    start = now.replace(hour=18, minute=0, second=0, microsecond=0)
    return start if now >= start else start - timedelta(days=1)

def day_trades(px, acct_id):
    return px.post("Trade/search", {
        "accountId": acct_id,
        "startTimestamp": session_start().astimezone(timezone.utc).isoformat()}).get("trades", [])

def day_pnl(px, acct_id):
    return sum((t.get("profitAndLoss") or 0) - (t.get("fees") or 0) for t in day_trades(px, acct_id))

# ---------------- trade journal (for the day breakdown in the app) ----------------
JOURNAL = "journal.json"

def journal_add(acct_id, cid, strategy, side, entry=None, stop=None, targets=None):
    try:
        with open(JOURNAL) as f:
            j = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        j = []
    j.append({"ts": time.time(), "acct": acct_id, "cid": cid, "strategy": strategy, "side": side,
              "entry": entry, "stop": stop, "targets": targets or []})
    try:
        with open(JOURNAL + ".tmp", "w") as f:
            json.dump(j[-1000:], f)
        os.replace(JOURNAL + ".tmp", JOURNAL)
    except OSError:
        pass

def session_of(dt):
    h = dt.hour + dt.minute / 60
    if h >= 18 or h < 2:
        return "Asia"
    return "London" if h < 8 else "New York"

def _ts(s):
    return datetime.fromisoformat(str(s).replace("Z", "+00:00"))

def round_trips(trades, acct):
    """Turn raw fills into finished trades: entry time, market, side, size, strategy, session, net P&L."""
    try:
        with open(JOURNAL) as f:
            journal = [e for e in json.load(f) if e["acct"] == acct.id]
    except (FileNotFoundError, json.JSONDecodeError):
        journal = []
    book, trips = {}, []
    for t in sorted((t for t in trades if not t.get("voided")), key=lambda t: str(t.get("creationTimestamp"))):
        cid = t["contractId"]
        s = book.setdefault(cid, {"qty": 0})
        q = t["size"] if t["side"] == 0 else -t["size"]
        if s["qty"] == 0:
            s.update(start=_ts(t["creationTimestamp"]), side="Long" if q > 0 else "Short", pnl=0.0, fees=0.0, size=0)
        px_ = t.get("price")
        if (q > 0) == (s["side"] == "Long"):
            s["size"] += abs(q)
            if px_ is not None:
                s["e_val"] = s.get("e_val", 0.0) + px_ * abs(q)
                s["e_q"] = s.get("e_q", 0) + abs(q)
        elif px_ is not None:
            s["x_val"] = s.get("x_val", 0.0) + px_ * abs(q)
            s["x_q"] = s.get("x_q", 0) + abs(q)
        s["end"] = _ts(t["creationTimestamp"])
        s["qty"] += q
        s["pnl"] += t.get("profitAndLoss") or 0
        s["fees"] += t.get("fees") or 0
        if s["qty"] == 0:
            start = s["start"].astimezone(ET)
            # the journal entry closest to this fill (paper fills are stamped with the delayed candle time)
            near = sorted((e for e in journal if e["cid"] == cid and abs(e["ts"] - s["start"].timestamp()) < 1800),
                          key=lambda e: abs(e["ts"] - s["start"].timestamp()))
            if not near:   # fall back to the latest entry Swing logged for this market before the exit
                near = sorted((e for e in journal if e["cid"] == cid and e["ts"] <= s["end"].timestamp() + 1800),
                              key=lambda e: -e["ts"])[:1]
            j = near[0] if near else {}
            net = s["pnl"] - s["fees"]
            trips.append({"time": start.isoformat(), "exit_time": s["end"].astimezone(ET).isoformat(),
                          "market": cid.split(".")[3] if cid.count(".") >= 4 else cid,
                          "side": s["side"], "size": s["size"], "session": session_of(start),
                          "strategy": j.get("strategy", "manual"), "net": round(net, 2),
                          "entry": round(s["e_val"] / s["e_q"], 4) if s.get("e_q") else j.get("entry"),
                          "exit": round(s["x_val"] / s["x_q"], 4) if s.get("x_q") else None,
                          "stop": j.get("stop"), "targets": j.get("targets") or [],
                          "outcome": "Break-even" if abs(net) < 5 else ("Win" if net > 0 else "Loss"),
                          "account": acct.name})
            s.update(e_val=0.0, e_q=0, x_val=0.0, x_q=0)
    return trips

def flatten_contract(px, acct_id, cid):
    for o in px.post("Order/searchOpen", {"accountId": acct_id}).get("orders", []):
        if o["contractId"] == cid:
            px.post("Order/cancel", {"accountId": acct_id, "orderId": o["id"]})
    if any(p["contractId"] == cid for p in get_positions(px, acct_id)):
        px.post("Position/closeContract", {"accountId": acct_id, "contractId": cid})

def flatten_account(px, acct_id):
    for p in get_positions(px, acct_id):
        flatten_contract(px, acct_id, p["contractId"])

MANAGED = {}   # (account id, contract id) -> runner info for break-even management
OPENED = {}    # (account id, contract id) -> params of the setup that opened it (for time exits)
FIRST_SEEN = {}  # (account id, contract id) -> when Swing first saw the position without a stop
LIVE_STATE = "live_state.json"
CHART = {}     # market -> recent 5-minute candles for the app's live trades chart
ORDERS = {}    # account id -> its open orders (stops and targets), refreshed every loop
CHART_BARS = 96   # 8 hours of 5-minute candles

def chart_update(sym, bars):
    if bars:
        CHART[sym] = [[b["dt"].isoformat(), round(b["o"], 4), round(b["h"], 4), round(b["l"], 4), round(b["c"], 4)]
                      for b in bars[-CHART_BARS:]]

def save_live():
    """Remember open-trade management across restarts (runner/break-even, time exits)."""
    data = {"managed": [[a, c, m] for (a, c), m in MANAGED.items()],
            "opened": [[a, c, p] for (a, c), p in OPENED.items()]}
    try:
        with open(LIVE_STATE + ".tmp", "w") as f:
            json.dump(data, f)
        os.replace(LIVE_STATE + ".tmp", LIVE_STATE)
    except OSError:
        pass

def load_live():
    try:
        with open(LIVE_STATE) as f:
            d = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return
    for a, c, m in d.get("managed", []):
        MANAGED[(a, c)] = m
    for a, c, p in d.get("opened", []):
        OPENED[(a, c)] = p

def protect(px, acct, positions):
    """Every loop, for each account:
    - cancel leftover stop/target orders once their position is closed
    - shrink exit orders that are bigger than the position (otherwise a fill could flip the account
      into a new opposite position, e.g. after a restart mid-trade)
    - close any position that has no stop for 20+ seconds: never sit in a trade unprotected."""
    orders = px.post("Order/searchOpen", {"accountId": acct.id}).get("orders", [])
    ORDERS[acct.id] = orders
    held = {p["contractId"]: p for p in positions}
    changed = False
    for o in orders:
        if o["contractId"] not in held:
            px.post("Order/cancel", {"accountId": acct.id, "orderId": o["id"]})
    for cid, p in held.items():
        exit_side = 1 if p["type"] == 1 else 0
        mine = [o for o in orders if o["contractId"] == cid and o.get("side") == exit_side]
        for kind in (4, 1):                      # 4 = stop, 1 = limit (target)
            room = p["size"]
            for o in sorted((o for o in mine if o.get("type") == kind), key=lambda o: -(o.get("size") or 0)):
                sz = o.get("size") or 0
                if sz <= room:
                    room -= sz
                    continue
                if room > 0:
                    px.post("Order/modify", {"accountId": acct.id, "orderId": o["id"], "size": room})
                    log.info(f"[{acct.name}] {names_of(p)} exit order resized {sz} -> {room} to match the position")
                    room = 0
                else:
                    px.post("Order/cancel", {"accountId": acct.id, "orderId": o["id"]})
                    log.info(f"[{acct.name}] {names_of(p)} extra exit order cancelled (bigger than the position)")
        key = (acct.id, cid)
        if any(o.get("type") == 4 for o in mine):
            FIRST_SEEN.pop(key, None)
            continue
        FIRST_SEEN.setdefault(key, time.time())
        if time.time() - FIRST_SEEN[key] >= 20:
            log.warning(f"[{acct.name}] {names_of(p)} position had no stop: closing it for safety")
            NT.send(NOTIFY, f"Swing: closed an unprotected {names_of(p)} trade",
                    f"{acct.name} had a position with no stop order, so Swing closed it.", tags="warning", priority=4)
            flatten_contract(px, acct.id, cid)
            FIRST_SEEN.pop(key, None)
    for key in [k for k in list(MANAGED) + list(OPENED) if k[0] == acct.id and k[1] not in held]:
        MANAGED.pop(key, None)
        OPENED.pop(key, None)
        changed = True
    if changed:
        save_live()

def enter(px, acct, c, side, size, stop_pts, tgt_pts, partial=False, strategy=""):
    buy, cid, tick = side == "long", c["id"], c["tickSize"]
    px.post("Order/place", {"accountId": acct.id, "contractId": cid,
                            "type": 2, "side": 0 if buy else 1, "size": size})
    time.sleep(2)
    pos = next((p for p in get_positions(px, acct.id) if p["contractId"] == cid), None)
    if not pos:
        log.error(f"[{acct.name}] entry not filled on {cid}")
        return False
    fill, size = pos["averagePrice"], pos["size"]
    stop = round_tick(fill - stop_pts if buy else fill + stop_pts, tick)
    target = round_tick(fill + tgt_pts if buy else fill - tgt_pts, tick)
    exit_side = 1 if buy else 0
    half = size // 2 if partial and size >= 2 else 0
    try:
        r = px.post("Order/place", {"accountId": acct.id, "contractId": cid, "type": 4,
                                    "side": exit_side, "size": size, "stopPrice": stop})
        if half:
            t1 = round_tick(fill + stop_pts if buy else fill - stop_pts, tick)
            px.post("Order/place", {"accountId": acct.id, "contractId": cid, "type": 1,
                                    "side": exit_side, "size": half, "limitPrice": t1})
            px.post("Order/place", {"accountId": acct.id, "contractId": cid, "type": 1,
                                    "side": exit_side, "size": size - half, "limitPrice": target})
            MANAGED[(acct.id, cid)] = {"stop_id": r.get("orderId"), "entry": fill, "size": size,
                                       "exit_side": exit_side, "tick": tick, "be": False}
        else:
            px.post("Order/place", {"accountId": acct.id, "contractId": cid, "type": 1,
                                    "side": exit_side, "size": size, "limitPrice": target})
    except Exception:
        log.exception(f"[{acct.name}] stop/target failed, flattening for safety")
        flatten_contract(px, acct.id, cid)
        return False
    save_live()
    tlist = ([t1] if half else []) + [target]
    journal_add(acct.id, cid, strategy, side, fill, stop, tlist)
    if NOTIFY["trades"]:
        sym = cid.split(".")[3] if cid.count(".") >= 4 else cid
        NT.send(NOTIFY, f"Swing: {side} {size} {sym}",
                f"Entered at {fill} on {acct.name}. Stop {stop}, target {target}.", tags="arrow_right")
    log.info(f"[{acct.name}] ENTERED {side} {size}x {cid} @ {fill} stop {stop} target {target}"
             + (f" (half off at 1R, then break-even)" if half else ""))
    return True

def manage_runners(px, acct, positions):
    """After the first target fills: shrink the stop to the runner size and move it to break-even."""
    for (aid, cid), m in list(MANAGED.items()):
        if aid != acct.id:
            continue
        pos = next((p for p in positions if p["contractId"] == cid), None)
        if not pos:
            del MANAGED[(aid, cid)]
            continue
        if m["be"] or pos["size"] >= m["size"]:
            continue
        be = round_tick(m["entry"], m["tick"])
        try:
            px.post("Order/modify", {"accountId": aid, "orderId": m["stop_id"],
                                     "size": pos["size"], "stopPrice": be})
        except Exception:
            try:   # fallback: replace the stop
                px.post("Order/cancel", {"accountId": aid, "orderId": m["stop_id"]})
                r = px.post("Order/place", {"accountId": aid, "contractId": cid, "type": 4,
                                            "side": m["exit_side"], "size": pos["size"], "stopPrice": be})
                m["stop_id"] = r.get("orderId")
            except Exception:
                log.exception(f"[{acct.name}] could not move stop to break-even, flattening {cid}")
                flatten_contract(px, aid, cid)
                del MANAGED[(aid, cid)]
                continue
        m["be"] = True
        save_live()
        log.info(f"[{acct.name}] first target hit on {cid}: runner stop moved to break-even {be}")


# ---------------- risk guard ----------------
def guard(acct, info, pnl, st):
    """Returns (halt_reason or None, $ risk allowed for the next trade)."""
    cfg, p = acct.cfg, acct.p
    s = st.setdefault(str(acct.id), {"peak_eod": cfg["start_balance"], "days": {}})
    bal = info["balance"]
    if s.get("start") is not None and s["start"] != cfg["start_balance"]:   # balance basis changed: start over
        s.update(peak_eod=max(cfg["start_balance"], bal), start=cfg["start_balance"], eod_bal=bal)
    # A payout on a funded account locks the max loss at the start balance for good (Topstep rule).
    # Spot it when the balance drops by more than today's trading explains. (A false alarm only makes Swing safer.)
    same = s.get("eod_session") == session_start().isoformat()     # end-of-day already counted today's P&L
    if cfg["type"] == "express" and not s.get("paid_out") and s.get("eod_bal") is not None \
            and bal < s["eod_bal"] + pnl - (s.get("eod_pnl", 0) if same else 0) - (3 * p["risk"] + 50):
        s["paid_out"] = True
        log.info(f"[{acct.name}] payout detected: max loss now locked at the start balance")
    floor = cfg["start_balance"] if s.get("paid_out") else \
        min(s["peak_eod"] - cfg["mll"], cfg["start_balance"])     # trailing MLL, locks at start
    room = bal - floor
    acct.room = room                                  # shown in the app, so a shrinking trade size is explained
    cap = p["daily_cap"]
    if cfg.get("profit_target") and cfg.get("consistency"):
        cap = min(cap, cfg["consistency"] * cfg["profit_target"] * 0.9)
    if cfg["type"] == "combine" and cfg.get("profit_target") and bal >= cfg["start_balance"] + cfg["profit_target"]:
        return "profit target reached - check your Topstep dashboard", 0
    if pnl <= -p["daily_loss"] * (cfg["mll"] / 2000 if cfg["risk"] == "auto" else 1):
        return f"daily loss limit hit (${pnl:.0f})", 0
    if pnl >= cap:
        return f"daily profit cap hit (${pnl:.0f}), protecting consistency", 0
    if room < 2 * p["risk"]:
        return f"only ${room:.0f} above Max Loss Limit", 0
    risk = p["risk"]
    if cfg["risk"] == "auto":
        risk *= cfg["mll"] / 2000             # tested on a 50K ($2,000 max loss); bigger accounts scale up with it
    if cfg["type"] == "express" and room < 1.25 * cfg["mll"]:
        risk *= 0.5                           # cushion mode: half size until the account has room to breathe
    daily_loss = p["daily_loss"] * (cfg["mll"] / 2000 if cfg["risk"] == "auto" else 1)
    return None, min(risk, room / 4, daily_loss + pnl)


# ---------------- state & dashboard ----------------
def load_state():
    try:
        with open(STATE_FILE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_state(st):
    with open(STATE_FILE, "w") as f:
        json.dump(st, f, indent=2)

def record_eod(px, accounts, infos, st, today):
    for a in accounts:
        if a.id not in infos:
            continue
        s = st.setdefault(str(a.id), {"peak_eod": a.cfg["start_balance"], "days": {}})
        s["name"], s["type"], s["start"] = a.name, a.cfg["type"], a.cfg["start_balance"]
        s["paper"] = PAPER
        bal = infos[a.id]["balance"]
        pnl_now = sum((t.get("profitAndLoss") or 0) - (t.get("fees") or 0) for t in day_trades(px, a.id))
        if a.cfg["type"] == "express" and s.get("eod_bal") is not None and bal < s["eod_bal"] + pnl_now - 50:
            s["paid_out"] = True              # payout taken: max loss is locked at the start balance from now on
        s["eod_bal"], s["eod_pnl"], s["eod_session"] = bal, pnl_now, session_start().isoformat()
        s["peak_eod"] = max(s["peak_eod"], bal)
        trades = day_trades(px, a.id)
        closed = [t for t in trades if t.get("profitAndLoss") is not None]
        pnl = sum((t.get("profitAndLoss") or 0) - (t.get("fees") or 0) for t in trades)
        trips = round_trips(trades, a)
        s["days"][today] = {"pnl": round(pnl, 2), "trades": len(trips) or len(closed), "trips": trips,
                            "wins": sum(1 for t in trips if t["outcome"] == "Win"),
                            "losses": sum(1 for t in trips if t["outcome"] == "Loss")}
        floor = a.cfg["start_balance"] if s.get("paid_out") else min(s["peak_eod"] - a.cfg["mll"], a.cfg["start_balance"])
        log.info(f"[{a.name}] EOD P&L ${pnl:.2f} | balance ${bal:,.2f} | MLL floor ${floor:,.2f}")
    st["last_eod"] = today
    save_state(st)
    write_calendar(st, date.fromisoformat(today))
    try:
        evening_recap(datetime.now(ET), accounts, infos, st, today)
    except Exception:
        log.exception("recap failed")

def write_calendar(st, today):
    y, m = today.year, today.month
    agg = {}
    for v in st.values():
        if isinstance(v, dict) and "days" in v:
            for d, r in v["days"].items():
                a = agg.setdefault(d, {"pnl": 0, "trades": 0, "wins": 0, "losses": 0})
                for k in a:
                    a[k] += r.get(k, 0)
    month = {d: r for d, r in agg.items() if d.startswith(f"{y}-{m:02d}")}
    money = lambda v: f"{'+' if v >= 0 else '-'}${abs(v):,.2f}"
    pnls = [r["pnl"] for r in month.values()] or [0]
    wins = sum(r["wins"] for r in month.values())
    losses = sum(r["losses"] for r in month.values())
    wr = 100 * wins / (wins + losses) if wins + losses else 0
    cells = "".join(f'<div class="hd">{d}</div>' for d in ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"])
    for week in calendar.Calendar(firstweekday=6).monthdatescalendar(y, m):
        for d in week:
            r = month.get(d.isoformat())
            cls = "out" if d.month != m else ("win" if r and r["pnl"] >= 0 else "loss" if r else "")
            body = (f"<b>{money(r['pnl'])}</b><small>{r['trades']}t &middot; {r['wins']}W {r['losses']}L</small>"
                    if r else "")
            cells += f'<div class="day {cls}"><span>{d.day}</span>{body}</div>'
    css = """
    :root{--bg:#f4f6fb;--card:#fff;--ink:#1c2333;--mut:#8a93a6;--g:#14894b;--r:#c0392b}
    @media(prefers-color-scheme:dark){:root{--bg:#10131a;--card:#1a1f2b;--ink:#e8ecf4;--mut:#7d869a}}
    body{margin:0;padding:16px;background:var(--bg);color:var(--ink);font-family:system-ui,sans-serif}
    .card{background:var(--card);border-radius:14px;padding:16px;margin-bottom:12px;max-width:820px}
    h1{margin:0 0 8px;font-family:Georgia,serif;font-weight:500}
    .stats{display:flex;flex-wrap:wrap;gap:6px 20px;font-family:ui-monospace,monospace}
    .grid{display:grid;grid-template-columns:repeat(7,1fr);gap:6px}
    .hd{font-size:11px;color:var(--mut);text-align:center;letter-spacing:1px}
    .day{min-height:68px;border:1px solid #8883;border-radius:10px;padding:5px;font-size:12px;
         display:flex;flex-direction:column;gap:2px;overflow:hidden}
    .day span{color:var(--mut)} .out{opacity:.3}
    .win b{color:var(--g)} .loss b{color:var(--r)} small{color:var(--mut);font-size:10px}
    .pos{color:var(--g)} .neg{color:var(--r)}"""
    cl = lambda v: "pos" if v >= 0 else "neg"
    html = f"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>P&amp;L Calendar</title>
<style>{css}</style></head><body>
<div class="card"><h1>{calendar.month_name[m]} {y}</h1><div class="stats">
<span>P&amp;L <b class="{cl(sum(pnls))}">{money(sum(pnls))}</b></span>
<span>Trades <b>{sum(r['trades'] for r in month.values())}</b></span>
<span>Win rate <b>{wr:.1f}%</b></span>
<span>Best day <b class="{cl(max(pnls))}">{money(max(pnls))}</b></span>
<span>Worst day <b class="{cl(min(pnls))}">{money(min(pnls))}</b></span>
</div></div><div class="card"><div class="grid">{cells}</div></div>
<p style="color:var(--mut);font-size:12px">All accounts combined. Updated {datetime.now(ET):%b %d %I:%M %p} ET</p>
</body></html>"""
    with open(CALENDAR_FILE, "w") as f:
        f.write(html)


# ---------------- main loop ----------------
def match_accounts(px):
    out = []
    for info in px.post("Account/search", {"onlyActiveAccounts": True})["accounts"]:
        if not info.get("canTrade"):
            continue
        cfg = next((c for c in ACCOUNTS if c.get("id") == info["id"]), None) or \
            next((c for c in ACCOUNTS if "id" not in c and c["match"] in info["name"]), None)
        if cfg:
            cfg = dict(cfg)
            if cfg["type"] == "express" and (info.get("balance") or 0) < 0.5 * cfg["start_balance"]:
                cfg["start_balance"] = 0      # Topstep funded accounts start at a $0 balance (50K is buying power)
            out.append(Account(info, cfg))
    if not out:
        raise SystemExit("None of the accounts switched on in Settings can trade right now. Check them in TopstepX.")
    if sum(1 for a in out if a.cfg["type"] == "express") > 5:
        log.warning("Topstep allows max 5 active Express Funded Accounts")
    return out

CAPS = {"min_pass": 75.0, "max_breach": 10.0, "table": [], "why": {}}

def risk_cap(kind, asked):
    """Biggest tested $/trade at or below what you asked for that still meets the safety floor:
    Combines must pass at least min_pass% of the time, funded accounts must breach at most max_breach%."""
    rows = [x for x in CAPS["table"] if x.get("risk") and x["risk"] <= asked]
    if not rows:
        return None
    if kind == "combine":
        ok = [x for x in rows if x.get("pass") is not None and x["pass"] >= CAPS["min_pass"]]
        CAPS["why"][kind] = f"Combines must pass at least {CAPS['min_pass']:.0f}% of the time in testing"
    else:
        ok = [x for x in rows if x.get("breach") is not None and x["breach"] <= CAPS["max_breach"]]
        CAPS["why"][kind] = f"funded accounts may lose the account at most {CAPS['max_breach']:.0f}% of the time"
    if any(x["risk"] == asked for x in ok):
        return asked
    return max((x["risk"] for x in ok), default=min(x["risk"] for x in rows))

# ---------------- remove what stops working ----------------
# Every finished trade is logged per setup. A setup that has clearly stopped working live
# (8+ signals since the last backtest, profit factor under 0.7 and losing money) is benched until
# the next backtest picks fresh setups. Benching only removes trades; it never changes a setup's rules.
LEDGER = "setup_ledger.json"
BENCH_MIN, BENCH_PF = 8, 0.7
BENCHED = {}     # "MNQ:orb" -> why

def ledger_load():
    try:
        with open(LEDGER) as f:
            d = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        d = {}
    if d.get("config") != CAPS.get("generated"):      # new backtest = fresh start for every setup
        d = {"config": CAPS.get("generated"), "trades": {}, "benched": {}}
    d.setdefault("trades", {})
    d.setdefault("benched", {})
    return d

def ledger_save(d):
    try:
        with open(LEDGER + ".tmp", "w") as f:
            json.dump(d, f)
        os.replace(LEDGER + ".tmp", LEDGER)
    except OSError:
        pass

def ledger_add(trips, acct, markets):
    """Record finished trades; returns setups that just got benched."""
    d = ledger_load()
    for t in trips:
        if t.get("strategy") in (None, "manual"):
            continue
        key = f"{t['market']}:{t['strategy']}"
        sig = t["time"][:16]                         # one signal traded on several accounts counts once
        d["trades"].setdefault(key, {}).setdefault(sig, {})[str(acct.id)] = t["net"]
    new = []
    for key, sigs in d["trades"].items():
        if key in d["benched"]:
            continue
        nets = [sum(v.values()) for v in sigs.values()]
        win, loss = sum(x for x in nets if x > 0), -sum(x for x in nets if x < 0)
        pf = win / loss if loss else 99
        if len(nets) >= BENCH_MIN and pf < BENCH_PF and sum(nets) < 0:
            sym, strat = key.split(":", 1)
            others = [l["strategy"] for l in (markets.get(sym, {}).get("legs") or []) if l["strategy"] != strat
                      and f"{sym}:{l['strategy']}" not in d["benched"]]
            d["benched"][key] = (f"{len(nets)} live trades, profit factor {pf:.2f}, {money(sum(nets))}. "
                                 + (f"{sym} keeps trading its other {len(others)} setup{'s' if len(others) > 1 else ''}." if others else
                                    f"{sym} pauses until the next backtest finds a replacement."))
            new.append(key)
    ledger_save(d)
    BENCHED.clear()
    BENCHED.update(d["benched"])
    return new

# ---------------- trial run for new setups ----------------
# (Optional) new setups can be made to earn real money first: each one trades on paper next to your live account
# (same signals, simulated fills) and only goes live after PROB_MIN paper trades that made money with a
# profit factor of PROB_PF or better. If it loses on paper it's benched without costing you anything.
# Progress is kept across weekly backtests, so a setup doesn't start over every Saturday.
PROBATION = set()   # off: you chose to let the backtest alone decide what trades (add setup names to turn trials on)
PROB_FILE = "trial_runs.json"
PROB_MIN, PROB_PF = 15, 1.2

def prob_load():
    try:
        with open(PROB_FILE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def prob_save(d):
    try:
        with open(PROB_FILE + ".tmp", "w") as f:
            json.dump(d, f)
        os.replace(PROB_FILE + ".tmp", PROB_FILE)
    except OSError:
        pass

def prob_stats(rec):
    rs = [t["r"] for t in rec.get("trades", [])]
    win, loss = sum(x for x in rs if x > 0), -sum(x for x in rs if x < 0)
    return len(rs), (win / loss if loss else (99 if win else 0)), sum(rs)

def on_trial(sym, strat):
    """True while this setup is still proving itself on paper (live accounts only)."""
    if strat not in PROBATION or PAPER:
        return False
    return prob_load().get(f"{sym}:{strat}", {}).get("status", "trial") != "live"

def trial_open(sym, strat, side, stop_pts, tgt_pts, bar, params, tick, pv):
    d = prob_load()
    rec = d.setdefault(f"{sym}:{strat}", {"status": "trial", "trades": []})
    if rec.get("status") == "benched" or rec.get("open"):
        return
    rec["open"] = {"side": side, "sig_t": bar["dt"].isoformat(), "stop_pts": stop_pts, "tgt_pts": tgt_pts,
                   "exit": params.get("exit"), "tick": tick, "pv": pv}
    prob_save(d)
    log.info(f"TRIAL {sym} {strat}: paper {side} (not traded live until it proves itself)")

def trial_update(sym, bars):
    """Walk open paper trades forward through new bars: stop first (conservative), then target, then time exit."""
    d = prob_load()
    changed = False
    for key, rec in d.items():
        o = rec.get("open")
        if not o or not key.startswith(sym + ":"):
            continue
        sig_t = datetime.fromisoformat(o["sig_t"])
        after = [b for b in bars if b["dt"] > sig_t]
        if not after:
            continue
        L, slip = o["side"] == "long", o["tick"]
        entry = after[0]["o"] + (slip if L else -slip)
        stop = entry - o["stop_pts"] if L else entry + o["stop_pts"]
        tgt = entry + o["tgt_pts"] if L else entry - o["tgt_pts"]
        ex_dt = S.exit_time(after[0]["dt"], {"exit": o["exit"]} if o.get("exit") else {})
        out = None
        for b in after:
            if b["dt"] >= ex_dt:
                out = b["o"] - slip if L else b["o"] + slip
            elif (b["l"] <= stop) if L else (b["h"] >= stop):
                out = (min(b["o"], stop) - slip) if L else (max(b["o"], stop) + slip)
            elif (b["h"] >= tgt) if L else (b["l"] <= tgt):
                out = tgt
            if out is not None:
                break
        if out is None:
            continue
        move = (out - entry) if L else (entry - out)
        r = move / o["stop_pts"] - 1.0 / (o["stop_pts"] * o["pv"])        # minus round-trip fees (about $1 per micro)
        rec.setdefault("trades", []).append({"t": o["sig_t"], "side": o["side"], "r": round(r, 3)})
        rec["open"] = None
        changed = True
        n, pf, tot = prob_stats(rec)
        log.info(f"TRIAL {key}: paper trade {r:+.2f}R, now {n} trades, PF {pf:.2f}, {tot:+.1f}R")
        if n >= PROB_MIN and pf >= PROB_PF and tot > 0:
            rec["status"] = "live"
            msg = f"{n} paper trades, profit factor {pf:.2f}, {tot:+.1f}R. It now trades your accounts."
            log.warning(f"TRIAL PASSED {key}: {msg}")
            if NOTIFY["trades"]:
                NT.send(NOTIFY, f"Swing: {key.replace(':', ' ')} passed its trial", msg, tags="tada")
        elif n >= 8 and pf < 0.8 and tot < 0:
            rec["status"] = "benched"
            log.warning(f"TRIAL FAILED {key}: {n} paper trades, PF {pf:.2f}, {tot:+.1f}R. Never traded live.")
    if changed:
        prob_save(d)

def setup_stats():
    d = ledger_load()
    out = {}
    for key, sigs in d["trades"].items():
        nets = [sum(v.values()) for v in sigs.values()]
        win, loss = sum(x for x in nets if x > 0), -sum(x for x in nets if x < 0)
        out[key] = {"trades": len(nets), "net": round(sum(nets), 2), "wins": sum(1 for x in nets if x > 0),
                    "pf": round(win / loss, 2) if loss else None, "benched": d["benched"].get(key)}
    for key, rec in prob_load().items():
        n, pf, tot = prob_stats(rec)
        out.setdefault(key, {"trades": 0, "net": 0, "pf": None, "benched": None})["trial"] = {
            "status": rec.get("status", "trial"), "n": n, "need": PROB_MIN, "pf": round(pf, 2) if n else None,
            "r": round(tot, 1), "open": bool(rec.get("open"))}
    return out

def load_strategy_config():
    try:
        with open(CONFIG_FILE) as f:
            bc = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        bc = None
    if not bc or not bc.get("markets"):
        if not DRY_RUN and not PAPER:
            raise SystemExit("No best_config.json. Run backtest.py first; it decides what's safe to trade.")
        log.warning("No best_config.json yet: using a default strategy until you run the backtest")
        bc = {"risk_per_trade": 100, "markets": {s: DEFAULT_STRATEGY for s in DEFAULT_MARKETS}}
    # Overnight models (Asia, London, Europe) are retired: they lost money live. Never trade them,
    # even if an older best_config.json still lists them.
    for sym, mc in list(bc["markets"].items()):
        legs = [l for l in (mc.get("legs") or [mc]) if l.get("strategy") not in RETIRED]
        if not legs:
            log.info(f"{sym}: overnight model retired, market off")
            del bc["markets"][sym]
            continue
        if mc.get("strategy") in RETIRED or len(legs) != len(mc.get("legs") or [mc]):
            log.info(f"{sym}: overnight model retired, keeping {', '.join(l['strategy'] for l in legs)}")
            top = {k: v for k, v in legs[0].items()}
            for k in ("test_stats", "train_stats", "stats"):
                if k in mc:
                    top[k] = mc[k]
            top["legs"] = legs
            bc["markets"][sym] = top
    CAPS.update(min_pass=float(MIN_PASS_SETTING if MIN_PASS_SETTING is not None else bc.get("min_pass", 75)),
                max_breach=float(bc.get("max_breach", 10)), table=bc.get("risk_table") or [],
                generated=bc.get("generated"))
    BENCHED.update(ledger_load().get("benched", {}))
    r = bc["risk_per_trade"]
    if CAPS["table"] and CAPS["min_pass"] != float(bc.get("min_pass", 75)):
        # you changed the pass-rate floor since the backtest: re-pick the Combine size from its table
        ok = [x for x in CAPS["table"] if x.get("pass") is not None and x["pass"] >= CAPS["min_pass"]]
        if ok:
            r = min(ok, key=lambda x: (x["days"] or 10**6, -x["pass"], x["risk"]))["risk"]
            log.info(f"Combine size re-picked for a {CAPS['min_pass']:.0f}% pass floor: ${r}/trade")
    RISK_PRESETS["auto"] = {"risk": r, "daily_loss": 3 * r, "daily_cap": 7 * r, "max_trades": 6}
    rx = bc.get("risk_express", r)          # funded accounts: the size that kept the most money in testing
    RISK_PRESETS["auto_express"] = {"risk": rx, "daily_loss": 3 * rx, "daily_cap": 7 * rx, "max_trades": 6}
    if RISK_OVERRIDE:                       # your own amount from Settings replaces Swing's pick
        ro = RISK_OVERRIDE
        RISK_PRESETS["custom"] = {"risk": ro, "daily_loss": 3 * ro, "daily_cap": 7 * ro, "max_trades": 6}
    return bc

# ---------------- one trader at a time ----------------
# If Swing runs on the cloud server AND on your PC for the same Topstep login, only one may trade.
# Each copy posts a heartbeat to a private channel named after your Topstep login (ntfy.sh, free).
# The cloud copy always trades; a PC copy that hears the cloud stands by (no orders at all), and takes
# over by itself if the cloud copy goes quiet for 3 minutes.
import hashlib, secrets as _secrets
INSTANCE = _secrets.token_hex(4)
LOCK = {"standby": None, "last": 0, "seen": 0}

def lock_check():
    if PAPER or not USERNAME:
        return None                                  # paper accounts are separate in each copy: no overlap
    if time.time() - LOCK["last"] < 30:
        return LOCK["standby"]
    LOCK["last"] = time.time()
    topic = "swing-lock-" + hashlib.sha256(USERNAME.lower().encode()).hexdigest()[:20]
    try:
        requests.post(f"https://ntfy.sh/{topic}", data=json.dumps({"id": INSTANCE, "host": HOST}),
                      headers={"Cache": "yes", "Title": "heartbeat"}, timeout=8)
        if HOST != "cloud":
            r = requests.get(f"https://ntfy.sh/{topic}/json", params={"poll": "1", "since": "3m"}, timeout=8)
            for line in r.text.splitlines():
                try:
                    m = json.loads(json.loads(line).get("message") or "{}")
                except ValueError:
                    continue
                if m.get("host") == "cloud" and m.get("id") != INSTANCE:
                    LOCK["seen"] = time.time()
    except requests.RequestException:
        pass                                         # can't reach the channel: keep the last decision
    was = LOCK["standby"]
    LOCK["standby"] = ("the cloud copy of Swing is trading" if HOST != "cloud" and time.time() - LOCK["seen"] < 180
                       else None)
    if LOCK["standby"] != was:
        log.warning(f"STANDBY: {LOCK['standby']}. This copy places no orders." if LOCK["standby"]
                    else "This copy is trading now (no other copy heard).")
    return LOCK["standby"]

NEWS_STATE = {"paused": None, "until": None, "shock": {}, "upcoming": [], "ok": True, "alert": None}

_SETTINGS_MTIME = [None]

def reload_notify():
    """Pick up notification changes from the app without restarting the bot."""
    global NOTIFY
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.json")
    try:
        m = os.path.getmtime(p)
        if m == _SETTINGS_MTIME[0]:
            return
        first = _SETTINGS_MTIME[0] is None
        _SETTINGS_MTIME[0] = m
        with open(p) as f:
            new = NT.settings(json.load(f).get("notify"))
        if not first and new.get("enabled") != NOTIFY.get("enabled"):
            log.info("Phone notifications " + ("on" if new.get("enabled") else "off"))
        NOTIFY.clear()
        NOTIFY.update(new)
    except (OSError, ValueError):
        pass

def money(v):
    return f"{'+' if v >= 0 else '-'}${abs(v):,.2f}"

def brief(kind, title, body):
    NT.save_brief(kind, title, body)
    if (kind == "weekly" and NOTIFY["weekly"]) or (kind != "weekly" and NOTIFY["briefs"]):
        NT.send(NOTIFY, title, body, tags="newspaper" if kind == "morning" else "bar_chart")

def morning_brief(now, accounts, infos, st, events, markets):
    lines = []
    today = [e for e in events if datetime.fromisoformat(e["time"]).date() == now.date()
             and (e["impact"] == "High" or NEWS["medium"])]
    if today:
        lines.append("News today: " + "; ".join(
            f"{e['title']} {datetime.fromisoformat(e['time']):%I:%M %p} ET".replace(" 0", " ") for e in today[:5])
            + ". Swing pauses around these.")
    else:
        lines.append("No big US news today.")
    lines.append("Watching: " + ", ".join(markets) + (" (paper)" if PAPER else " (watch only)" if DRY_RUN else "") + ".")
    for a in accounts:
        days = st.get(str(a.id), {}).get("days", {})
        last = days[max(days)]["pnl"] if days else None
        bal = infos.get(a.id, {}).get("balance")
        lines.append(f"{a.name}: balance ${bal:,.2f}" + (f", last session {money(last)}" if last is not None else "") + ".")
    brief("morning", f"Swing morning brief, {now:%a %b %d}", "\n".join(lines))

def evening_recap(now, accounts, infos, st, tday):
    lines, total, trips = [], 0.0, []
    for a in accounts:
        d = st.get(str(a.id), {}).get("days", {}).get(tday, {})
        total += d.get("pnl", 0)
        trips += d.get("trips", [])
    w = sum(1 for x in trips if x["outcome"] == "Win")
    l = sum(1 for x in trips if x["outcome"] == "Loss")
    pl = lambda n, word: f"{n} {word}{'' if n == 1 else ('es' if word.endswith('s') else 's')}"
    lines.append(f"Today {money(total)} from {pl(len(trips), 'trade')} ({pl(w, 'win')}, {pl(l, 'loss')})." if trips
                 else "No trades today. Sometimes the best trade is no trade.")
    if trips:
        best = max(trips, key=lambda x: x["net"])
        lines.append(f"Best: {best['market']} {best['side'].lower()} {money(best['net'])} ({best['session']}).")
    for a in accounts:
        s = st.get(str(a.id), {})
        bal = infos.get(a.id, {}).get("balance") or 0
        floor = a.cfg["start_balance"] if s.get("paid_out") else \
            min(s.get("peak_eod", a.cfg["start_balance"]) - a.cfg["mll"], a.cfg["start_balance"])
        extra = ""
        if a.cfg["type"] == "combine" and a.cfg.get("profit_target"):
            left = a.cfg["start_balance"] + a.cfg["profit_target"] - bal
            extra = f", ${max(left, 0):,.0f} to the profit target" if left > 0 else ", profit target reached"
        lines.append(f"{a.name}: ${bal:,.2f}, ${bal - floor:,.0f} above max loss{extra}.")
    brief("evening", f"Swing recap, {now:%a %b %d}", "\n".join(lines))
    if now.weekday() == 4:
        week = [k for k in sorted({d for a in accounts for d in st.get(str(a.id), {}).get("days", {})})
                if (now.date() - date.fromisoformat(k)).days < 7]
        daily = {k: sum(st.get(str(a.id), {}).get("days", {}).get(k, {}).get("pnl", 0) for a in accounts) for k in week}
        allt = [x for a in accounts for k in week for x in st.get(str(a.id), {}).get("days", {}).get(k, {}).get("trips", [])]
        ww = sum(1 for x in allt if x["outcome"] == "Win")
        ll = sum(1 for x in allt if x["outcome"] == "Loss")
        body = [f"Week {money(sum(daily.values()))} over {len(daily)} day{'s' if len(daily) != 1 else ''}, "
                f"{len(allt)} trade{'s' if len(allt) != 1 else ''}."]
        if ww + ll:
            body.append(f"Win rate {100 * ww / (ww + ll):.0f}%.")
        if daily:
            body.append(f"Best day {money(max(daily.values()))}, worst day {money(min(daily.values()))}.")
        brief("weekly", "Swing weekly P&L report", " ".join(body))

def names_of(position):
    cid = position["contractId"]
    return cid.split(".")[3] if cid.count(".") >= 4 else cid

def losses_in_a_row(trips, market=None):
    n = 0
    for t in sorted(trips, key=lambda t: t["time"]):
        if market and t["market"] != market:
            continue
        n = n + 1 if t["outcome"] == "Loss" else 0
    return n

def position_view(a, p, names, contracts, journal):
    """One open trade for the app: entry, stop, targets, last price and open P&L."""
    cid = p["contractId"]
    sym = names.get(cid, cid)
    long_ = p["type"] == 1
    exit_side = 1 if long_ else 0
    mine = [o for o in ORDERS.get(a.id, []) if o.get("contractId") == cid and o.get("side") == exit_side]
    stop = next((o.get("stopPrice") for o in mine if o.get("type") == 4 and o.get("stopPrice") is not None), None)
    targets = sorted({o.get("limitPrice") for o in mine if o.get("type") == 1 and o.get("limitPrice") is not None},
                     reverse=not long_)
    last = CHART[sym][-1][4] if CHART.get(sym) else None
    pv = (contracts.get(sym) or {}).get("point_value")
    upnl = None
    if last is not None and pv:
        upnl = round((last - p["averagePrice"]) * (1 if long_ else -1) * pv * p["size"], 2)
    j = next((e for e in reversed(journal) if e.get("acct") == a.id and e.get("cid") == cid), None)
    return {"symbol": sym, "side": "Long" if long_ else "Short", "size": p["size"], "avg": p["averagePrice"],
            "stop": stop, "targets": targets, "last": last, "upnl": upnl,
            "since": datetime.fromtimestamp(j["ts"], ET).isoformat() if j else None,
            "setup": S.SETUP.get(j.get("strategy"), "Setup") if j else None,
            "risk_usd": round(abs(p["averagePrice"] - stop) * pv * p["size"], 2) if stop is not None and pv else None}

def write_status(accounts, infos, positions, pnl_cache, markets, contracts, closed):
    """Snapshot for the app's dashboard."""
    names = {c["id"]: s for s, c in contracts.items() if c}
    try:
        with open(JOURNAL) as f:
            journal = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        journal = []
    out = {"ts": time.time(), "updated": datetime.now(ET).strftime("%I:%M:%S %p ET"), "dry_run": DRY_RUN, "paper": PAPER,
           "market_open": not closed, "markets": {s: m["strategy"] for s, m in markets.items()}, "accounts": [],
           "news": {"paused": NEWS_STATE["paused"], "until": NEWS_STATE["until"], "ok": NEWS_STATE["ok"],
                    "shock": {s: u for s, u in NEWS_STATE["shock"].items()}, "alert": NEWS_STATE["alert"]},
           "charts": {s: CHART[s] for s in markets if s in CHART},
           "benched": dict(BENCHED), "setups": setup_stats(), "standby": LOCK["standby"], "host": HOST}
    for a in accounts:
        info = infos.get(a.id, {})
        out["accounts"].append({
            "name": a.name, "type": a.cfg["type"], "balance": info.get("balance"),
            "pnl_today": round(pnl_cache.get(a.id, (0, 0))[1], 2), "halted": a.halted,
            "risk": round(a.risk or a.p["risk"]), "trades_today": a.trades_today, "max_trades": a.p["max_trades"],
            "trips": a.trips, "capped": a.capped,
            "room": round(a.room) if getattr(a, "room", None) is not None else None,
            "risk_full": round(a.p["risk"] * (a.cfg["mll"] / 2000 if a.cfg["risk"] == "auto" else 1)), "cushion": a.cfg["type"] == "express" and 0 < a.risk < a.p["risk"],
            "positions": [position_view(a, p, names, contracts, journal) for p in positions.get(a.id, [])]})
    try:
        with open("status.json.tmp", "w") as f:
            json.dump(out, f)
        os.replace("status.json.tmp", "status.json")
    except OSError:
        pass

def _nth_weekday(y, m, wd, n):
    """n-th weekday wd (Mon=0) of a month; n=-1 for the last one."""
    from datetime import date as _d
    if n > 0:
        first = _d(y, m, 1)
        return first + timedelta(days=(wd - first.weekday()) % 7 + 7 * (n - 1))
    last = (_d(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1))
    return last - timedelta(days=(last.weekday() - wd) % 7)

def _observed(d):
    return d - timedelta(days=1) if d.weekday() == 5 else d + timedelta(days=1) if d.weekday() == 6 else d

def sit_out_days(y):
    """Days Swing doesn't trade: US holidays and early-close days (thin, jumpy markets that close early, so a
    trade can get stuck past the close) and national election days plus the day after (headline-driven
    swings that no backtest pattern covers)."""
    from datetime import date as _d
    a, b = y % 19, y // 100                    # Easter (for Good Friday), anonymous Gregorian algorithm
    c, e = y % 100, b // 4
    f = (b - (b + 8) // 25 + 1) // 3
    h = (19 * a + b - e - f + 15) % 30
    l_ = (32 + 2 * (b % 4) + 2 * (c // 4) - h - c % 4) % 7
    m_ = (a + 11 * h + 22 * l_) // 451
    easter = _d(y, (h + l_ - 7 * m_ + 114) // 31, ((h + l_ - 7 * m_ + 114) % 31) + 1)
    thanks = _nth_weekday(y, 11, 3, 4)
    days = {
        _observed(_d(y, 1, 1)): "New Year's Day", _nth_weekday(y, 1, 0, 3): "Martin Luther King Jr. Day",
        _nth_weekday(y, 2, 0, 3): "Presidents' Day", easter - timedelta(days=2): "Good Friday",
        _nth_weekday(y, 5, 0, -1): "Memorial Day", _observed(_d(y, 6, 19)): "Juneteenth",
        _observed(_d(y, 7, 4)): "Independence Day", _nth_weekday(y, 9, 0, 1): "Labor Day",
        thanks: "Thanksgiving", thanks + timedelta(days=1): "day after Thanksgiving (early close)",
        _observed(_d(y, 12, 25)): "Christmas",
    }
    if _d(y, 12, 24).weekday() < 5:
        days.setdefault(_d(y, 12, 24), "Christmas Eve (early close)")
    if y % 2 == 0:                                # federal elections: Tuesday after the first Monday of November
        ed_ = _nth_weekday(y, 11, 0, 1) + timedelta(days=1)
        days[ed_] = "Election Day"
        days[ed_ + timedelta(days=1)] = "day after the election"
    return days

def sit_out(now):
    """Why Swing sits out today (ET calendar day), or None."""
    return sit_out_days(now.year).get(now.date()) if RULES.get("sit_out", True) else None

def market_closed(now):
    """Flat period: 3:50-6 PM ET weekdays, and Fri 3:50 PM to Sun 6 PM ET."""
    hm, wd = (now.hour, now.minute), now.weekday()
    return (wd == 4 and hm >= tuple(FLATTEN)) or wd == 5 or (wd == 6 and hm < (18, 0)) \
        or (tuple(FLATTEN) <= hm < (18, 0))

def main():
    if not PAPER and (not USERNAME or not API_KEY):
        raise SystemExit("Add your TopstepX username and API key in Settings, or switch to Paper mode.")
    bc = load_strategy_config()
    markets = bc["markets"]
    if PAPER:
        from paper import PaperPX
        px = PaperPX()
        log.info("PAPER MODE: free delayed data from Yahoo Finance, simulated fills, no broker")
    else:
        px = PX()
    st = load_state()
    accounts = match_accounts(px)
    for a in accounts:
        log.info(f"Account: {a.name} ({a.cfg['type']}, risk {a.cfg['risk']} = ${a.p['risk']}/trade)")
    for sym, m in markets.items():
        log.info(f"{sym}: {m['strategy']} {json.dumps(m['params'])}")
    log.info(f"DRY_RUN={DRY_RUN}")
    needed = set(markets) | {S.PAIRS[s] for s, m in markets.items() if m["strategy"] == "smt" and s in S.PAIRS}
    contracts, last_bar, day, pnl_cache = {}, {s: None for s in markets}, None, {}
    next_due = {}
    load_live()

    while True:
        try:
            if os.path.exists("STOP"):
                log.warning("Kill switch found: flattening everything and exiting")
                if not DRY_RUN:
                    for a in accounts:
                        flatten_account(px, a.id)
                return

            reload_notify()
            if lock_check():                     # another copy (the cloud) is trading: hands off completely
                write_status(accounts, {}, {}, pnl_cache, markets, contracts, False)
                time.sleep(20)
                continue
            now = datetime.now(ET)
            hm, tday = (now.hour, now.minute), S.trade_day(now).isoformat()
            if tday != day:
                day = tday
                for a in accounts:
                    a.trades_today, a.halted, a.risk, a.peak, a.trips = 0, None, 0, 0.0, []
                contracts = {s: find_contract(px, s) for s in needed}    # handles contract rolls

            infos = {i["id"]: i for i in px.post("Account/search", {"onlyActiveAccounts": True})["accounts"]}
            positions = {a.id: get_positions(px, a.id) for a in accounts if a.id in infos}
            if not DRY_RUN:
                for a in accounts:
                    if a.id in positions:
                        manage_runners(px, a, positions[a.id])
                        protect(px, a, positions[a.id])

            if market_closed(now):
                if not DRY_RUN:
                    for a in accounts:
                        if positions.get(a.id):
                            flatten_account(px, a.id)
                if now.weekday() < 5 and tuple(FLATTEN) <= hm < (18, 0) and st.get("last_eod") != tday:
                    record_eod(px, accounts, infos, st, tday)
                for s_ in markets:
                    if s_ not in CHART and contracts.get(s_):
                        try:
                            chart_update(s_, get_bars(px, contracts[s_]["id"]))
                        except Exception:
                            pass
                write_status(accounts, infos, positions, pnl_cache, markets, contracts, True)
                time.sleep(60)
                continue

            # --- strategy time exits (e.g. Asia trades close by 3 AM ET) ---
            for a in accounts:
                for p_ in list(positions.get(a.id, [])):
                    ex = (OPENED.get((a.id, p_["contractId"])) or {}).get("exit")
                    if ex and S.in_window(now, ex, S.add_min(ex, 15)):
                        log.info(f"[{a.name}] {names_of(p_)} strategy exit time, closing")
                        if not DRY_RUN:
                            flatten_contract(px, a.id, p_["contractId"])
                            positions[a.id] = get_positions(px, a.id)

            for s_, u in list(NEWS_STATE.get("shock_dt", {}).items()):
                if now >= u:
                    NEWS_STATE["shock_dt"].pop(s_)
                    NEWS_STATE["shock"].pop(s_, None)

            # --- news: scheduled events, headline alerts ---
            try:
                events, ok = N.calendar()
            except Exception:
                events, ok = [], False
            NEWS_STATE["ok"] = ok
            if now.weekday() < 5 and (8, 30) <= hm < (9, 0) and st.get("last_morning") != tday:
                st["last_morning"] = tday
                save_state(st)
                try:
                    morning_brief(now, accounts, infos, st, events, list(markets))
                except Exception:
                    log.exception("morning brief failed")
            reason, until = N.news_pause(now, events, NEWS, ok)
            if not reason and NEWS["headline_pause"]:
                try:
                    hit = N.headline_alert(N.headlines(NEWS["keywords"]), 10)
                except Exception:
                    hit = None
                if hit:
                    reason = f"headline: {hit['title'][:80]}"
                    until = datetime.fromisoformat(hit["time"]).astimezone(ET) + timedelta(minutes=15)
            if reason != NEWS_STATE["paused"]:
                log.info(f"NEWS PAUSE: no new trades until {until:%I:%M %p} ET ({reason})" if reason
                         else "NEWS PAUSE over: trading resumes")
            day_off = sit_out(now)
            if day_off:
                reason, until = f"{day_off}: Swing sits out today", now.replace(hour=23, minute=59)
                if any(positions.values()) and not DRY_RUN and NEWS_STATE.get("sat_out") != now.date():
                    NEWS_STATE["sat_out"] = now.date()
                    log.info(f"{day_off}: closing open trades, no trading today")
                    for a in accounts:
                        if positions.get(a.id):
                            flatten_account(px, a.id)
                            positions[a.id] = get_positions(px, a.id)
            NEWS_STATE["paused"] = reason
            NEWS_STATE["until"] = until.strftime("%I:%M %p ET") if until else None
            ev = N.flatten_due(now, events, NEWS)
            if ev and NEWS_STATE.get("flattened") != ev["time"]:
                NEWS_STATE["flattened"] = ev["time"]
                if any(positions.values()):
                    log.info(f"NEWS: closing open trades before {ev['title']}")
                    if not DRY_RUN:
                        for a in accounts:
                            if positions.get(a.id):
                                flatten_account(px, a.id)
                                positions[a.id] = []

            # --- per-account risk guards ---
            for a in accounts:
                if a.id not in infos:
                    a.halted = a.halted or "account no longer active"
                    continue
                if a.halted:
                    continue
                ts, pnl = pnl_cache.get(a.id, (0, 0))
                if time.time() - ts > 60:
                    trades = day_trades(px, a.id)
                    pnl = sum((t.get("profitAndLoss") or 0) - (t.get("fees") or 0) for t in trades)
                    pnl_cache[a.id] = (time.time(), pnl)
                    new = round_trips(trades, a)
                    if NOTIFY["trades"] and len(new) > len(a.trips):
                        for x in new[len(a.trips):]:
                            NT.send(NOTIFY, f"Swing: {x['market']} {x['side'].lower()} closed {money(x['net'])}",
                                    f"{x['outcome']} on {a.name}. Today so far {money(pnl)}.",
                                    tags="white_check_mark" if x["net"] > 0 else "x")
                    a.trips = new
                    for key in ledger_add(new, a, markets):
                        log.warning(f"BENCHED {key}: {BENCHED[key]}")
                        if NOTIFY["trades"]:
                            NT.send(NOTIFY, f"Swing: stopped using {key.replace(':', ' ')}", BENCHED[key], tags="warning")
                reason, a.risk = guard(a, infos[a.id], pnl, st)
                a.peak = max(a.peak, pnl)
                if not reason and RULES["giveback"] and a.peak >= 2 * a.p["risk"] and pnl <= 0.5 * a.peak:
                    reason = f"gave back half of today's gains (peak ${a.peak:.0f}, now ${pnl:.0f}), keeping the rest"
                if not reason and RULES["loss_streak_all"] and losses_in_a_row(a.trips) >= 2:
                    reason = "2 losses in a row"
                if reason:
                    a.halted = reason
                    log.info(f"[{a.name}] STOPPED for today: {reason}")
                    if NOTIFY["trades"]:
                        NT.send(NOTIFY, f"Swing: {a.name} done for today", reason[:1].upper() + reason[1:] + ".",
                                tags="octagonal_sign")
                    if not DRY_RUN and positions.get(a.id):
                        flatten_account(px, a.id)
                        positions[a.id] = []

            # --- per-market signals ---
            bar_cache = {}
            def bars_for(s):
                if s not in bar_cache and contracts.get(s):
                    bar_cache[s] = get_bars(px, contracts[s]["id"])
                    chart_update(s, bar_cache[s])
                return bar_cache.get(s, [])

            for sym, m in markets.items():
                c = contracts.get(sym)
                if not c:
                    continue
                due = next_due.get(sym)
                if due and now < due:                  # no new 5-minute candle yet: skip the download
                    continue
                bars = bars_for(sym)
                if bars:
                    next_due[sym] = bars[-1]["dt"] + timedelta(minutes=2 * BAR_MINUTES, seconds=3)
                if len(bars) < 250 or bars[-1]["t"] == last_bar[sym]:
                    continue
                last_bar[sym] = bars[-1]["t"]
                legs = m.get("legs") or [m]
                if any(l["strategy"] in PROBATION for l in legs) and not PAPER:
                    try:
                        trial_update(sym, bars)
                    except Exception:
                        log.exception("trial update failed")
                if NEWS["shock"] and any(l.get("shock_filter", True) for l in legs) and N.shock(bars, S.atr(bars)):
                    until = now + timedelta(minutes=5 * N.SHOCK_BARS)
                    for s_ in {sym, S.PAIRS.get(sym, sym)}:
                        NEWS_STATE["shock"][s_] = until.strftime("%I:%M %p ET")
                        NEWS_STATE.setdefault("shock_dt", {})[s_] = until
                    log.info(f"VOLATILITY SHOCK on {sym}: no new {sym} trades until {until:%I:%M %p} ET")
                # several setups per market: the first one (best first) that signals takes the trade
                sd = NEWS_STATE.get("shock_dt", {}).get(sym)
                sig = None
                for leg in legs:
                    if f"{sym}:{leg['strategy']}" in BENCHED:
                        continue
                    if leg.get("skip_lunch") and S.in_window(now, [11, 30], [13, 30]):
                        continue
                    if NEWS["shock"] and leg.get("shock_filter", True) and sd and now < sd:
                        continue
                    pair = bars_for(S.PAIRS[sym]) if leg["strategy"] == "smt" and sym in S.PAIRS else None
                    sig = S.get_signal(leg["strategy"], bars, leg["params"], pair)
                    if sig and on_trial(sym, leg["strategy"]):
                        if not NEWS_STATE["paused"]:
                            trial_open(sym, leg["strategy"], sig[0], max(sig[1], 4 * c["tickSize"]),
                                       max(sig[2], 4 * c["tickSize"]), bars[-1], leg["params"],
                                       c["tickSize"], c["point_value"])
                        sig = None
                        continue
                    if sig:
                        m = leg
                        break
                if not sig:
                    continue
                side, stop_pts, tgt_pts = sig
                stop_pts = max(stop_pts, 4 * c["tickSize"])
                tgt_pts = max(tgt_pts, 4 * c["tickSize"])
                cid = c["id"]

                # exit positions pointing the other way first
                opp = 2 if side == "long" else 1
                for a in accounts:
                    if any(p["contractId"] == cid and p["type"] == opp for p in positions.get(a.id, [])):
                        log.info(f"[{a.name}] {sym} reversal signal, closing position")
                        if not DRY_RUN:
                            flatten_contract(px, a.id, cid)
                            positions[a.id] = get_positions(px, a.id)

                if NEWS_STATE["paused"]:
                    log.info(f"{sym} {side} signal skipped: news pause ({NEWS_STATE['paused']})")
                    continue
                if sym == "MCL":
                    oil = N.oil_pause(now, events, NEWS)
                    if oil:
                        log.info(f"MCL {side} signal skipped: {oil}")
                        continue
                if m.get("skip_lunch") and S.in_window(now, [11, 30], [13, 30]):
                    log.info(f"{sym} {side} signal skipped: lunch chop (11:30-1:30 ET)")
                    continue
                if NEWS["shock"] and m.get("shock_filter", True) and sd and now < sd:
                    log.info(f"{sym} {side} signal skipped: volatility shock")
                    continue
                want = 1 if side == "long" else 2
                if any(p["contractId"] == cid and p["type"] != want
                       for ps in positions.values() for p in ps):
                    log.warning(f"{sym} {side} skipped: would hedge across accounts")
                    continue

                for a in accounts:
                    ps = positions.get(a.id)
                    if ps is None or a.halted or a.risk <= 0 or a.trades_today >= a.p["max_trades"]:
                        continue
                    if len(ps) >= MAX_OPEN_POSITIONS or any(p["contractId"] == cid for p in ps):
                        continue
                    if sym in S.RISK_ON and any(names_of(p) in S.RISK_ON and p["type"] == want for p in ps):
                        log.info(f"[{a.name}] {sym} skipped: already {side} Nasdaq/S&P (same bet twice)")
                        continue
                    if m.get("loss_streak_stop") and losses_in_a_row(a.trips, sym) >= 2:
                        log.info(f"[{a.name}] {sym} skipped: 2 losses in a row in {sym} today")
                        continue
                    scale = a.cfg["mll"] / 2000 if a.cfg["risk"] == "auto" else 1
                    cap = max(int(MAX_CONTRACTS_PER_TRADE * scale), int(MAX_CONTRACTS_PER_TRADE * a.p["risk"] / 100))
                    size = min(cap, a.cfg["max_micros"],
                               int(a.risk // (stop_pts * c["point_value"])))
                    fixed = m["params"].get("fixed_size")
                    if fixed:                          # researched setups trade a set size, not a risk amount
                        size = fixed
                        room_ = getattr(a, "room", None)
                        if room_ is not None and size * stop_pts * c["point_value"] > room_ * 0.6:
                            log.info(f"[{a.name}] {sym} skipped: its safety stop needs more room above the max loss limit")
                            continue
                    if size < 1:
                        log.info(f"[{a.name}] {sym} skipped: stop too wide for ${a.risk:.0f} risk")
                        continue
                    if DRY_RUN:
                        log.info(f"[DRY RUN][{a.name}] {side} {size}x {sym} ({S.SETUP.get(m['strategy'], 'setup').lower()}"
                                 f"{', runner' if m['params'].get('partial') and size >= 2 else ''}), "
                                 f"stop {stop_pts:.2f} / target {tgt_pts:.2f} pts, "
                                 f"risk ${size * stop_pts * c['point_value']:.0f}")
                    else:
                        ok = enter(px, a, c, side, size, stop_pts, tgt_pts, m["params"].get("partial", False), m["strategy"])
                        positions[a.id] = get_positions(px, a.id)
                        if not ok:
                            continue                     # a failed entry doesn't use up a trade
                        OPENED[(a.id, cid)] = m["params"]
                        save_live()
                    a.trades_today += 1
            write_status(accounts, infos, positions, pnl_cache, markets, contracts, False)
        except Exception:
            log.exception("Loop error")
            time.sleep(30)
        time.sleep(LOOP_SECONDS)


if __name__ == "__main__":
    main()
